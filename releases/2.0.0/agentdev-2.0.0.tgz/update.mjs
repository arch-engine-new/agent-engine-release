#!/usr/bin/env node
/**
 * rpo/update.mjs — 客户机在线更新（commercial T4；spec §5.5，红队 M3/M4/M7）。
 *
 * 本脚本随商业包分发（包根 update.mjs；默认安装根 = 脚本所在目录），承载更新的机械
 * 步骤；agentdev-update skill 编排调用并解读 JSON 判定（与 goal 模式同构）。
 *
 * 流程（每步 fail-closed，任一失败即中止且安装态不变）：
 *   1. 本地版本读取（<installRoot>/package.json；非安装形态即拒）
 *   2. 信任锚解析（M1 同纪律）：import 包内 mcp/src/license/verify.js 的
 *      EMBEDDED_LICENSE_PUBLIC_KEY——空（dev 形态）即拒。绝不接受外部传入公钥
 *      （env/CLI 传入等于把更新信任锚交给攻击者选择）；v1 manifest 签名钥 = 发证钥
 *      同钥（O4 v1.2 评估记录见 pack.mjs 头注与 report）。
 *   3. 版本发现（O3）：GET <base>/releases/index.json → 列集取语义 max（--to-version
 *      可显式指定，单调性照常强制）。
 *   4. manifest 验签（M3）：latest-<version>.json 剥 signature 后 canonicalJson +
 *      Ed25519 verify（canonicalJson 为面向客户机的自足副本，与 rpo 库同算法逐字实现；
 *      lockstep 由「pack 产物被本副本验签通过」的测试行为级锚定）。
 *   5. 单调性校验（M4）：目标 < 本地 → 拒绝（版本回退攻击防御）；目标 == 本地 →
 *      up-to-date 空操作。
 *   6. 下载 tgz + sha256 校验（不符 → 拒装 + 证据留档 .agentdev/update-rejected/）。
 *   7. 上一版备份 → .agentdev/backup/<stamp>/（排除 node_modules[重装可再生] 与
 *      .agentdev 自身[license/台账不进备份]）；解包（tar 解析器：checksum 校验 +
 *      zip-slip 防逃逸）→ 逐文件 sha256 对账 + 文件集双向对账。
 *   8. skills 重分发（zcode/codex skills 形态复制到项目根；commands 形态平台由
 *      distribute.sh/ps1 承接，输出中明示）。
 *   9. npm ci（M7 lean 清单 + 随包 lockfile；失败 → 自动回滚备份——半更新的安装比
 *      旧版本更危险）。失败/回滚均需联网重试或 --rollback（v1 更新需联网，R1-M7 明示）。
 *  10. 版本回写：.agentdev/update-state.json 台账（fromVersion/toVersion/动作/时间）。
 *
 * 回滚：--rollback 恢复最近一次备份（版本与安装态还原；建议随后 npm ci 重建依赖）。
 *
 * 用法：
 *   node update.mjs [--base-url=<发布基址>] [--to-version=x.y.z]
 *                   [--install-root=<dir>] [--project-root=<dir>] [--rollback]
 *                   [--redistribute-only]
 *   env：AGENTDEV_RELEASE_BASE_URL（--base-url 缺省）；AGENTDEV_PROJECT_ROOT 已有语义沿用。
 *   stdout 末行 = 结构化 JSON 判定；exit 0 = 更新/up-to-date/回滚成功，1 = 拒绝/失败，2 = 用法错。
 * 依赖纪律：零第三方依赖（npm 经可注入 runner 子进程调用；下载经可注入 fetch）；Node >= 22。
 */
import { spawnSync } from "node:child_process";
import { createHash, verify as cryptoVerify } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import zlib from "node:zlib";

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));

/** 更新失败（可编程判别；CLI 折为 exit 1，用法错折 exit 2） */
export class UpdateError extends Error {
  constructor(message) {
    super(message);
    this.name = "UpdateError";
  }
}

/** manifest 结构版本（与 pack.mjs MANIFEST_VERSION 同步；客户端按版本判别） */
const MANIFEST_VERSION = "2026-09-30.1";
const SEMVER_PATTERN = /^\d+\.\d+\.\d+$/;

// ---------------------------------------------------------------------------
// 签名原语（自足副本——客户机包内无 rpo 依赖树；与 src/license/crypto.ts 同算法逐字实现）
// ---------------------------------------------------------------------------

/** 递归键排序后序列化（canonicalJson 逐字同构；漂移由跨实现 lockstep 测试锚定） */
export function canonicalJson(value) {
  if (Array.isArray(value)) {
    return JSON.stringify(value.map(canonicalJson));
  }
  if (value && typeof value === "object") {
    const entries = Object.entries(value)
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
      .map(([key, val]) => [key, JSON.parse(canonicalJson(val))]);
    return JSON.stringify(Object.fromEntries(entries));
  }
  return JSON.stringify(value);
}

/**
 * manifest 验签（M3）：剥 signature → canonicalJson → Ed25519 verify。
 * manifestVersion 必须是本脚本可判别的版本（结构漂移在验证前暴露，而不是验证出一个
 * 「语义不明的通过」）。
 */
export function verifyManifest(manifest, publicKeyPem) {
  if (!manifest || typeof manifest !== "object") return { ok: false, reason: "manifest is not an object" };
  if (manifest.manifestVersion !== MANIFEST_VERSION) {
    return { ok: false, reason: `unsupported manifestVersion: ${String(manifest.manifestVersion)} (client understands ${MANIFEST_VERSION})` };
  }
  const body = { ...manifest };
  const signature = body.signature;
  delete body.signature;
  if (typeof signature !== "string" || signature === "") return { ok: false, reason: "manifest has no signature" };
  if (typeof publicKeyPem !== "string" || publicKeyPem.trim() === "") {
    return { ok: false, reason: "no trust anchor available to verify the manifest" };
  }
  try {
    const ok = cryptoVerify(null, Buffer.from(canonicalJson(body), "utf8"), publicKeyPem, Buffer.from(signature, "base64"));
    return ok ? { ok: true, reason: null } : { ok: false, reason: "manifest signature does not verify under the embedded trust anchor (tamper or wrong channel)" };
  } catch (err) {
    return { ok: false, reason: `manifest signature verification failed: ${err instanceof Error ? err.message : String(err)}` };
  }
}

/**
 * 语义版本比较（单调性判定纯函数）：逐段数值比较，缺段补 0；
 * 非语义形态直接抛错——单调性绝不在不可排序的版本号上放行。
 */
export function compareVersions(a, b) {
  if (!SEMVER_PATTERN.test(a) || !SEMVER_PATTERN.test(b)) {
    throw new UpdateError(`versions must be semver x.y.z for monotonic comparison (got "${a}" vs "${b}")`);
  }
  const ka = a.split(".").map((n) => parseInt(n, 10));
  const kb = b.split(".").map((n) => parseInt(n, 10));
  for (let i = 0; i < 3; i++) {
    if (ka[i] !== kb[i]) return ka[i] < kb[i] ? -1 : 1;
  }
  return 0;
}

// ---------------------------------------------------------------------------
// tgz 读取器（零依赖 ustar + gunzip；安全解包）
// ---------------------------------------------------------------------------

/**
 * 解析 tgz → [{ name(posix), type, data }]。checksum 校验（完整性底线）；
 * pax/GNU 扩展条目（x/g/L/K）即拒——本发布面的 tgz 由 pack.mjs 自实现 ustar 产出，
 * 出现扩展条目说明来源不是发布方工具链（fail-closed）。
 */
export function parseTar(tgz) {
  let raw;
  try {
    raw = zlib.gunzipSync(tgz);
  } catch (err) {
    throw new UpdateError(`downloaded package is not valid gzip: ${err instanceof Error ? err.message : String(err)}`);
  }
  const entries = [];
  let offset = 0;
  while (offset + 512 <= raw.length) {
    const block = raw.subarray(offset, offset + 512);
    if (block.every((b) => b === 0)) break;
    // checksum：头 512 字节中 chksum 字段按空格计入求和
    let checksum = 0;
    for (let i = 0; i < 512; i++) checksum += i >= 148 && i < 156 ? 0x20 : block[i];
    const stored = parseInt(block.subarray(148, 156).toString("utf-8").replace(/\0.*$/, "").trim() || "0", 8);
    if (stored !== checksum) {
      throw new UpdateError(`tar checksum mismatch at offset ${offset} (stored ${stored}, computed ${checksum}) — package bytes are corrupt`);
    }
    const name = block.subarray(0, 100).toString("utf-8").replace(/\0.*$/, "");
    const prefix = block.subarray(345, 500).toString("utf-8").replace(/\0.*$/, "");
    const sizeText = block.subarray(124, 136).toString("utf-8").replace(/\0.*$/, "").trim();
    const size = parseInt(sizeText, 8) || 0;
    const type = block.subarray(156, 157).toString("utf-8") || "0";
    if ("xgLK".includes(type)) {
      throw new UpdateError(`unsupported tar entry type "${type}" (${name}) — release packages are plain ustar`);
    }
    offset += 512;
    if (type === "0" || type === "\0" || type === "5") {
      entries.push({
        name: prefix ? `${prefix}/${name}` : name,
        type: type === "5" ? "5" : "0",
        data: type === "5" ? Buffer.alloc(0) : Buffer.from(raw.subarray(offset, offset + size)),
      });
    }
    offset += Math.ceil(size / 512) * 512;
  }
  return entries;
}

/** 条目路径安全归一（zip-slip 防逃逸）：绝对/盘符/反斜杠/.. 一律拒绝 */
function safeJoin(rootDir, entryName) {
  if (entryName.includes("\\") || path.isAbsolute(entryName) || /^[a-zA-Z]:/.test(entryName)) {
    throw new UpdateError(`unsafe tar entry path rejected: ${entryName}`);
  }
  const parts = entryName.split("/");
  if (parts.includes("..")) {
    throw new UpdateError(`unsafe tar entry path escapes the install root: ${entryName}`);
  }
  const resolved = path.resolve(rootDir, ...parts);
  const normalizedRoot = path.resolve(rootDir);
  if (resolved !== normalizedRoot && !resolved.startsWith(normalizedRoot + path.sep)) {
    throw new UpdateError(`tar entry resolves outside the install root: ${entryName}`);
  }
  return resolved;
}

/** 解包 tgz 到 destDir（先整体解析+路径安全校验，再落盘）；返回落盘的相对路径集 */
export function extractTarSafe(tgz, destDir) {
  const entries = parseTar(tgz);
  const written = [];
  const planned = [];
  for (const entry of entries) {
    if (entry.name === "") continue;
    planned.push({ ...entry, dest: safeJoin(destDir, entry.name) });
  }
  for (const entry of planned) {
    if (entry.type === "5") {
      fs.mkdirSync(entry.dest, { recursive: true });
      continue;
    }
    fs.mkdirSync(path.dirname(entry.dest), { recursive: true });
    fs.writeFileSync(entry.dest, entry.data);
    written.push(entry.name);
  }
  return { written, entries: planned };
}

// ---------------------------------------------------------------------------
// 子流程
// ---------------------------------------------------------------------------

/** 读本地版本（非安装形态即拒——更新只对已安装的包有意义） */
function readLocalVersion(installRoot) {
  const pkgPath = path.join(installRoot, "package.json");
  if (!fs.existsSync(pkgPath)) {
    throw new UpdateError(`not an installed package: ${pkgPath} missing — updates apply to an existing commercial installation`);
  }
  let pkg;
  try {
    pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
  } catch (err) {
    throw new UpdateError(`installed package.json is not valid JSON: ${err instanceof Error ? err.message : String(err)}`);
  }
  if (typeof pkg.version !== "string" || !SEMVER_PATTERN.test(pkg.version)) {
    throw new UpdateError(`installed package.json has no semver version: "${pkg.version}"`);
  }
  return pkg.version;
}

/**
 * 信任锚解析（更新专用，M1 同纪律）：只认包内编译产物的内嵌公钥常量。
 * 为什么不走 resolvePublicKeyPem()：那是「内嵌优先 → env 兜底」的 license 语义，
 * 而更新信任锚绝不允许 env 兜底（攻击者设 env = 把验签钥换成自己的）。dev 形态
 * （常量为空）fail-closed——dev 安装不走商业更新通道。
 */
async function resolveUpdateTrustAnchor(installRoot) {
  const verifyJs = path.join(installRoot, "mcp", "src", "license", "verify.js");
  if (!fs.existsSync(verifyJs)) {
    throw new UpdateError(`embedded trust anchor module not found: ${verifyJs} — this does not look like a commercial installation`);
  }
  let mod;
  try {
    mod = await import(pathToFileURL(verifyJs).href);
  } catch (err) {
    throw new UpdateError(`cannot load trust anchor module: ${err instanceof Error ? err.message : String(err)}`);
  }
  const key = typeof mod.EMBEDDED_LICENSE_PUBLIC_KEY === "string" ? mod.EMBEDDED_LICENSE_PUBLIC_KEY : "";
  if (key.trim() === "") {
    throw new UpdateError(
      "embedded trust anchor is empty (dev-form installation) — updates verify release manifests against the key baked into the commercial build; env overrides are not honored by design",
    );
  }
  return key;
}

/** 默认下载器（Node >= 22 全局 fetch；404 语义由调用方判读） */
async function defaultFetchImpl(url) {
  return fetch(url);
}

async function downloadBytes(fetchImpl, url) {
  let response;
  try {
    response = await fetchImpl(url);
  } catch (err) {
    throw new UpdateError(`download failed: ${url} (${err instanceof Error ? err.message : String(err)})`);
  }
  if (!response || !response.ok) {
    throw new UpdateError(`download failed: ${url} (HTTP ${response?.status ?? "no response"}) — check the release base URL and that the version was published`);
  }
  return Buffer.from(await response.arrayBuffer());
}

/** 版本发现（O3）：列集取 max；index 缺失/畸形 fail-closed */
async function discoverLatestVersion(fetchImpl, baseUrl) {
  const raw = await downloadBytes(fetchImpl, `${baseUrl}releases/index.json`).catch(() => null);
  if (raw === null) {
    throw new UpdateError(
      `release index not reachable at ${baseUrl}releases/index.json — the publisher maintains it via rpo/publish-r2.mjs; pass --to-version to target a known version`,
    );
  }
  let index;
  try {
    index = JSON.parse(raw.toString("utf-8"));
  } catch {
    throw new UpdateError("releases/index.json is not valid JSON");
  }
  const versions = Array.isArray(index.versions) ? index.versions : [];
  if (versions.length === 0) throw new UpdateError("releases/index.json lists no versions");
  let latest = null;
  for (const version of versions) {
    if (typeof version !== "string" || !SEMVER_PATTERN.test(version)) {
      throw new UpdateError(`release index contains a non-semver version: "${version}"`);
    }
    if (latest === null || compareVersions(version, latest) > 0) latest = version;
  }
  return latest;
}

/** npm 子进程默认 runner（Windows .cmd 形态 + shell） */
function defaultRunNpm({ args, cwd }) {
  const cmd = process.platform === "win32" ? "npm.cmd" : "npm";
  const result = spawnSync(cmd, args, { cwd, encoding: "utf8", shell: process.platform === "win32" });
  if (result.error) {
    return { status: null, stdout: "", stderr: String(result.error.message ?? result.error) };
  }
  return { status: result.status, stdout: String(result.stdout ?? ""), stderr: String(result.stderr ?? "") };
}

/** 备份/恢复时的排除集（node_modules 重装可再生；.agentdev 是 license/台账域，不进备份） */
const BACKUP_EXCLUDES = new Set(["node_modules", ".agentdev"]);

function copyTreeFiltered(sourceDir, destDir) {
  fs.mkdirSync(destDir, { recursive: true });
  for (const entry of fs.readdirSync(sourceDir, { withFileTypes: true })) {
    if (BACKUP_EXCLUDES.has(entry.name)) continue;
    const from = path.join(sourceDir, entry.name);
    const to = path.join(destDir, entry.name);
    if (entry.isDirectory()) copyTreeFiltered(from, to);
    else if (entry.isFile()) fs.copyFileSync(from, to);
  }
}

function latestBackupDir(installRoot) {
  const backupRoot = path.join(installRoot, ".agentdev", "backup");
  if (!fs.existsSync(backupRoot)) return null;
  const stamps = fs.readdirSync(backupRoot).sort();
  const latest = stamps[stamps.length - 1];
  return latest ? path.join(backupRoot, latest) : null;
}

/** skills 重分发（zcode/codex skills 形态；commands 形态平台交回 distribute 脚本） */
function redistributeSkills(installRoot, projectRoot) {
  const sourceSkills = path.join(installRoot, "skills");
  if (!fs.existsSync(sourceSkills)) throw new UpdateError(`package skills directory missing: ${sourceSkills}`);
  const distributed = [];
  for (const platform of [".zcode", ".codex"]) {
    const targetRoot = path.join(projectRoot, platform, "skills");
    for (const entry of fs.readdirSync(sourceSkills, { withFileTypes: true })) {
      if (!entry.isDirectory() || !entry.name.startsWith("agentdev-")) continue;
      const from = path.join(sourceSkills, entry.name);
      const to = path.join(targetRoot, entry.name);
      fs.rmSync(to, { recursive: true, force: true });
      fs.cpSync(from, to, { recursive: true });
      distributed.push(path.join(platform, "skills", entry.name));
    }
  }
  return distributed;
}

function writeUpdateState(installRoot, record) {
  const stateDir = path.join(installRoot, ".agentdev");
  fs.mkdirSync(stateDir, { recursive: true });
  const statePath = path.join(stateDir, "update-state.json");
  let state = {};
  try {
    state = JSON.parse(fs.readFileSync(statePath, "utf-8"));
  } catch {
    state = {};
  }
  fs.writeFileSync(statePath, JSON.stringify({ ...state, ...record, updatedAt: new Date().toISOString() }, null, 2));
  return statePath;
}

// ---------------------------------------------------------------------------
// 主流程
// ---------------------------------------------------------------------------

/** 更新（程序化入口；CLI main 只是薄封装）。见文件头流程图；result.ok=false 时 reason 人读。 */
export async function runUpdate(options) {
  const {
    installRoot = SCRIPT_DIR,
    projectRoot,
    baseUrl = process.env.AGENTDEV_RELEASE_BASE_URL,
    fetchImpl = defaultFetchImpl,
    toVersion,
    runNpm = defaultRunNpm,
    log = (msg) => console.error(msg),
    redistributeOnly = false,
  } = options;

  const base = String(baseUrl ?? "").trim();
  const result = {
    ok: false,
    action: "update",
    fromVersion: null,
    toVersion: null,
    manifestVerified: false,
    sha256Ok: false,
    filesVerified: false,
    backupDir: null,
    npmCi: { ok: false },
    evidencePath: null,
    reason: null,
  };
  try {
    if (redistributeOnly) {
      if (!projectRoot) throw new UpdateError("--project-root is required for --redistribute-only");
      const fromVersion = readLocalVersion(installRoot);
      result.fromVersion = fromVersion;
      result.action = "update";
      const distributed = redistributeSkills(installRoot, projectRoot);
      log(`[redistribute] ${distributed.length} skill dir(s) → ${path.resolve(projectRoot)}`);
      result.ok = true;
      result.reason = `redistributed ${distributed.length} skill dir(s); commands-form platforms need distribute.sh/ps1 re-run`;
      return result;
    }
    if (base === "") {
      throw new UpdateError(
        "no release base URL: pass --base-url=<…> or set AGENTDEV_RELEASE_BASE_URL (the R2 public base that serves releases/)",
      );
    }
    const normalizedBase = base.endsWith("/") ? base : `${base}/`;

    // 1) 本地版本 + 更新信任锚（内嵌、且仅内嵌）
    const localVersion = readLocalVersion(installRoot);
    result.fromVersion = localVersion;
    const anchorPem = await resolveUpdateTrustAnchor(installRoot);

    // 2) 版本发现（O3 列集取 max；显式 toVersion 优先）
    const target = typeof toVersion === "string" && toVersion !== "" ? toVersion : await discoverLatestVersion(fetchImpl, normalizedBase);
    if (!SEMVER_PATTERN.test(target)) {
      throw new UpdateError(`--to-version must be semver x.y.z (got "${target}")`);
    }
    result.toVersion = target;

    // 3) 单调性（M4）：目标 < 本地 → 拒绝（版本回退攻击防御）；== 本地 → up-to-date
    const order = compareVersions(target, localVersion);
    if (order < 0) {
      result.reason =
        `monotonicity rejected: target ${target} is older than installed ${localVersion} ` +
        "(downgrades are refused as rollback-attack defense; use --rollback to restore a backup instead)";
      return result;
    }
    if (order === 0) {
      result.ok = true;
      result.action = "up-to-date";
      result.reason = `already at ${target}`;
      return result;
    }

    // 4) manifest 下载 + 验签（M3，内嵌锚）
    const manifestBytes = await downloadBytes(fetchImpl, `${normalizedBase}releases/latest-${target}.json`);
    let manifest;
    try {
      manifest = JSON.parse(manifestBytes.toString("utf-8"));
    } catch {
      throw new UpdateError("release manifest is not valid JSON");
    }
    const verdict = verifyManifest(manifest, anchorPem);
    if (!verdict.ok) {
      result.reason = `manifest verification failed: ${verdict.reason}`;
      return result;
    }
    result.manifestVerified = true;
    if (manifest.packageVersion !== target) {
      result.reason = `manifest packageVersion ${manifest.packageVersion} does not match requested ${target}`;
      return result;
    }

    // 5) 下载 tgz + sha256 校验（不符 → 拒装 + 留证）
    const packageBytes = await downloadBytes(fetchImpl, `${normalizedBase}releases/${target}/${manifest.packageFile}`);
    const observedSha = createHash("sha256").update(packageBytes).digest("hex");
    if (observedSha !== manifest.packageSha256) {
      const rejectedDir = path.join(installRoot, ".agentdev", "update-rejected");
      fs.mkdirSync(rejectedDir, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      const evidencePath = path.join(rejectedDir, `${stamp}-${manifest.packageFile}`);
      fs.writeFileSync(evidencePath, packageBytes);
      fs.writeFileSync(
        `${evidencePath}.evidence.json`,
        JSON.stringify({ url: `${normalizedBase}releases/${target}/${manifest.packageFile}`, expected: manifest.packageSha256, observed: observedSha, at: new Date().toISOString() }, null, 2),
      );
      result.evidencePath = evidencePath;
      result.reason = `sha256 mismatch for ${manifest.packageFile}: expected ${manifest.packageSha256.slice(0, 16)}… observed ${observedSha.slice(0, 16)}… — install refused, evidence kept at ${evidencePath}`;
      return result;
    }
    result.sha256Ok = true;

    // 6) 解包前干跑校验（路径安全 + 与 manifest 文件集双向对账——任何不一致都在落盘前暴露）
    const entries = parseTar(packageBytes);
    const tarFiles = entries.filter((e) => e.type === "0");
    const tarNames = new Set(tarFiles.map((e) => e.name));
    const manifestNames = new Set(manifest.files.map((f) => f.path));
    for (const entry of tarFiles) safeJoin(installRoot, entry.name); // zip-slip 提前爆
    const missingInTar = manifest.files.filter((f) => !tarNames.has(f.path));
    const extraInTar = tarFiles.filter((e) => !manifestNames.has(e.name));
    if (missingInTar.length > 0 || extraInTar.length > 0) {
      result.reason =
        "manifest/tgz file-set mismatch (refusing to install): " +
        [...missingInTar.map((f) => `manifest-only: ${f.path}`), ...extraInTar.map((e) => `tgz-only: ${e.name}`)].slice(0, 10).join("; ");
      return result;
    }
    const shaMismatch = manifest.files.filter((f) => {
      const entry = tarFiles.find((e) => e.name === f.path);
      return !entry || createHash("sha256").update(entry.data).digest("hex") !== f.sha256;
    });
    if (shaMismatch.length > 0) {
      result.reason = `per-file sha256 mismatch: ${shaMismatch.map((f) => f.path).slice(0, 5).join("; ")} — install refused`;
      return result;
    }

    // 7) 备份上一版（排除 node_modules/.agentdev；单代滚动）
    const previousBackup = latestBackupDir(installRoot);
    if (previousBackup) fs.rmSync(previousBackup, { recursive: true, force: true });
    const backupDir = path.join(installRoot, ".agentdev", "backup", new Date().toISOString().replace(/[:.]/g, "-"));
    copyTreeFiltered(installRoot, backupDir);
    result.backupDir = backupDir;
    log(`[backup] ${backupDir}`);

    // 8) 解包（覆盖式；包内容不含 .agentdev——负向清单保证 license 域零接触）
    extractTarSafe(packageBytes, installRoot);
    result.filesVerified = true;

    // 9) skills 重分发（项目根；commands 形态平台交回 distribute.sh/ps1）
    const effectiveProjectRoot = projectRoot ?? path.resolve(installRoot, "..");
    const distributed = redistributeSkills(installRoot, effectiveProjectRoot);
    log(`[redistribute] ${distributed.length} skill dir(s) → ${effectiveProjectRoot}`);

    // 10) npm ci（M7 lean 清单 + 随包 lockfile；失败 → 自动回滚）
    const npmResult = await runNpm({ args: ["ci"], cwd: installRoot });
    if (!npmResult || npmResult.status !== 0) {
      const restored = restoreBackup(installRoot, backupDir);
      result.reason =
        `npm ci failed (exit ${npmResult?.status}): ${(npmResult?.stderr ?? "").slice(-300)} — ` +
        `automatically rolled back to ${restored} (v1 updates require network for npm ci; retry when connectivity is restored)`;
      return result;
    }
    result.npmCi.ok = true;

    // 11) 版本回写（台账；安装内 package.json 的版本号已随解包更新）
    writeUpdateState(installRoot, {
      lastAction: "update",
      fromVersion: localVersion,
      toVersion: target,
      manifestPackageSha256: manifest.packageSha256,
      backupDir,
    });
    result.ok = true;
    result.action = "update";
    return result;
  } catch (err) {
    result.reason = err instanceof Error ? err.message : String(err);
    return result;
  }
}

/** 恢复备份到安装根（覆盖式还原；返回还原出的版本号） */
function restoreBackup(installRoot, backupDir) {
  for (const entry of fs.readdirSync(backupDir, { withFileTypes: true })) {
    const from = path.join(backupDir, entry.name);
    const to = path.join(installRoot, entry.name);
    if (entry.isDirectory()) {
      fs.rmSync(to, { recursive: true, force: true });
      fs.cpSync(from, to, { recursive: true });
    } else if (entry.isFile()) {
      fs.copyFileSync(from, to);
    }
  }
  try {
    return JSON.parse(fs.readFileSync(path.join(installRoot, "package.json"), "utf-8")).version ?? null;
  } catch {
    return null;
  }
}

/** 回滚（--rollback）：恢复最近一次备份 + 台账记录（license/台账域不进备份，天然不受影响） */
export function runRollback(options) {
  const { installRoot = SCRIPT_DIR, log = (msg) => console.error(msg) } = options;
  const backupDir = latestBackupDir(installRoot);
  if (!backupDir || !fs.existsSync(path.join(backupDir, "package.json"))) {
    throw new UpdateError(
      `no backup to roll back to under ${path.join(installRoot, ".agentdev", "backup")} — backups are created by successful update attempts`,
    );
  }
  const restoredVersion = restoreBackup(installRoot, backupDir);
  writeUpdateState(installRoot, { lastAction: "rollback", restoredVersion, backupDir });
  log(`[rollback] restored ${restoredVersion ?? "?"} from ${backupDir}`);
  log("[rollback] recommend re-running `npm ci` in the install root to rebuild node_modules for the restored lockfile");
  return { ok: true, action: "rollback", restoredVersion, backupDir };
}

// ---------------------------------------------------------------------------
// CLI 入口
// ---------------------------------------------------------------------------

function parseArgs(argv) {
  const out = {};
  for (const arg of argv.slice(2)) {
    const kv = /^--([\w-]+)=(.*)$/.exec(arg);
    if (kv) {
      out[kv[1]] = kv[2];
      continue;
    }
    const flag = /^--([\w-]+)$/.exec(arg);
    if (flag) out[flag[1]] = true;
  }
  return out;
}

async function main() {
  const args = parseArgs(process.argv);
  if (args.rollback === true) {
    try {
      const outcome = runRollback({
        installRoot: typeof args["install-root"] === "string" ? path.resolve(args["install-root"]) : undefined,
      });
      console.log(JSON.stringify({ ...outcome, reason: null }));
      process.exit(0);
    } catch (err) {
      console.error(`[update] FAIL: ${err instanceof Error ? err.message : String(err)}`);
      process.exit(1);
    }
  }
  const result = await runUpdate({
    installRoot: typeof args["install-root"] === "string" ? path.resolve(args["install-root"]) : undefined,
    projectRoot: typeof args["project-root"] === "string" ? path.resolve(args["project-root"]) : undefined,
    baseUrl: typeof args["base-url"] === "string" ? args["base-url"] : undefined,
    toVersion: typeof args["to-version"] === "string" ? args["to-version"] : undefined,
    redistributeOnly: args["redistribute-only"] === true,
  });
  console.log(JSON.stringify(result));
  process.exit(result.ok ? 0 : 1);
}

// 直跑守卫：字面对拍优先，失配退回 realpath 对拍（macOS $TMPDIR 符号链接环境下纯字面
// 对拍恒失配 → CLI 静默空跑；Node 默认按 realpath 装载模块而 argv[1] 保持调用形态）。
// 与 templates/*.mjs 同款；详见 docs/platform-notes.md PN-1。
function isDirectRun() {
  const invoked = path.resolve(process.argv[1]);
  const self = fileURLToPath(import.meta.url);
  if (invoked === self) return true;
  try {
    return fs.realpathSync(invoked) === fs.realpathSync(self);
  } catch {
    return false;
  }
}

if (process.argv[1] && isDirectRun()) {
  main();
}
