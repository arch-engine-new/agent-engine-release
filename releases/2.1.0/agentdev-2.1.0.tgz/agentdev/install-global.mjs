#!/usr/bin/env node
/**
 * install-global.mjs - agentdev 本机用户级安装（install.sh / install.ps1 的零依赖核心）。
 *
 * 与 install-into.mjs（项目级）互补：本项目级装进单个目标项目，本脚本把 agentdev
 * 装到「这台机器的用户级」，一次安装、任意项目可用（brief: install-global Task）：
 *   1. MCP 注册：按 --ide 把 agentdev/distribute/mcp-configs/ 模板（字段形态真源）
 *      渲染后合并进各平台**用户级**配置——合并不覆盖（既有其它 server/用户状态保留，
 *      已有 agentdev-mcp 就地更新）；JSON 解析失败 fail-closed 报错不写。
 *   2. 八命令分发：agentdev/skills/agentdev-* → 各平台**用户级**命令目录，形态规则同
 *      distribute.sh（zcode/codex=skills 形态原样拷目录；claude/cursor/qoder/opencode/trae
 *      =commands 形态删 frontmatter name 行落 <name>.md）。只碰 agentdev-* 前缀。
 *   3. 冒烟验证（--smoke）：以用户级条目原样拉起 agentdev-mcp 子进程，裸 stdio 走真实
 *      initialize → tools/list，断言 7 注册工具在场。
 *
 * 与项目级的关键差异（用户级语义）：
 *   - **不设 AGENTDEV_PROJECT_ROOT**：用户级注册是全机共享的，项目根由运行时 cwd 上溯
 *     .agentdev/ 标记发现（mcp/src/paths.ts 最高优先级 env 之下的兜底通道）——模板里的
 *     env.AGENTDEV_PROJECT_ROOT 在用户级渲染时剥除。
 *   - **备份先行**：改写任何既有配置文件前，先落 `<file>.agentdev-bak-<ts>` 原文备份，
 *     升级/卸载同语义；--dry-run 不写备份（不落盘）。
 *   - **--uninstall**：只摘 agentdev-mcp 注册与 agentdev-* 全局命令，其它条目原样保留。
 *
 * 各平台用户级位置选型（官方惯例，详见 .apt/orchestration/install-global-report.md）：
 *   claude  → ~/.claude.json 顶层 mcpServers（Claude Code user scope 官方定义）
 *   cursor  → ~/.cursor/mcp.json（Cursor 全局 MCP 官方位）
 *   zcode   → ~/.zcode/mcp.json（ZCode 全局 MCP 位）
 *   codex   → <CODEX_HOME|~/.codex>/config.toml（codex 无项目级 MCP，本就用户级）
 *   opencode→ ~/.config/opencode/opencode.json 的 mcp 段（XDG 全局配置官方位）
 *   qoder   → ~/.qoder/mcp.json（Qoder 全局 MCP 位）
 *   trae    → ~/.trae/mcp.json（Trae 全局 MCP 位）
 *
 * 用法：
 *   node agentdev/install-global.mjs [--ide=cursor|claude|zcode|codex|opencode|qoder|trae|all]
 *     [--repo-root=<agent-engine仓根>] [--dry-run] [--uninstall] [--smoke]
 *
 * 布局自适应（v2.1.0 随商业包原样分发）：包根 mcp/src/index.js 编译入口在位 = 商业包
 * 布局（skills/、distribute/ 在包根，注册/冒烟入口 = 编译产物 node 直跑）；否则 = 本仓
 * 开发布局（agentdev/* 嵌套 + tsx 直跑）。install.sh / install.ps1 是本脚本的本机安装
 * 包装（node 检查 → 依赖安装 → 本脚本 → 冒烟），商业包内位于包根。
 *
 * Contract：
 *   - 零依赖（仅 node:fs/path/os/child_process/url），Node >= 22（replaceAll/cpSync）。
 *   - 两阶段执行：先全量读取+校验+计算写计划（所有 fail-closed 错误在此抛出），后统一
 *     落盘——「报错不写」是全盘语义：任何一处目标 JSON 损坏，则一个文件都不写。
 *   - 幂等：重跑安全——JSON 合并 in-place 更新 agentdev-mcp 条目；TOML 段替换/追加；
 *     skills 升级即重分发；卸载重复执行不报错。
 *   - 隔离缝：用户主目录经 USERPROFILE || HOME 解析（测试注入临时目录），codex 经
 *     CODEX_HOME 官方重定向语义——测试绝不触碰本机真实用户级配置。
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const EXIT_OK = 0;
const EXIT_FAIL = 1; // 运行失败（源损坏 / 目标 JSON 解析失败 / 冒烟握手失败等 fail-closed）
const EXIT_USAGE = 2; // 用法/环境错误（未知 --ide、Node < 22、非法参数组合）

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const defaultRepoRoot = path.resolve(scriptDir, ".."); // 脚本在 <repo>/agentdev/ 下

/** MCP server 条目名（check-namespace.js 同款纪律：模板里的条目名必须等于它） */
const SERVER_KEY = "agentdev-mcp";

/** 冒烟握手期望的注册工具（与 mcp-configs/README.md 校验清单同一份契约） */
const EXPECTED_TOOLS = [
  "ping",
  "license_status",
  "agent_scaffold",
  "agent_eval_run",
  "agentdev_status",
  "agentdev_signoff",
  "agentdev_deploy",
].sort();

/** 冒烟握手整体看门狗（tsx 冷启动 + 两轮往返，富余量） */
const SMOKE_TIMEOUT_MS = 90_000;

/**
 * 平台注册表（用户级）：MCP 安装位置（模板文件 + 目标路径 + 配置形态）× 命令分发形态。
 * 模板与 install-into.mjs 共用 agentdev/distribute/mcp-configs/（字段形态真源）；
 * 目标路径全部锚在用户主目录（区别于项目级锚在 <project>）。
 */
const PLATFORMS = {
  claude: {
    template: "claude-code.mcp.json",
    mcpTarget: (home) => path.join(home, ".claude.json"),
    commandsRoot: (home) => path.join(home, ".claude", "commands"),
    toml: false,
    commandForm: "commands",
  },
  cursor: {
    template: "cursor.mcp.json",
    mcpTarget: (home) => path.join(home, ".cursor", "mcp.json"),
    commandsRoot: (home) => path.join(home, ".cursor", "commands"),
    toml: false,
    commandForm: "commands",
  },
  zcode: {
    template: "zcode.mcp.json",
    mcpTarget: (home) => path.join(home, ".zcode", "mcp.json"),
    commandsRoot: (home) => path.join(home, ".zcode", "skills"),
    toml: false,
    commandForm: "skills",
  },
  codex: {
    template: "codex.config.toml",
    mcpTarget: null, // 经 codexHome()（CODEX_HOME 官方重定向语义优先）
    commandsRoot: (home) => path.join(home, ".codex", "skills"),
    toml: true,
    commandForm: "skills",
  },
  opencode: {
    template: "opencode.json",
    mcpTarget: (home) => path.join(home, ".config", "opencode", "opencode.json"),
    commandsRoot: (home) => path.join(home, ".config", "opencode", "commands"),
    toml: false,
    commandForm: "commands",
  },
  qoder: {
    template: "qoder.mcp.json",
    mcpTarget: (home) => path.join(home, ".qoder", "mcp.json"),
    commandsRoot: (home) => path.join(home, ".qoder", "commands"),
    toml: false,
    commandForm: "commands",
  },
  trae: {
    template: "trae.mcp.json",
    mcpTarget: (home) => path.join(home, ".trae", "mcp.json"),
    commandsRoot: (home) => path.join(home, ".trae", "commands"),
    toml: false,
    commandForm: "commands",
  },
};
const ALL_PLATFORMS = Object.keys(PLATFORMS);

/** Node >= 22 硬门槛（replaceAll/cpSync 等依赖；sh/ps1 已先行检查，这里是双保险） */
const nodeMajor = Number(process.versions.node.split(".")[0]);
if (!Number.isFinite(nodeMajor) || nodeMajor < 22) {
  console.error(`ERROR: install-global: 需要 Node >= 22，当前 ${process.versions.node}。安装指引：https://nodejs.org/`);
  process.exit(EXIT_USAGE);
}

/** 用户主目录：USERPROFILE 优先（win32），HOME 兜底（posix）——测试注入临时目录的解析缝 */
function userHome() {
  return process.env.USERPROFILE || process.env.HOME || os.homedir();
}

/** codex 用户级配置目录：CODEX_HOME 官方重定向语义优先（测试隔离缝），缺省 ~/.codex */
function codexHome() {
  return process.env.CODEX_HOME || path.join(userHome(), ".codex");
}

function toPosix(p) {
  return p.split(path.sep).join("/");
}

function usage(message) {
  if (message) console.error(`ERROR: install-global: ${message}`);
  console.error(
    `用法: node install-global.mjs [--ide=${ALL_PLATFORMS.join("|")}|all]` +
      ` [--repo-root=<agent-engine仓根>] [--dry-run] [--uninstall] [--smoke]`,
  );
  process.exit(EXIT_USAGE);
}

function fail(message) {
  console.error(`ERROR: install-global: ${message}`);
  process.exit(EXIT_FAIL);
}

// ---------------------------------------------------------------------------
// 参数解析（未知参数即用法错误；--smoke 与 --uninstall 互斥）
// ---------------------------------------------------------------------------
let ideArg = "all";
let repoRootArg = null;
let dryRun = false;
let uninstall = false;
let smoke = false;

for (const arg of process.argv.slice(2)) {
  if (arg.startsWith("--ide=")) ideArg = arg.slice("--ide=".length);
  else if (arg.startsWith("--repo-root=")) repoRootArg = arg.slice("--repo-root=".length);
  else if (arg === "--dry-run") dryRun = true;
  else if (arg === "--uninstall") uninstall = true;
  else if (arg === "--smoke") smoke = true;
  else usage(`未知参数: ${arg}（支持 --ide= / --repo-root= / --dry-run / --uninstall / --smoke）`);
}

if (ideArg !== "all" && !ALL_PLATFORMS.includes(ideArg)) {
  usage(`未知 --ide=${ideArg}（支持 ${ALL_PLATFORMS.join("|")}|all）`);
}
if (smoke && uninstall) usage("--smoke 与 --uninstall 不能同用");

const repoRoot = path.resolve(repoRootArg || defaultRepoRoot);

/**
 * 布局自适应（v2.1.0 商业包随包同一份脚本）：包根编译入口 <root>/mcp/src/index.js 在位 =
 * 商业包布局（skills/、distribute/ 提升到包根，MCP 入口为编译产物 node 直跑——包内无
 * tsx 与 ts 源）；否则 = agent-engine 仓开发布局（agentdev/* 嵌套 + tsx 直跑 src/index.ts）。
 * 探测锚选编译入口：pack 对包内 mcp/src/index.js 是 fail-closed 断言（必有），仓根不存在
 * mcp/ 目录——两布局互斥零误判。pack 对本脚本零改写原样随包，行为分叉全由本探测承载。
 */
const packageEntryJs = path.join(repoRoot, "mcp", "src", "index.js");
const packageLayout = fs.existsSync(packageEntryJs);
const packageEntryPosix = toPosix(packageEntryJs);

const srcSkillsDir = path.join(repoRoot, ...(packageLayout ? ["skills"] : ["agentdev", "skills"]));
const mcpConfigsDir = path.join(repoRoot, ...(packageLayout ? ["distribute", "mcp-configs"] : ["agentdev", "distribute", "mcp-configs"]));
const tsxCli = path.join(repoRoot, "agentdev", "mcp", "node_modules", "tsx", "dist", "cli.mjs");
const mcpEntry = path.join(repoRoot, "agentdev", "mcp", "src", "index.ts");

// 正斜杠化后仍可能含引号/反斜杠的路径无法安全进 TOML 基本字符串——fail-closed 而非写出坏配置
const repoRootPosix = toPosix(repoRoot);
if (repoRootPosix.includes('"') || repoRootPosix.includes("\\")) {
  fail(`repo-root 路径含 "${repoRootPosix.includes('"') ? '"' : "\\"}" 字符，无法安全写入 codex TOML: ${repoRootPosix}`);
}

const selectedPlatforms = ideArg === "all" ? ALL_PLATFORMS : [ideArg];

// ---------------------------------------------------------------------------
// --smoke：stdio boot initialize 握手（裸启动：无 AGENTDEV_PROJECT_ROOT，中性 cwd）
// ---------------------------------------------------------------------------
function childEnvClean(extra) {
  // 剥 VITEST*（index.ts isDirectRun 守卫会在 VITEST 下静默不启动，e2e helpers 同款纪律）；
  // 剥 AGENTDEV_PROJECT_ROOT（冒烟要证明用户级裸启动可用）。extra 显式值最后合并。
  const clean = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined && !key.startsWith("VITEST") && key !== "AGENTDEV_PROJECT_ROOT") {
      clean[key] = value;
    }
  }
  return { ...clean, ...extra };
}

/** 冒烟握手（异步 I/O）：resolve=全工具在场；reject=任何失败。调用方须 await（见底部派发） */
function runSmoke() {
  if (packageLayout) {
    // 商业包布局：入口 = 包根编译产物（依赖由包根 npm ci 按 lockfile 提供）
    if (!fs.existsSync(packageEntryJs)) {
      fail(`MCP 入口缺失（商业包布局要求 <安装根>/mcp/src/index.js，先在包根 npm ci）：${packageEntryJs}`);
    }
  } else if (!fs.existsSync(tsxCli) || !fs.existsSync(mcpEntry)) {
    fail(`MCP 入口缺失（先在 agentdev/mcp 下 npm ci）：${tsxCli} / ${mcpEntry}`);
  }
  return new Promise((resolve, reject) => {
  const cwd = fs.mkdtempSync(path.join(os.tmpdir(), "agentdev-smoke-"));
  const child = spawn(process.execPath, packageLayout ? [packageEntryJs] : [tsxCli, mcpEntry], {
    cwd,
    env: childEnvClean({}),
    stdio: ["pipe", "pipe", "pipe"],
  });

  let buffer = "";
  let stderrBuf = "";
  let settled = false;

  const timer = setTimeout(() => finish(false, `握手超时（>${SMOKE_TIMEOUT_MS}ms）。stderr: ${stderrBuf.trim()}`), SMOKE_TIMEOUT_MS);

  function finish(ok, message) {
    if (settled) return;
    settled = true;
    clearTimeout(timer);
    child.kill();
    try {
      fs.rmSync(cwd, { recursive: true, force: true });
    } catch {
      /* 临时目录清理失败不影响结论 */
    }
    if (ok) resolve();
    else reject(new Error(message));
  }

  function send(obj) {
    child.stdin.write(JSON.stringify(obj) + "\n");
  }

  child.on("error", (err) => finish(false, `子进程拉起失败: ${err.message}`));
  child.stderr.on("data", (chunk) => {
    stderrBuf += chunk;
  });
  child.stdout.on("data", (chunk) => {
    buffer += chunk;
    let idx;
    while ((idx = buffer.indexOf("\n")) >= 0) {
      const line = buffer.slice(0, idx).trim();
      buffer = buffer.slice(idx + 1);
      if (!line) continue;
      let msg;
      try {
        msg = JSON.parse(line);
      } catch {
        continue; // 非JSON行忽略（server 不应输出，防御性跳过）
      }
      if (msg.id === 1 && msg.result) {
        const serverInfo = msg.result.serverInfo?.name;
        if (serverInfo !== SERVER_KEY) finish(false, `initialize 回包 serverInfo.name=${serverInfo}，期望 ${SERVER_KEY}`);
        send({ jsonrpc: "2.0", method: "notifications/initialized" });
        send({ jsonrpc: "2.0", id: 2, method: "tools/list" });
      } else if (msg.id === 2 && msg.result) {
        const tools = (msg.result.tools ?? []).map((t) => t.name).sort();
        const missing = EXPECTED_TOOLS.filter((t) => !tools.includes(t));
        if (missing.length > 0) finish(false, `tools/list 缺注册工具: ${missing.join(", ")}（实得 ${tools.join(", ")}）`);
        finish(true);
      } else if (msg.id === 1 || msg.id === 2) {
        finish(false, `JSON-RPC 错误回包: ${JSON.stringify(msg.error ?? msg)}`);
      }
    }
  });
  child.on("exit", (code) => {
    // 未落定时子进程退出一律判负（含 initialized 已发但 tools/list 未回的情形，杜绝静默漏判）
    if (!settled) finish(false, `子进程提前退出（code=${code}）。stderr: ${stderrBuf.trim()}`);
  });

  // initialize 请求（协议版本对齐 SDK 支持集；SDK 以自身版本回包）
  send({
    jsonrpc: "2.0",
    id: 1,
    method: "initialize",
    params: {
      protocolVersion: "2024-11-05",
      capabilities: {},
      clientInfo: { name: "agentdev-install-global", version: "0.1.0" },
    },
  });
  }); // end new Promise
}

if (smoke) {
  // 顶层 await：握手是异步 I/O，必须等它落定再放行后续（否则同步安装流会抢跑并 exit——
  // 这正是首版「--smoke 却整装了一遍」的根因）。冒烟只跑握手，不安装不卸载。
  try {
    await runSmoke();
  } catch (err) {
    fail(`冒烟握手失败：${err && err.message ? err.message : String(err)}`);
  }
  console.log(`OK [smoke] stdio boot 握手成功：initialize → tools/list = ${EXPECTED_TOOLS.length} 注册工具（${EXPECTED_TOOLS.join(", ")}）`);
  process.exit(EXIT_OK);
}

// ---------------------------------------------------------------------------
// 源完整性：skills 源（八命令）+ MCP 模板（字段形态真源）
// ---------------------------------------------------------------------------
let skillDirs = fs
  .readdirSync(srcSkillsDir, { withFileTypes: true })
  .filter((e) => e.isDirectory() && e.name.startsWith("agentdev-"))
  .map((e) => e.name)
  .sort();
if (skillDirs.length === 0) {
  fail(`agentdev/skills 下没有 agentdev-* 目录——源不完整: ${srcSkillsDir}`);
}

const skillBodies = new Map(); // name → SKILL.md 原文（commands 形态变换用）
for (const name of skillDirs) {
  const skillPath = path.join(srcSkillsDir, name, "SKILL.md");
  if (!fs.existsSync(skillPath)) fail(`skills 源缺 SKILL.md: ${skillPath}`);
  skillBodies.set(name, fs.readFileSync(skillPath, "utf-8"));
}

/** 读模板 JSON 并抽出 server 条目（mcpServers / mcp 容器键由模板本体决定；install-into 同构） */
function loadJsonTemplate(templateFile) {
  const raw = fs.readFileSync(path.join(mcpConfigsDir, templateFile), "utf-8");
  let doc;
  try {
    doc = JSON.parse(raw);
  } catch (err) {
    fail(`MCP 模板不是合法 JSON（模板被改动？）: ${templateFile}（${err.message}）`);
  }
  const containerKey = doc.mcpServers ? "mcpServers" : doc.mcp ? "mcp" : null;
  if (!containerKey || !doc[containerKey][SERVER_KEY]) {
    fail(`MCP 模板缺 ${containerKey ?? "mcpServers|mcp"}.${SERVER_KEY} 条目（模板被改动？）: ${templateFile}`);
  }
  if (Object.keys(doc[containerKey])[0] !== SERVER_KEY) {
    fail(`MCP 模板 server 条目名不是 ${SERVER_KEY}（命名空间纪律）: ${templateFile}`);
  }
  return { containerKey, entry: doc[containerKey][SERVER_KEY] };
}

/** 读 codex 模板并抽出 [mcp_servers.agentdev-mcp] 块行（模板顶部注释行不参与安装） */
function loadCodexTemplateLines() {
  const raw = fs.readFileSync(path.join(mcpConfigsDir, "codex.config.toml"), "utf-8");
  const lines = raw.split(/\r?\n/);
  const start = lines.findIndex((l) => /^\[mcp_servers\.agentdev-mcp\]\s*$/.test(l));
  if (start < 0) fail("codex 模板缺 [mcp_servers.agentdev-mcp] 段（模板被改动？）");
  return lines.slice(start);
}

/**
 * 用户级条目渲染：占位符 → 本仓根；**剥除 AGENTDEV_PROJECT_ROOT**（与项目级的本质差异：
 * 用户级注册全机共享，项目根由运行时 cwd 上溯 .agentdev/ 标记发现，paths.ts 兜底通道）。
 * env/environment 因此清空时整个键摘除，保持条目最小形态。
 */
function renderJsonEntry(entry) {
  const rendered = JSON.parse(JSON.stringify(entry).replaceAll("__AGENTDEV_REPO_ROOT__", repoRootPosix));
  for (const envKey of ["env", "environment"]) {
    if (rendered[envKey] && typeof rendered[envKey] === "object") {
      delete rendered[envKey].AGENTDEV_PROJECT_ROOT;
      if (Object.keys(rendered[envKey]).length === 0) delete rendered[envKey];
    }
  }
  return rendered;
}

/**
 * 商业包布局的条目修正：模板 args 载的是开发态 tsx 入口（包内无 tsx 与 ts 源，必然失效），
 * 注册一律改指编译产物 node 直跑（command 恒 node；AGENTDEV_PROJECT_ROOT 的剥除仍由
 * renderJsonEntry 统一承担）。仓开发布局原样透传。
 */
function withPackageEntry(entry) {
  if (!packageLayout) return entry;
  return { ...entry, command: "node", args: [packageEntryPosix] };
}

/** 用户级 codex 块渲染：剥 env 行（AGENTDEV_PROJECT_ROOT 载体）+ 占位符 → 本仓根 */
function renderCodexBlock() {
  if (packageLayout) {
    // 商业包布局：块从编译入口直接推导（dev 模板 tsx args 在包内不成立）；形态仍守
    // check-namespace 校验器的受控子集（command 字符串 + args 字符串数组，零 env）。
    return ["[mcp_servers.agentdev-mcp]", 'command = "node"', `args = ["${packageEntryPosix}"]`].join("\n");
  }
  const lines = loadCodexTemplateLines().filter((l) => !/^env\s*=/.test(l.trim()));
  return lines.join("\n").replaceAll("__AGENTDEV_REPO_ROOT__", repoRootPosix).trimEnd();
}

/** commands 形态变换（与 distribute.sh awk / check-namespace toCommandBody 逐字节同构） */
function toCommandBody(markdown) {
  const lines = markdown.split(/\r?\n/);
  const out = [];
  let inFrontmatter = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (i === 0 && line === "---") { inFrontmatter = true; out.push(line); continue; }
    if (inFrontmatter && line === "---") { inFrontmatter = false; out.push(line); continue; }
    if (inFrontmatter && /^name:\s/.test(line)) continue;
    out.push(line);
  }
  if (out.length > 1 && out[out.length - 1] === "" && markdown.endsWith("\n")) out.pop();
  return out.join("\n") + (markdown.endsWith("\n") ? "\n" : "");
}

// ---------------------------------------------------------------------------
// 阶段一：计算写计划（所有读取/校验在此完成；任何 fail-closed 错误 → 不写任何文件）
// ---------------------------------------------------------------------------
/** 写计划项：{kind:"write",path,content} | {kind:"copyDir",src,dst} | {kind:"rmDir",path} | {kind:"rmFile",path} */
const plan = [];
const failures = [];
const reportLines = [];

/** codex 的 MCP 目标路径（toml 平台专用） */
function codexTomlPath() {
  return path.join(codexHome(), "config.toml");
}

function planJsonMerge(platform) {
  const spec = PLATFORMS[platform];
  const { containerKey, entry } = loadJsonTemplate(spec.template);
  const targetPath = spec.mcpTarget(userHome());
  const rendered = renderJsonEntry(withPackageEntry(entry));

  let doc = {};
  if (fs.existsSync(targetPath)) {
    const raw = fs.readFileSync(targetPath, "utf-8");
    try {
      doc = JSON.parse(raw);
    } catch (err) {
      failures.push(`既有配置 JSON 解析失败，fail-closed 不写: ${toPosix(targetPath)}（${err.message}）`);
      return;
    }
    if (typeof doc !== "object" || doc === null || Array.isArray(doc)) {
      failures.push(`既有配置不是 JSON 对象，无法合并: ${toPosix(targetPath)}`);
      return;
    }
  }
  if (doc[containerKey] === undefined) doc[containerKey] = {};
  const container = doc[containerKey];
  if (typeof container !== "object" || Array.isArray(container)) {
    failures.push(`既有配置的 ${containerKey} 段不是对象，无法合并: ${toPosix(targetPath)}`);
    return;
  }
  const verb = Object.prototype.hasOwnProperty.call(container, SERVER_KEY) ? "updated" : "merged";
  container[SERVER_KEY] = rendered;
  plan.push({ kind: "write", path: targetPath, content: JSON.stringify(doc, null, 2) + "\n" });
  reportLines.push({ platform, text: `${toPosix(targetPath)}: ${SERVER_KEY} 已注册（${verb}）` });
}

function planTomlMerge() {
  const targetPath = codexTomlPath();
  const block = renderCodexBlock();
  let content;
  let verb;
  if (fs.existsSync(targetPath)) {
    const text = fs.readFileSync(targetPath, "utf-8");
    const lines = text.split(/\r?\n/);
    const start = lines.findIndex((l) => /^\[mcp_servers\.agentdev-mcp\]\s*$/.test(l));
    if (start >= 0) {
      // 段替换：只动本工具自己的段（到下一个顶层段头/表数组头或 EOF），其余逐字节保留
      let end = lines.length;
      for (let i = start + 1; i < lines.length; i++) {
        if (/^\[\[?[^\]]*\]\]?\s*$/.test(lines[i])) { end = i; break; }
      }
      lines.splice(start, end - start, ...block.split("\n"));
      content = lines.join("\n");
      verb = "updated";
    } else {
      // 追加：既有内容与新区块之间恰留一个空行
      const sep = text.endsWith("\n\n") ? "" : text.endsWith("\n") ? "\n" : "\n\n";
      content = text + sep + block + "\n";
      verb = "appended";
    }
  } else {
    content = block + "\n";
    verb = "created";
  }
  if (!content.endsWith("\n")) content += "\n";
  plan.push({ kind: "write", path: targetPath, content });
  reportLines.push({ platform: "codex", text: `${toPosix(targetPath)}: ${SERVER_KEY} 已注册（${verb}）` });
}

function planJsonUninstall(platform) {
  const spec = PLATFORMS[platform];
  const { containerKey } = loadJsonTemplate(spec.template);
  const targetPath = spec.mcpTarget(userHome());
  if (!fs.existsSync(targetPath)) {
    reportLines.push({ platform, text: `${toPosix(targetPath)}: 不存在，跳过` });
    return;
  }
  let doc;
  try {
    doc = JSON.parse(fs.readFileSync(targetPath, "utf-8"));
  } catch (err) {
    failures.push(`既有配置 JSON 解析失败，fail-closed 不动: ${toPosix(targetPath)}（${err.message}）`);
    return;
  }
  const container = doc?.[containerKey];
  if (!container || typeof container !== "object" || Array.isArray(container) || !(SERVER_KEY in container)) {
    reportLines.push({ platform, text: `${toPosix(targetPath)}: 无 ${SERVER_KEY} 条目，跳过` });
    return;
  }
  delete container[SERVER_KEY];
  plan.push({ kind: "write", path: targetPath, content: JSON.stringify(doc, null, 2) + "\n" });
  reportLines.push({ platform, text: `${toPosix(targetPath)}: ${SERVER_KEY} 已摘除（其余条目保留）` });
}

function planTomlUninstall() {
  const targetPath = codexTomlPath();
  if (!fs.existsSync(targetPath)) {
    reportLines.push({ platform: "codex", text: `${toPosix(targetPath)}: 不存在，跳过` });
    return;
  }
  const lines = fs.readFileSync(targetPath, "utf-8").split(/\r?\n/);
  const start = lines.findIndex((l) => /^\[mcp_servers\.agentdev-mcp\]\s*$/.test(l));
  if (start < 0) {
    reportLines.push({ platform: "codex", text: `${toPosix(targetPath)}: 无 ${SERVER_KEY} 段，跳过` });
    return;
  }
  let end = lines.length;
  for (let i = start + 1; i < lines.length; i++) {
    if (/^\[\[?[^\]]*\]\]?\s*$/.test(lines[i])) { end = i; break; }
  }
  lines.splice(start, end - start);
  let content = lines.join("\n").replace(/\n+$/, "\n"); // 段摘除后的尾随空行归一
  if (content.trim() === "") content = "";
  plan.push({ kind: "write", path: targetPath, content });
  reportLines.push({ platform: "codex", text: `${toPosix(targetPath)}: ${SERVER_KEY} 段已摘除（其余内容逐字节保留）` });
}

/** 列用户级命令目录里的 agentdev-* 条目（卸载按目标实况枚举，陈旧产物一并摘除） */
function listAgentdevEntries(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .filter((e) => e.name.startsWith("agentdev-"))
    .map((e) => ({ name: e.name, dir: e.isDirectory() }));
}

function planCommandsInstall(platform) {
  const spec = PLATFORMS[platform];
  const dstDir = spec.commandsRoot(userHome());
  for (const name of skillDirs) {
    plan.push({ kind: "write", path: path.join(dstDir, `${name}.md`), content: toCommandBody(skillBodies.get(name)) });
  }
  reportLines.push({ platform, text: `${toPosix(dstDir)}: ${skillDirs.length} 个 agentdev-* commands` });
}

function planSkillsInstall(platform) {
  const spec = PLATFORMS[platform];
  const dstRoot = spec.commandsRoot(userHome());
  for (const name of skillDirs) {
    plan.push({ kind: "copyDir", src: path.join(srcSkillsDir, name), dst: path.join(dstRoot, name) });
  }
  reportLines.push({ platform, text: `${toPosix(dstRoot)}: ${skillDirs.length} 个 agentdev-* skills` });
}

function planCommandsUninstall(platform) {
  const spec = PLATFORMS[platform];
  const dstDir = spec.commandsRoot(userHome());
  const entries = listAgentdevEntries(dstDir);
  for (const entry of entries) {
    plan.push(entry.dir ? { kind: "rmDir", path: path.join(dstDir, entry.name) } : { kind: "rmFile", path: path.join(dstDir, entry.name) });
  }
  reportLines.push({
    platform,
    text: entries.length > 0 ? `${toPosix(dstDir)}: 摘除 ${entries.length} 个 agentdev-* 条目` : `${toPosix(dstDir)}: 无 agentdev-* 条目，跳过`,
  });
}

for (const platform of selectedPlatforms) {
  const spec = PLATFORMS[platform];
  if (uninstall) {
    if (spec.toml) planTomlUninstall();
    else planJsonUninstall(platform);
    planCommandsUninstall(platform);
  } else {
    if (spec.toml) planTomlMerge();
    else planJsonMerge(platform);
    if (spec.commandForm === "skills") planSkillsInstall(platform);
    else planCommandsInstall(platform);
  }
}

if (failures.length > 0) {
  console.error(`install-global: FAIL（${failures.length} 项，未写任何文件）`);
  for (const message of failures) console.error(`  - ${message}`);
  process.exit(EXIT_FAIL);
}

// 源完整性附加提示（不阻断）：用户级条目指向仓内 tsx 开发态入口，依赖 node_modules
// （商业包布局条目指向包内编译产物，无此依赖——提示仅属仓开发布局）
const tsxMissing = !packageLayout && !fs.existsSync(tsxCli);

// ---------------------------------------------------------------------------
// 阶段二：落盘（dry-run 到此为止；改写既有文件前一律先备份原文）
// ---------------------------------------------------------------------------
if (dryRun) {
  console.log(`install-global: dry-run 预览（不落盘）${uninstall ? " [uninstall]" : ""}`);
  for (const op of plan) {
    if (op.kind === "write") console.log(`DRY write ${toPosix(op.path)}`);
    else if (op.kind === "copyDir") console.log(`DRY copy  ${toPosix(op.dst)}/ ← agentdev/skills/${path.basename(op.src)}/`);
    else if (op.kind === "rmDir") console.log(`DRY rmdir ${toPosix(op.path)}/`);
    else if (op.kind === "rmFile") console.log(`DRY rm    ${toPosix(op.path)}`);
  }
  console.log("install-global: dry-run complete（预览即上列路径；去掉 --dry-run 实际执行）");
  process.exit(EXIT_OK);
}

const backupStamp = new Date().toISOString().replace(/[^0-9]/g, "").slice(0, 14); // YYYYMMDDHHMMSS
const backedUp = new Set();
const backupLines = [];

/** 备份先行：改写既有文件前落 <file>.agentdev-bak-<ts>（同一文件一次运行只备份一次） */
function backupBeforeWrite(filePath) {
  if (!fs.existsSync(filePath) || backedUp.has(filePath)) return;
  const backupPath = `${filePath}.agentdev-bak-${backupStamp}`;
  fs.copyFileSync(filePath, backupPath);
  backedUp.add(filePath);
  backupLines.push(backupPath);
}

const mkdirs = new Set();
for (const op of plan) {
  if (op.kind === "write") mkdirs.add(path.dirname(op.path));
  else if (op.kind === "copyDir") mkdirs.add(path.dirname(op.dst));
}
for (const dir of mkdirs) fs.mkdirSync(dir, { recursive: true });

for (const op of plan) {
  if (op.kind === "write") {
    backupBeforeWrite(op.path);
    fs.writeFileSync(op.path, op.content, "utf-8");
  } else if (op.kind === "copyDir") {
    // 升级即重分发：先摘旧目标。rmSync 对 symlink/junction 只摘链接本身，不穿过链接删真实目录
    fs.rmSync(op.dst, { recursive: true, force: true });
    fs.cpSync(op.src, op.dst, { recursive: true });
  } else if (op.kind === "rmDir") {
    fs.rmSync(op.path, { recursive: true, force: true });
  } else if (op.kind === "rmFile") {
    fs.rmSync(op.path, { force: true });
  }
}

// ---------------------------------------------------------------------------
// 报告 + 下一步指引
// ---------------------------------------------------------------------------
console.log(`install-global: ${uninstall ? "用户级卸载" : "用户级安装"}（home: ${toPosix(userHome())}；repo: ${repoRootPosix}）`);
for (const line of reportLines) console.log(`OK [${line.platform}] ${line.text}`);
for (const backupPath of backupLines) console.log(`BACKUP ${toPosix(backupPath)}`);
if (!uninstall && tsxMissing) {
  console.log(`WARN: ${toPosix(tsxCli)} 不存在——用户级条目指向仓内开发态入口，先在 agentdev/mcp 下 npm ci（install.sh/ps1 会自动做）`);
}

if (!uninstall) {
  console.log("");
  console.log("下一步：");
  console.log("  1. 重启 IDE（或 Reload Window / 重开终端）让 agentdev-mcp 用户级注册生效");
  console.log("  2. 打开任意项目目录——无需项目级配置，项目根由 cwd 上溯 .agentdev/ 标记自动发现");
  console.log("  3. 跑 /agentdev-init（Codex 为 skill agentdev-init）：连通 MCP、建立 .agentdev/ 状态目录、license 排查与激活引导");
  console.log("  4. /agentdev-goal 走全流程，或分命令 /agentdev-brainstorm → /agentdev-scaffold → /agentdev-eval → /agentdev-deploy");
  console.log("  卸载：node <repo>/agentdev/install-global.mjs --uninstall（只摘 agentdev-*，其它条目保留）");
}
process.exit(EXIT_OK);
