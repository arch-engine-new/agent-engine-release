/**
 * T5 契约 trace 发射器（JSONL）——与 langgraph-python 模板的 tracing.py 同契约镜像。
 *
 * 事件契约：agentdev 协议层 trace-schema（agentdev://protocol/trace-schema.json）——
 * 五类事件 task_start / tool_call / llm_call / assertion / complete；公共必填字段
 * type / ts / run_id / task_id；complete.status 取值 ok|error。发射目标由环境变量
 * AGENTDEV_TRACE_FILE 指定（缺省 ./trace.jsonl），逐行追加 JSON（UTF-8）。
 *
 * 安全约定：工具入参只发哈希摘要（tool_call.args_digest），明文不入 trace。
 * 零运行时依赖（仅 node 内建）；Node >= 22.18 原生类型剥离直接运行（无需构建步骤）。
 */
import { createHash, randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

/** 五类事件类型（与协议层 trace-validate.ts 的枚举严格镜像，漂移由测试锁定） */
export type TraceEventType = "task_start" | "tool_call" | "llm_call" | "assertion" | "complete";

/** complete.status 受控枚举（error 是合法事件内容，只锁枚举不判任务成败） */
export type CompleteStatus = "ok" | "error";

/** 受控枚举运行时镜像（发射侧分派/校验共用） */
export const TRACE_EVENT_TYPES: readonly TraceEventType[] = [
  "task_start",
  "tool_call",
  "llm_call",
  "assertion",
  "complete",
];

/** trace 落盘缺省路径（env AGENTDEV_TRACE_FILE 未设置时生效） */
export const DEFAULT_TRACE_FILE = "./trace.jsonl";

/** 单条 trace 事件的 wire 形态（契约字段 snake_case：run_id/task_id，与协议层镜像） */
export interface TraceEventRecord {
  type: TraceEventType;
  ts: string;
  run_id: string;
  task_id: string;
  /** 向前兼容索引签名：允许发射器附加字段（契约只锁必填与类型） */
  [key: string]: unknown;
}

/** 解析 trace 落盘路径：env AGENTDEV_TRACE_FILE 优先，缺省 ./trace.jsonl */
export function traceFilePath(): string {
  return process.env["AGENTDEV_TRACE_FILE"] || DEFAULT_TRACE_FILE;
}

/** 当前 UTC 时间的 ISO 8601 字符串（毫秒精度、Z 后缀，契约 pattern 兼容） */
export function isoNow(): string {
  return new Date().toISOString();
}

/** 生成一次运行的唯一 run_id（uuid；跨事件串联键） */
export function newRunId(): string {
  return "run-" + randomUUID();
}

/** 敏感入参的 sha256 摘要（规范化键序后哈希；禁明文入 trace，防敏感信息泄漏） */
export function argsDigest(payload: unknown): string {
  const canonical = stableStringify(payload);
  return "sha256:" + createHash("sha256").update(canonical, "utf-8").digest("hex");
}

/** 稳定序列化：对象键排序，保证同载荷跨进程摘要一致 */
function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") {
    return JSON.stringify(value) ?? "null";
  }
  if (Array.isArray(value)) {
    return "[" + value.map(stableStringify).join(",") + "]";
  }
  const entries = Object.entries(value as Record<string, unknown>)
    .filter(([, fieldValue]) => fieldValue !== undefined)
    .sort(([leftKey], [rightKey]) => (leftKey < rightKey ? -1 : leftKey > rightKey ? 1 : 0));
  return "{" + entries.map(([key, val]) => JSON.stringify(key) + ":" + stableStringify(val)).join(",") + "}";
}

/** 构造公共必填四字段；未知事件类型在此显性报错（发射侧先于校验器拦截） */
function baseEvent(eventType: TraceEventType, runId: string, taskId: string): TraceEventRecord {
  if (!TRACE_EVENT_TYPES.includes(eventType)) {
    throw new Error("unknown trace event type: " + String(eventType));
  }
  if (runId.length === 0 || taskId.length === 0) {
    throw new Error("run_id/task_id 必须是非空字符串");
  }
  return { type: eventType, ts: isoNow(), run_id: runId, task_id: taskId };
}

/** 把单条事件追加写入 JSONL（UTF-8、逐行、目录自动创建）；返回写入的事件对象 */
export function emitEvent(event: TraceEventRecord, tracePath: string = traceFilePath()): TraceEventRecord {
  fs.mkdirSync(path.dirname(path.resolve(tracePath)), { recursive: true });
  fs.appendFileSync(tracePath, JSON.stringify(event) + "\n", "utf-8");
  return event;
}

/** task_start：任务开始（R2-F8 完整性必需事件之一） */
export function emitTaskStart(runId: string, taskId: string, extra: Record<string, unknown> = {}, tracePath?: string): TraceEventRecord {
  const event = baseEvent("task_start", runId, taskId);
  Object.assign(event, extra);
  return emitEvent(event, tracePath);
}

/** tool_call：工具调用（入参只发 args_digest 摘要，不落明文） */
export function emitToolCall(
  runId: string,
  taskId: string,
  tool: string,
  toolArgs: unknown = {},
  extra: Record<string, unknown> = {},
  tracePath?: string,
): TraceEventRecord {
  const event = baseEvent("tool_call", runId, taskId);
  event["tool"] = tool;
  event["args_digest"] = argsDigest(toolArgs);
  Object.assign(event, extra);
  return emitEvent(event, tracePath);
}

/** llm_call：模型调用（model 必填；token 计数可选，在场时须为非负整数） */
export function emitLlmCall(
  runId: string,
  taskId: string,
  model: string,
  tokensIn?: number,
  tokensOut?: number,
  extra: Record<string, unknown> = {},
  tracePath?: string,
): TraceEventRecord {
  const event = baseEvent("llm_call", runId, taskId);
  event["model"] = model;
  if (tokensIn !== undefined) {
    event["tokens_in"] = tokensIn;
  }
  if (tokensOut !== undefined) {
    event["tokens_out"] = tokensOut;
  }
  Object.assign(event, extra);
  return emitEvent(event, tracePath);
}

/** assertion：断言求值（断言失败是合法事件内容，passed 严格 boolean） */
export function emitAssertion(
  runId: string,
  taskId: string,
  assertionId: string,
  passed: boolean,
  extra: Record<string, unknown> = {},
  tracePath?: string,
): TraceEventRecord {
  const event = baseEvent("assertion", runId, taskId);
  event["assertion_id"] = assertionId;
  event["passed"] = passed;
  Object.assign(event, extra);
  return emitEvent(event, tracePath);
}

/** complete：任务收尾（R2-F8 完整性必需事件之一；status 取值 ok|error） */
export function emitComplete(
  runId: string,
  taskId: string,
  status: CompleteStatus,
  extra: Record<string, unknown> = {},
  tracePath?: string,
): TraceEventRecord {
  if (status !== "ok" && status !== "error") {
    throw new Error("complete.status 必须是 'ok' 或 'error'，实得 " + String(status));
  }
  const event = baseEvent("complete", runId, taskId);
  event["status"] = status;
  Object.assign(event, extra);
  return emitEvent(event, tracePath);
}
