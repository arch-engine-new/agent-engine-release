#!/usr/bin/env node
/**
 * agent '{{AGENT_NAME}}' 可启动入口（CLI）。
 *
 * 由 agentdev agent_scaffold 从模板 '{{TEMPLATE_ID}}' 渲染生成：
 * agent 名称与 description 来自 approved agent-spec，审批 hash 绑定见 SPEC_HASH。
 *
 * Usage:
 *   node src/agent.ts --task "your input"
 *   node src/agent.ts --serve    # 服务模式（v0 为 stub，仅回报模式声明）
 *
 * 环境变量:
 *   AGENTDEV_TRACE_FILE        trace JSONL 落盘路径（缺省 ./trace.jsonl）
 *   AGENTDEV_MODEL_API_KEY     真实模型接线用（演示实现不依赖）
 */
import { pathToFileURL } from "node:url";

import { runTask } from "./demo_agent.ts";
import { emitComplete, emitTaskStart, newRunId } from "./tracing.ts";

/** agent 名称（来自 spec.identity.name） */
export const AGENT_NAME = "{{AGENT_NAME}}";

/** agent 描述（来自 spec.identity.description；JSON 转义保证任意文本安全嵌入） */
export const AGENT_DESCRIPTION: string = "{{AGENT_DESCRIPTION_ESC}}";

/** 来源 spec 的审批绑定 hash（U3；可追溯生成基线） */
export const SPEC_HASH = "{{SPEC_HASH}}";

/** 生成所用模板 id */
export const TEMPLATE_ID = "{{TEMPLATE_ID}}";

/** 生成时间（ISO 8601，与部署清单 generatedAt 同源） */
export const GENERATED_AT = "{{GENERATED_AT}}";

/** CLI 单次任务的结构化结果（stdout 最后一行 JSON 的形态） */
export interface CliRunResult {
  agent: string;
  run_id: string;
  task_id: string;
  output: string;
}

/** 执行一次任务并发射 task_start/complete 事件；任务异常发射 complete(error) 后上抛 */
export function runCli(taskInput: string, taskId: string = "cli"): CliRunResult {
  const runId = newRunId();
  emitTaskStart(runId, taskId);
  let output: string;
  try {
    output = runTask(taskInput);
  } catch (err) {
    emitComplete(runId, taskId, "error", { error: err instanceof Error ? err.message : String(err) });
    throw err;
  }
  emitComplete(runId, taskId, "ok");
  return { agent: AGENT_NAME, run_id: runId, task_id: taskId, output };
}

/** 解析 CLI 参数：--task <text> / --serve */
function parseArgs(argv: readonly string[]): { task: string | null; serve: boolean } {
  let task: string | null = null;
  let serve = false;
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--serve") {
      serve = true;
    } else if (arg === "--task") {
      task = argv[index + 1] ?? null;
      index += 1;
    }
  }
  return { task, serve };
}

/** CLI 主入口：--serve 回报 stub 声明；--task 执行单次任务并打印结果 JSON。返回退出码 */
export function main(argv: readonly string[]): number {
  const { task, serve } = parseArgs(argv);
  if (serve) {
    // 服务模式留 stub（v0）：CLI 是唯一保证可跑的入口，服务化接线留后续版本
    console.log(JSON.stringify({ agent: AGENT_NAME, mode: "serve", status: "stub" }));
    return 0;
  }
  if (task === null || task.length === 0) {
    console.error("usage: node src/agent.ts --task <text>  (or --serve)");
    return 2;
  }
  console.log(JSON.stringify(runCli(task)));
  return 0;
}

// 仅直接执行时运行 CLI：被测试/工具 import 时不得抢占进程（守卫与 agentdev-mcp 同型）
const isDirectRun =
  process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isDirectRun) {
  process.exit(main(process.argv.slice(2)));
}
