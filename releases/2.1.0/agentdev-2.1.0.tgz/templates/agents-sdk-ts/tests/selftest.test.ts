/**
 * 模板自测（node:test，零依赖：无需 npm install、不调 LLM）。
 *
 * 覆盖（与 agentdev task-9 验收对齐）：
 * - 发射器：五类事件 JSONL 形状，对 trace-schema 手写断言（跨语言契约镜像）；
 * - 入口：CLI 子进程可跑、发射的 trace 含 task_start/complete（R2-F8）；
 * - 评测桩：报告键集与协议层 TaskGateResult/ChannelGateResult 精确一致（结构对齐）；
 * - 渲染安全：AGENT_NAME 等模块常量在「模板源态」与「渲染后态」都成立。
 *
 * 运行：npm test（Node >= 22.18 原生类型剥离，无需构建步骤）。
 */
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { test } from "node:test";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { AGENT_DESCRIPTION, AGENT_NAME, SPEC_HASH, TEMPLATE_ID, runCli } from "../src/agent.ts";
import { runTask } from "../src/demo_agent.ts";
import * as tracing from "../src/tracing.ts";
import { DEFAULT_PASS_RATIO_THRESHOLD, RUN_GATE_KEYS, TASK_GATE_KEYS, defaultTaskSet, runEval } from "../eval/stub.ts";

const TEMPLATE_ROOT = fileURLToPath(new URL("..", import.meta.url));

const ISO_TS_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$/;
const EVENT_TYPE_ENUM = new Set(["task_start", "tool_call", "llm_call", "assertion", "complete"]);
// 各事件类型专有必填字段（公共必填 type/ts/run_id/task_id 之外；对齐 trace-schema）
const TYPE_REQUIRED: Record<string, string[]> = {
  task_start: [],
  tool_call: ["tool", "args_digest"],
  llm_call: ["model"],
  assertion: ["assertion_id", "passed"],
  complete: ["status"],
};

/** 手写断言：单条事件满足 trace-schema 必填/类型/枚举（与 Python 自测同口径镜像） */
function assertEventContract(event: Record<string, unknown>): void {
  for (const key of ["type", "ts", "run_id", "task_id"]) {
    assert.ok(key in event, "缺公共必填字段 " + key);
  }
  assert.ok(EVENT_TYPE_ENUM.has(String(event["type"])));
  assert.equal(typeof event["ts"], "string");
  assert.match(String(event["ts"]), ISO_TS_PATTERN);
  assert.ok(typeof event["run_id"] === "string" && (event["run_id"] as string).length > 0);
  assert.ok(typeof event["task_id"] === "string" && (event["task_id"] as string).length > 0);
  for (const key of TYPE_REQUIRED[String(event["type"])] ?? []) {
    assert.ok(key in event, String(event["type"]) + " 缺专有必填字段 " + key);
  }
  if (event["type"] === "complete") {
    assert.ok(["ok", "error"].includes(String(event["status"])));
  }
  if (event["type"] === "assertion") {
    assert.equal(typeof event["passed"], "boolean");
  }
  if (event["type"] === "tool_call") {
    assert.equal(typeof event["args_digest"], "string");
    assert.ok((event["args_digest"] as string).length > 0);
  }
}

/** 读 JSONL 为事件列表（空白行容忍；坏行显性失败） */
function readEvents(tracePath: string): Array<Record<string, unknown>> {
  return fs
    .readFileSync(tracePath, "utf-8")
    .split("\n")
    .filter((line) => line.trim().length > 0)
    .map((line) => JSON.parse(line) as Record<string, unknown>);
}

/** 子进程环境（AGENTDEV_TRACE_FILE 指向临时路径） */
function subprocessEnv(tracePath: string): NodeJS.ProcessEnv {
  return { ...process.env, AGENTDEV_TRACE_FILE: tracePath };
}

test("demo agent runs offline: echo + word count", () => {
  const output = runTask("hello world");
  assert.ok(output.includes("echo"));
  assert.ok(output.includes("2"));
});

test("module consts are render-safe (valid in template source and rendered output)", () => {
  assert.equal(typeof AGENT_NAME, "string");
  assert.ok(AGENT_NAME.length > 0);
  assert.equal(typeof AGENT_DESCRIPTION, "string");
  // 模板源态为占位符 token；渲染后为 sha256: 前缀 hash——两种形态都必须是非空字符串
  assert.ok(typeof SPEC_HASH === "string" && SPEC_HASH.length > 0);
  assert.ok(TEMPLATE_ID.length > 0);
});

test("tracer emits contract-shaped JSONL for all five event types", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "agentdev-tpl-trace-"));
  const tracePath = path.join(dir, "trace.jsonl");
  const runId = tracing.newRunId();
  tracing.emitTaskStart(runId, "t1", {}, tracePath);
  tracing.emitToolCall(runId, "t1", "echo", { raw: "secret-input" }, {}, tracePath);
  tracing.emitLlmCall(runId, "t1", "demo-model", 1, 2, {}, tracePath);
  tracing.emitAssertion(runId, "t1", "a0", true, {}, tracePath);
  tracing.emitComplete(runId, "t1", "ok", {}, tracePath);
  const events = readEvents(tracePath);
  assert.equal(events.length, 5);
  for (const event of events) {
    assertEventContract(event);
  }
  assert.equal(events[0]?.["type"], "task_start");
  assert.equal(events[events.length - 1]?.["type"], "complete");
  assert.ok(String(events[1]?.["args_digest"]).startsWith("sha256:"));
  // 敏感入参只落摘要：明文不得出现在 trace 文件
  assert.ok(!fs.readFileSync(tracePath, "utf-8").includes("secret-input"));
});

test("emitComplete rejects unknown status (fail-closed at emitter)", () => {
  assert.throws(() => tracing.emitComplete(tracing.newRunId(), "t1", "maybe" as never, {}, path.join(os.tmpdir(), "unused.jsonl")));
});

test("runCli emits task_start/complete around the task", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "agentdev-tpl-cli-"));
  const tracePath = path.join(dir, "trace.jsonl");
  process.env["AGENTDEV_TRACE_FILE"] = tracePath;
  try {
    const result = runCli("hello cli");
    assert.ok(result.output.includes("echo"));
    assert.equal(result.agent, AGENT_NAME);
    const events = readEvents(tracePath);
    assert.ok(events.some((event) => event["type"] === "task_start"));
    const complete = events.find((event) => event["type"] === "complete");
    assert.equal(complete?.["status"], "ok");
    for (const event of events) {
      assertEventContract(event);
    }
  } finally {
    delete process.env["AGENTDEV_TRACE_FILE"];
  }
});

test("cli entry is launchable as a subprocess (node src/agent.ts --task ...)", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "agentdev-tpl-sub-"));
  const tracePath = path.join(dir, "cli-trace.jsonl");
  const proc = spawnSync(process.execPath, [path.join(TEMPLATE_ROOT, "src", "agent.ts"), "--task", "hello trace"], {
    cwd: TEMPLATE_ROOT,
    env: subprocessEnv(tracePath),
    encoding: "utf-8",
    timeout: 60_000,
  });
  assert.equal(proc.status, 0, proc.stderr);
  const payload = JSON.parse((proc.stdout ?? "").trim().split("\n").pop() ?? "{}") as Record<string, unknown>;
  assert.ok(String(payload["output"]).includes("echo"));
  const events = readEvents(tracePath);
  assert.ok(events.some((event) => event["type"] === "task_start"));
  assert.ok(events.some((event) => event["type"] === "complete" && event["status"] === "ok"));
});

test("eval stub report shape matches protocol TaskGateResult/ChannelGateResult key sets", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "agentdev-tpl-eval-"));
  const tracePath = path.join(dir, "eval-trace.jsonl");
  process.env["AGENTDEV_TRACE_FILE"] = tracePath;
  try {
    const report = runEval(defaultTaskSet(), 2) as Record<string, unknown>;
    // ChannelGateResult 键集（failReason 仅失败时在场）
    assert.deepEqual(Object.keys(report).sort(), ["channel", "passed", "tasks"]);
    assert.equal(report["passed"], true);
    assert.equal(report["channel"], "self-written");
    for (const task of report["tasks"] as Array<Record<string, unknown>>) {
      assert.deepEqual(
        Object.keys(task).filter((key) => key !== "failReason").sort(),
        [...TASK_GATE_KEYS].sort(),
      );
      assert.equal(task["threshold"], DEFAULT_PASS_RATIO_THRESHOLD);
      assert.equal(task["passed"], true);
      const runs = task["runs"] as Array<Record<string, unknown>>;
      assert.equal(runs.length, task["totalRuns"]);
      for (const run of runs) {
        assert.deepEqual(Object.keys(run).sort(), [...RUN_GATE_KEYS].sort());
      }
    }
    const events = readEvents(tracePath);
    assert.ok(events.some((event) => event["type"] === "task_start"));
    assert.ok(events.some((event) => event["type"] === "complete"));
    for (const event of events) {
      assertEventContract(event);
    }
  } finally {
    delete process.env["AGENTDEV_TRACE_FILE"];
  }
});

test("eval stub cli writes report file; fail path exits 1 with failReason (fail-closed)", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "agentdev-tpl-fail-"));
  const taskSetPath = path.join(dir, "tasks.json");
  const reportPath = path.join(dir, "fail-report.json");
  fs.writeFileSync(
    taskSetPath,
    JSON.stringify([{ id: "t-fail", input: "hello", assertions: [{ type: "contains", value: "NEVER" }] }]),
    "utf-8",
  );
  const proc = spawnSync(process.execPath, [path.join(TEMPLATE_ROOT, "eval", "stub.ts"), "--tasks", taskSetPath, "--runs", "1", "--out", reportPath], {
    cwd: TEMPLATE_ROOT,
    env: subprocessEnv(path.join(dir, "trace.jsonl")),
    encoding: "utf-8",
    timeout: 60_000,
  });
  // 门禁语义：通道不过必须以退出码 1 表达（报告仍完整落盘供审计）
  assert.equal(proc.status, 1, proc.stderr);
  const report = JSON.parse(fs.readFileSync(reportPath, "utf-8")) as Record<string, unknown>;
  assert.equal(report["passed"], false);
  assert.equal(typeof report["failReason"], "string");
  const task = (report["tasks"] as Array<Record<string, unknown>>)[0] as Record<string, unknown>;
  assert.equal(task["passed"], false);
  assert.equal(typeof task["failReason"], "string");
});
