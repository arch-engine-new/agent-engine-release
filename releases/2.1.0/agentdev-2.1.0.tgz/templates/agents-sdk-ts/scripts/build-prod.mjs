#!/usr/bin/env node
/**
 * R18 生产构建位（agentdev 模板注入锚点，v1.1 spec §5.3 / 红队 R1-F10）。
 *
 * 职责：生产构建 = 复制生产模块集（src/ + memory/ 若已注入）到 dist/，**评测钩子入口
 * 剥离**——eval 模式（记忆隔离/时间回拨/内省导出）属开发依赖，生产发布物不得含其代码
 * 路径（防提示注入触发记忆伪造原语）。剥离判据（三重，任一命中即剥离并记录）：
 *   1. 文件名：eval.ts / eval_ 前缀；
 *   2. 路径段：eval/ 目录（模板自带评测桩目录整体属于开发面）；
 *   3. 内容标记**行首注释锚**：/^(?:\/\/|#)\s*AGENTDEV_EVAL_ONLY/m（memory/eval.ts 首行
 *      形态）——只认整行以 // 或 # 起头的标记行；行中/块注释里的字面量提及（如生产入口
 *      memory/index.ts 的出口纪律注释「eval.ts（AGENTDEV_EVAL_ONLY）」）**不算** eval
 *      入口（防标记判据误剥生产文件，Task 7 fix）。
 * 双保险（fail-closed）：判据 3 命中但文件名/路径段不属判据 1/2 → 标记语义歧义，
 * 构造 issues **删除 dist、退出码 1**，不静默剥离。
 * 保留文件若引用评测模块（import 说明符命中判据 1/2）→ 构造 issues，**删除 dist、
 * 退出码 1**（fail-closed：宁可构建失败，不出带评测钩子的生产产物）。
 *
 * why 模板自带本脚本：模板自测零依赖可跑（src/ 缺 memory/ 时 dist=src 纯拷贝）；
 * scaffold 注入 memory 运行时后同一位即生效，生产构建开关无需二次接线。
 *
 * Usage: npm run build:prod   （在生成仓根目录执行）
 */
import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const ROOT = process.cwd();
const OUT_DIR = path.join(ROOT, "dist");
const INCLUDE_DIRS = ["src", "memory"];
const EVAL_ONLY_MARKER = "AGENTDEV_EVAL_ONLY";
// 判据 3 行首注释锚：只认整行起头的标记行（eval.ts 首行形态），行中/块注释提及不算
const EVAL_MARKER_LINE = /^(?:\/\/|#)\s*AGENTDEV_EVAL_ONLY/m;
const IMPORT_SPECIFIER_PATTERN = /(?:from|import)\s*\(?\s*["']([^"']+)["']/g;

/** 判据 1/2（文件名 / 路径段）：命中即属 eval 面，静默剥离并记录 */
function isEvalNamed(relPath) {
  const segments = relPath.split(/[\\/]+/);
  const base = segments[segments.length - 1];
  if (base === "eval.ts" || base.startsWith("eval_")) return true;
  return segments.includes("eval");
}

/** 判据 3（行首标记行）：内容级识别锚，与判据 1/2 分离判定（双保险语义见文件头） */
function hasEvalMarkerLine(content) {
  return EVAL_MARKER_LINE.test(content);
}

/** import 说明符是否指向评测模块（相对/裸说明符统一按段与基名判定，宁可误报不可漏放） */
function isEvalSpecifier(specifier) {
  if (specifier.startsWith("node:")) return false;
  const segments = specifier.split(/[\\/]+/);
  const base = segments[segments.length - 1].replace(/\.ts$/, "");
  if (base === "eval" || base.startsWith("eval_")) return true;
  return segments.includes("eval");
}

/** 递归收集目录文件（rel 以 posix 斜杠表示，输出路径跨平台稳定） */
function walk(dir, prefix) {
  if (!fs.existsSync(dir)) return [];
  const files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const rel = prefix ? prefix + "/" + entry.name : entry.name;
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...walk(abs, rel));
    else files.push({ rel, abs });
  }
  return files;
}

function main() {
  const copied = [];
  const excluded = [];
  const issues = [];
  fs.rmSync(OUT_DIR, { recursive: true, force: true }); // 清底重建：dist 状态只反映本次生产集
  for (const dir of INCLUDE_DIRS) {
    for (const file of walk(path.join(ROOT, dir), dir)) {
      const content = fs.readFileSync(file.abs, "utf-8");
      if (isEvalNamed(file.rel)) {
        excluded.push(file.rel);
        continue;
      }
      if (hasEvalMarkerLine(content)) {
        // 双保险：非 eval 命名文件携带行首标记行 → 判据歧义，硬失败（不静默剥离）
        issues.push(
          file.rel +
            ": 携带 " + EVAL_ONLY_MARKER + " 行首标记但非 eval 命名/路径（R18 双保险 fail-closed，禁止静默排除）",
        );
        continue;
      }
      for (const match of content.matchAll(IMPORT_SPECIFIER_PATTERN)) {
        const specifier = match[1] ?? "";
        if (isEvalSpecifier(specifier)) {
          issues.push(file.rel + ': 引用评测钩子模块 "' + specifier + '"（R18 fail-closed，生产产物禁止携带）');
        }
      }
      const target = path.join(OUT_DIR, ...file.rel.split("/"));
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, content, "utf-8");
      copied.push(file.rel);
    }
  }
  if (issues.length > 0) {
    fs.rmSync(OUT_DIR, { recursive: true, force: true }); // 拒绝产出半拉产物
    console.error(JSON.stringify({ ok: false, issues }, null, 2));
    process.exit(1);
  }
  console.log(JSON.stringify({ ok: true, copied: copied.length, excluded, out: OUT_DIR }, null, 2));
}

main();
