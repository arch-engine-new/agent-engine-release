/**
 * 评测桩：结构对齐优先（真实评测执行接线在 agentdev T11）。
 *
 * 职责边界：读任务集 JSON → 逐任务按运行策略 n 次重复跑 runTask → 发射 trace →
 * 输出报告 JSON。报告形状与 agentdev 协议层 run-policy.ts 的 TaskGateResult /
 * ChannelGateResult 字段严格对齐（camelCase wire 字段，键集由本模块常量声明并
 * 被自测锁定），供 T11 评测执行器与门禁链直接对接；本桩只保证结构可对接与离线可跑。
 *
 * 门禁语义对齐（run-policy.ts 同源口径）：默认 n=3；阈值默认 2/3（含等号）；
 * 空任务集 fail-closed；通道不过 → 进程退出码 1（报告仍完整落盘供审计）。
 *
 * Usage:
 *   node eval/stub.ts --tasks tasks.json --runs 3 --out eval-report.json
 */
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

import { runTask } from "../src/demo_agent.ts";
import { emitAssertion, emitComplete, emitTaskStart, newRunId } from "../src/tracing.ts";

/** 运行策略默认 n=3（与协议层 run-policy.ts 的 DEFAULT_RUN_COUNT 同源） */
export const DEFAULT_RUN_COUNT = 3;

/** 任务级通过率阈值默认 2/3（含等号；与 run-policy.ts 的 DEFAULT_PASS_RATIO_THRESHOLD 同源） */
export const DEFAULT_PASS_RATIO_THRESHOLD = 2 / 3;

/** TaskGateResult wire 键集（failReason 仅失败时在场；自测按此断言结构对齐） */
export const TASK_GATE_KEYS: readonly string[] = [
  "passCount",
  "passRatio",
  "passed",
  "runs",
  "runVariance",
  "taskId",
  "threshold",
  "totalRuns",
];

/** RunGateEntry wire 键集（单次运行门禁投影） */
export const RUN_GATE_KEYS: readonly string[] = ["countedAsPass", "isTraceValid", "passed"];

/** 评测任务（任务集 JSON 元素的 wire 形态；对齐协议层 EvalTask 的消费面） */
export interface StubTask {
  id: string;
  input: string;
  /** 断言集（演示级 exact/contains/regex；缺省视为无断言 → fail-closed 判不过） */
  assertions?: Array<{ type: string; value?: string; id?: string }>;
}

/** 读任务集 JSON：非空数组，每项含非空 id 与字符串 input；违约显性报错 */
export function loadTaskSet(taskSetPath: string): StubTask[] {
  const data: unknown = JSON.parse(fs.readFileSync(taskSetPath, "utf-8"));
  if (!Array.isArray(data) || data.length === 0) {
    throw new Error("任务集必须是非空 JSON 数组: " + taskSetPath);
  }
  data.forEach((task: unknown, index: number) => {
    const record = task as Record<string, unknown> | null;
    if (record === null || typeof record !== "object") {
      throw new Error("任务集第 " + index + " 项必须是对象");
    }
    if (typeof record["id"] !== "string" || record["id"].length === 0 || typeof record["input"] !== "string") {
      throw new Error("任务集第 " + index + " 项需要非空 id 与字符串 input");
    }
  });
  return data as StubTask[];
}

/** 内嵌演示任务集（--tasks 缺省时使用）：演示 agent 离线可判的 contains 断言 */
export function defaultTaskSet(): StubTask[] {
  return [
    { id: "demo-echo-1", input: "hello world", assertions: [{ type: "contains", value: "echo" }] },
    { id: "demo-echo-2", input: "agentdev scaffold", assertions: [{ type: "contains", value: "words" }] },
  ];
}

/** 单断言求值（exact/contains/regex）；其余类型按不过计（fail-closed：不认识即不放过） */
export function evaluateAssertion(output: string, assertion: { type: string; value?: string }): boolean {
  const expected = assertion.value;
  if (assertion.type === "exact" && typeof expected === "string") {
    return output === expected;
  }
  if (assertion.type === "contains" && typeof expected === "string") {
    return output.includes(expected);
  }
  if (assertion.type === "regex" && typeof expected === "string") {
    return new RegExp(expected).test(output);
  }
  return false;
}

/** 单次运行门禁投影（RunGateEntry 形态；异常运行发射 complete(error) 并计失败） */
export function runSingle(task: StubTask, runIndex: number): {
  passed: boolean;
  isTraceValid: boolean;
  countedAsPass: boolean;
} {
  const runId = newRunId();
  const taskId = String(task.id);
  emitTaskStart(runId, taskId, { run_index: runIndex });
  let output: string;
  try {
    output = runTask(String(task.input));
  } catch (err) {
    emitComplete(runId, taskId, "error", { error: err instanceof Error ? err.message : String(err) });
    return { passed: false, isTraceValid: true, countedAsPass: false };
  }
  const outcomes: boolean[] = [];
  const assertions = task.assertions ?? [];
  assertions.forEach((assertion, assertionIndex) => {
    const passed = evaluateAssertion(output, assertion);
    outcomes.push(passed);
    emitAssertion(runId, taskId, String(assertion.id ?? "a" + assertionIndex), passed);
  });
  emitComplete(runId, taskId, "ok");
  const passedAll = outcomes.length > 0 ? outcomes.every(Boolean) : false;
  return { passed: passedAll, isTraceValid: true, countedAsPass: passedAll };
}

/** 任务级判定（TaskGateResult 形态；键集见 TASK_GATE_KEYS；空运行集 fail-closed） */
export function evaluateTaskGate(taskId: string, runEntries: Array<Record<string, unknown>>, threshold: number): Record<string, unknown> {
  const total = runEntries.length;
  const passCount = runEntries.filter((entry) => entry["countedAsPass"] === true).length;
  const passRatio = total > 0 ? passCount / total : 0;
  const passed = total > 0 && passRatio >= threshold;
  let runVariance = 0;
  if (total > 1) {
    const outcomes = runEntries.map((entry) => (entry["countedAsPass"] === true ? 1 : 0));
    const mean = outcomes.reduce((sum, value) => sum + value, 0) / total;
    runVariance = outcomes.reduce((sum, value) => sum + (value - mean) * (value - mean), 0) / (total - 1);
  }
  const result: Record<string, unknown> = {
    taskId,
    passCount,
    totalRuns: total,
    passRatio,
    threshold,
    passed,
    runVariance,
    runs: runEntries,
  };
  if (!passed) {
    result["failReason"] = "通过率 " + passCount + "/" + total + " 低于阈值 " + threshold + "（U4 任务级门禁）";
  }
  return result;
}

/** 整场评测：逐任务 n 次重复 → 任务级判定 → 通道级 U4 全任务谓词裁决（ChannelGateResult 形态） */
export function runEval(
  tasks: StubTask[],
  runs: number = DEFAULT_RUN_COUNT,
  threshold: number = DEFAULT_PASS_RATIO_THRESHOLD,
  channel: "self-written" | "held-out" = "self-written",
): Record<string, unknown> {
  if (runs < 1) {
    throw new Error("runs 必须 >= 1，实得 " + String(runs));
  }
  const taskResults = tasks.map((task) =>
    evaluateTaskGate(
      String(task.id),
      Array.from({ length: runs }, (_, index) => runSingle(task, index)),
      threshold,
    ),
  );
  const passed = taskResults.length > 0 && taskResults.every((result) => result["passed"] === true);
  const report: Record<string, unknown> = { channel, tasks: taskResults, passed };
  if (!passed) {
    const failed = taskResults.filter((result) => result["passed"] !== true).map((result) => String(result["taskId"]));
    report["failReason"] = "通道存在未达标任务（U4 全任务谓词）: " + failed.join(", ");
  }
  return report;
}

/** CLI 主入口：退出码 0=通道过 / 1=通道不过（门禁语义） */
export function main(argv: readonly string[]): number {
  let tasksPath: string | null = null;
  let runs = DEFAULT_RUN_COUNT;
  let threshold = DEFAULT_PASS_RATIO_THRESHOLD;
  let outPath = "eval-report.json";
  let channel: "self-written" | "held-out" = "self-written";
  // 手写参数解析（模板零第三方依赖红线）：只识别本桩声明的开关，解析面收敛到演示所需的最小集。
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--tasks") {
      tasksPath = argv[index + 1] ?? null;
      index += 1;
    } else if (arg === "--runs") {
      runs = Number(argv[index + 1]);
      index += 1;
    } else if (arg === "--threshold") {
      threshold = Number(argv[index + 1]);
      index += 1;
    } else if (arg === "--out") {
      outPath = argv[index + 1] ?? outPath;
      index += 1;
    } else if (arg === "--channel") {
      const value = argv[index + 1];
      if (value === "self-written" || value === "held-out") {
        channel = value;
      }
      index += 1;
    }
  }
  // --tasks 缺省回落内嵌演示任务集：保证模板开箱离线可跑（scaffold e2e 的 exit 0 断言依赖此路径）。
  const tasks = tasksPath !== null ? loadTaskSet(tasksPath) : defaultTaskSet();
  const report = runEval(tasks, runs, threshold, channel);
  const resolvedOut = path.resolve(outPath);
  fs.mkdirSync(path.dirname(resolvedOut), { recursive: true });
  fs.writeFileSync(resolvedOut, JSON.stringify(report, null, 2) + "\n", "utf-8");
  console.log(JSON.stringify({ ok: true, out: resolvedOut, passed: report["passed"] }));
  // 退出码即门禁信号：通道不过必须非零退出，调用方（CI/e2e）以退出码做快速裁决而不必解析报告。
  return report["passed"] === true ? 0 : 1;
}

// 仅直接执行时运行 CLI：被测试/工具 import 时不得抢占进程（守卫与 src/agent.ts 同型）
const isDirectRun =
  process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isDirectRun) {
  process.exit(main(process.argv.slice(2)));
}
