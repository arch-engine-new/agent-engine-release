/**
 * 演示 agent：回显输入并统计词数（离线可跑，模板自测不依赖外部 LLM API）。
 *
 * 职责边界：让生成出的 agent 仓在「零配置、零网络」下即可启动与自测。
 * LLM 调用位：llmComplete() 是可替换 stub——真实接入时在此挂 Claude Agent SDK
 * （@anthropic-ai/claude-agent-sdk 已在 package.json 声明，API key 由使用者经环境变量提供）；
 * runTask() 的离线实现保证评测桩与自测全程不触网。
 */

/** LLM 调用 stub（接线位）：未配置 key 时显性报错，绝不静默假装成功 */
export function llmComplete(prompt: string): string {
  if (!process.env["AGENTDEV_MODEL_API_KEY"]) {
    throw new Error(
      "llmComplete 是占位实现：配置 AGENTDEV_MODEL_API_KEY 并把本函数替换为 @anthropic-ai/claude-agent-sdk 真实调用",
    );
  }
  throw new Error("请在本函数内接入 @anthropic-ai/claude-agent-sdk 模型调用（接线位）");
}

/** 演示任务实现：回显输入并统计词数（纯函数、零外部依赖） */
export function runTask(taskInput: string): string {
  const wordCount = taskInput.split(/\s+/).filter((word) => word.length > 0).length;
  return "echo: " + taskInput + " | words: " + String(wordCount);
}
