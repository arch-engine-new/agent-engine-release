"""演示 agent：回显输入并统计词数（离线可跑，模板自测不依赖外部 LLM API）。

职责边界：让生成出的 agent 仓在「零配置、零网络」下即可启动与自测。
LLM 调用位：llm_complete() 是可替换 stub——真实接入时在此挂 AutoGen
（autogen-agentchat，API key 由使用者经环境变量提供）；run_task() 的
离线实现保证评测桩与自测全程不触网。
"""

from __future__ import annotations

import os


def llm_complete(prompt: str) -> str:
    """LLM 调用 stub（接线位）：未配置 key 时显性报错，绝不静默假装成功。

    真实接入指引：配置 AGENTDEV_MODEL_API_KEY 后，把本函数替换为 AutoGen
    （autogen-agentchat）的模型调用；返回文本约定与 run_task 一致（纯字符串输出）。
    """
    if not os.environ.get("AGENTDEV_MODEL_API_KEY"):
        raise RuntimeError(
            "llm_complete 是占位实现：配置 AGENTDEV_MODEL_API_KEY 并把本函数替换为 autogen-agentchat 真实调用"
        )
    raise NotImplementedError("请在本函数内接入 AutoGen（autogen-agentchat）模型调用（接线位）")


def run_task(task_input: str) -> str:
    """演示任务实现：回显输入并统计词数（纯函数、零外部依赖）。

    参数:
        task_input: 任务输入文本。
    返回:
        形如 "echo: <输入> | words: <词数>" 的输出串。
    """
    word_count = len(task_input.split())
    return "echo: " + task_input + " | words: " + str(word_count)
