# {{AGENT_NAME}}

{{AGENT_DESCRIPTION}}

由 agentdev `agent_scaffold` 从 approved agent-spec 渲染生成的 agent 仓（Python 3.10+ / LangGraph，模板 langgraph-python）。
文件头部的 `AGENT_NAME` / `AGENT_DESCRIPTION` / `SPEC_HASH` 等常量来自 spec 身份块与审批绑定，
由脚手架在生成时替换（模板源内为占位符形态，渲染后零残留）。

## 运行

```bash
python agent.py --task "hello world"      # CLI：跑一次演示任务并发射 trace
python agent.py --serve                   # 服务模式（v0 stub，仅回报模式声明）
python -m pytest -q                       # 自测（零外部依赖：不装 langgraph、不调 LLM）
python eval_stub.py --runs 3              # 评测桩：输出报告 eval-report.json
```

## 结构

| 文件 | 职责 |
|------|------|
| `agent.py` | 可启动入口（CLI；服务模式留 stub） |
| `demo_agent.py` | 演示 agent（回显输入并统计词数；`llm_complete` 为可替换 LLM 接线位） |
| `tracing.py` | trace 发射器（agentdev T5 契约 JSONL：task_start/tool_call/llm_call/assertion/complete） |
| `eval_stub.py` | 评测桩（报告形状对齐协议层 TaskGateResult / ChannelGateResult；真实执行接线在 agentdev T11） |
| `tests/test_selftest.py` | 模板自测（发射器契约断言 + 入口/评测桩可跑） |

## 环境变量

- `AGENTDEV_TRACE_FILE`：trace JSONL 落盘路径（缺省 `./trace.jsonl`）。
- `AGENTDEV_MODEL_API_KEY`：真实模型接线用；演示实现与自测不依赖（不触网）。

## 真实 LLM 接线

把 `demo_agent.llm_complete` 替换为 LangGraph 模型调用（配置 API key 后原 stub 会显性报错提示）。
`requirements.txt` 已声明 `langgraph` 依赖，按需 `pip install -r requirements.txt`。

## trace 契约

发射器逐行追加 JSON 到 `AGENTDEV_TRACE_FILE`；公共必填字段 `type/ts/run_id/task_id`，
工具入参只落 sha256 摘要（`args_digest`），明文不入 trace。自测内置与协议层
trace-schema 一致的手写断言；agentdev 侧另有真实校验器（trace-validate）做跨语言回归。
