# {{AGENT_NAME}}

{{AGENT_DESCRIPTION}}

由 agentdev `agent_scaffold` 从 approved agent-spec 渲染生成的 agent 仓（Node 22+ / TypeScript / LangGraph JS，模板 langgraph-js）。
`src/agent.ts` 头部的 `AGENT_NAME` / `AGENT_DESCRIPTION` / `SPEC_HASH` 等常量来自 spec 身份块与审批绑定，
由脚手架在生成时替换（模板源内为占位符形态，渲染后零残留）。

## 运行

```bash
node src/agent.ts --task "hello world"    # CLI：跑一次演示任务并发射 trace
node src/agent.ts --serve                 # 服务模式（v0 stub，仅回报模式声明）
npm test                                  # 自测（node:test，零安装：原生类型剥离直接跑 TS）
node eval/stub.ts --runs 3                # 评测桩：输出报告 eval-report.json
```

要求 Node >= 22.18（原生 TS 类型剥离，无需构建步骤）；`npm install` 仅在接入真实
模型（`@langchain/langgraph` 已在 dependencies 声明）或跑 `npm run typecheck` 时需要。

## 结构

| 文件 | 职责 |
|------|------|
| `src/agent.ts` | 可启动入口（CLI；服务模式留 stub） |
| `src/demo_agent.ts` | 演示 agent（回显输入并统计词数；`llmComplete` 为可替换 LLM 接线位） |
| `src/tracing.ts` | trace 发射器（agentdev T5 契约 JSONL：task_start/tool_call/llm_call/assertion/complete） |
| `eval/stub.ts` | 评测桩（报告形状对齐协议层 TaskGateResult / ChannelGateResult；真实执行接线在 agentdev T11） |
| `tests/selftest.test.ts` | 模板自测（发射器契约断言 + 入口/评测桩可跑） |

## 环境变量

- `AGENTDEV_TRACE_FILE`：trace JSONL 落盘路径（缺省 `./trace.jsonl`）。
- `AGENTDEV_MODEL_API_KEY`：真实模型接线用；演示实现与自测不依赖（不触网）。

## 真实 LLM 接线

把 `src/demo_agent.ts` 的 `llmComplete` 替换为 LangGraph JS（`@langchain/langgraph`）
模型调用（配置 API key 后原 stub 会显性报错提示）。

## trace 契约

发射器逐行追加 JSON 到 `AGENTDEV_TRACE_FILE`；公共必填字段 `type/ts/run_id/task_id`，
工具入参只落 sha256 摘要（`args_digest`），明文不入 trace。自测内置与协议层
trace-schema 一致的手写断言；agentdev 侧另有真实校验器（trace-validate）做跨语言回归。
