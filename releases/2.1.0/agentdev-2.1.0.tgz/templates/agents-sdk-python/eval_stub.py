"""评测桩：结构对齐优先（真实评测执行接线在 agentdev T11）。

职责边界：读任务集 JSON → 逐任务按运行策略 n 次重复跑 run_task → 发射 trace →
输出报告 JSON。报告形状与 agentdev 协议层 run-policy.ts 的 TaskGateResult /
ChannelGateResult 字段严格对齐（camelCase wire 字段，键集由本模块常量声明并
被自测锁定），供 T11 评测执行器与门禁链直接对接；本桩只保证结构可对接与离线可跑，
不承担真实判定（断言求值为演示级 exact/contains/regex）。

门禁语义对齐（run-policy.ts 同源口径）：
- 运行策略默认每任务 n=3 次；任务级通过率阈值默认 2/3（含等号）；
- 无效/异常运行计失败进分母；空任务集 fail-closed（passed=false）；
- 通道不过 → 进程退出码 1（报告仍完整落盘供审计）。

Usage:
    python eval_stub.py --tasks tasks.json --runs 3 --out eval-report.json
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from demo_agent import run_task
from tracing import emit_assertion, emit_complete, emit_task_start, new_run_id

DEFAULT_RUN_COUNT = 3
"""运行策略默认 n=3（与协议层 run-policy.ts 的 DEFAULT_RUN_COUNT 同源）。"""

DEFAULT_PASS_RATIO_THRESHOLD = 2.0 / 3.0
"""任务级通过率阈值默认 2/3（含等号；与 run-policy.ts 的 DEFAULT_PASS_RATIO_THRESHOLD 同源）。"""

TASK_GATE_KEYS = frozenset(
    ("passCount", "passRatio", "passed", "runs", "runVariance", "taskId", "threshold", "totalRuns")
)
"""TaskGateResult wire 键集（failReason 仅失败时在场；自测按此断言结构对齐）。"""

RUN_GATE_KEYS = frozenset(("countedAsPass", "isTraceValid", "passed"))
"""RunGateEntry wire 键集（单次运行门禁投影）。"""


def load_task_set(path: Path) -> List[Dict[str, Any]]:
    """读任务集 JSON：非空数组，每项含非空 id 与字符串 input；违约显性报错。"""
    data = json.loads(path.read_text(encoding="utf-8"))
    # fail-closed：空/畸形任务集必须在此显性报错——静默放行会产出「结构合法但空判」的报告，把整条门禁链架空。
    if not isinstance(data, list) or not data:
        raise ValueError("任务集必须是非空 JSON 数组: " + str(path))
    # 逐项锁 id/input：task_id 是报告与失败定位的唯一键，源头不洁则下游去重与归因全部失真。
    for index, task in enumerate(data):
        if not isinstance(task, dict):
            raise ValueError("任务集第 " + str(index) + " 项必须是对象")
        if not task.get("id") or not isinstance(task.get("input"), str):
            raise ValueError("任务集第 " + str(index) + " 项需要非空 id 与字符串 input")
    return data


def default_task_set() -> List[Dict[str, Any]]:
    """内嵌演示任务集（--tasks 缺省时使用）：演示 agent 离线可判的 contains 断言。"""
    return [
        {
            "id": "demo-echo-1",
            "input": "hello world",
            "assertions": [{"type": "contains", "value": "echo"}],
        },
        {
            "id": "demo-echo-2",
            "input": "agentdev scaffold",
            "assertions": [{"type": "contains", "value": "words"}],
        },
    ]


def evaluate_assertion(output: str, assertion: Dict[str, Any]) -> bool:
    """单断言求值（exact/contains/regex）；其余类型按不过计（fail-closed：不认识即不放过）。"""
    kind = assertion.get("type")
    expected = assertion.get("value")
    if kind == "exact" and isinstance(expected, str):
        return output == expected
    if kind == "contains" and isinstance(expected, str):
        return expected in output
    if kind == "regex" and isinstance(expected, str):
        return re.search(expected, output) is not None
    return False


def run_single(task: Dict[str, Any], run_index: int) -> Dict[str, Any]:
    """跑单次：发射 task_start → 求值断言 → complete；返回 RunGateEntry 形状。

    R2-F8 对齐：本桩发射 task_start 与 complete（结构完整），isTraceValid 恒为 true；
    任务异常发射 complete(status=error) 并计失败（异常运行进分母）。
    """
    run_id = new_run_id()
    task_id = str(task["id"])
    emit_task_start(run_id, task_id, run_index=run_index)
    try:
        output = run_task(str(task["input"]))
    except Exception as err:
        emit_complete(run_id, task_id, "error", error=str(err))
        return {"passed": False, "isTraceValid": True, "countedAsPass": False}
    outcomes: List[bool] = []
    for a_index, assertion in enumerate(task.get("assertions") or []):
        passed = evaluate_assertion(output, assertion if isinstance(assertion, dict) else {})
        outcomes.append(passed)
        emit_assertion(run_id, task_id, str(assertion.get("id") or "a" + str(a_index)), passed)
    emit_complete(run_id, task_id, "ok")
    passed_all = all(outcomes) if outcomes else False
    return {"passed": passed_all, "isTraceValid": True, "countedAsPass": passed_all}


def evaluate_task_gate(task_id: str, run_entries: List[Dict[str, Any]], threshold: float) -> Dict[str, Any]:
    """组装 TaskGateResult 形状（键集见 TASK_GATE_KEYS；空运行集 fail-closed）。"""
    total = len(run_entries)
    pass_count = sum(1 for entry in run_entries if entry.get("countedAsPass") is True)
    pass_ratio = (pass_count / total) if total else 0.0
    # U4 口径：空运行集 fail-closed（passed=false），阈值含等号——恰好 2/3 也算过（与 run-policy.ts 同源）。
    passed = bool(total) and pass_ratio >= threshold
    variance = 0.0
    # runVariance 暴露运行间抖动：0 表示确定性复现，非 0 提示被测 agent 或环境不稳定（报告消费方的排障信号）。
    if total > 1:
        outcomes = [1.0 if entry.get("countedAsPass") is True else 0.0 for entry in run_entries]
        mean = sum(outcomes) / total
        variance = sum((value - mean) ** 2 for value in outcomes) / (total - 1)
    result: Dict[str, Any] = {
        "taskId": task_id,
        "passCount": pass_count,
        "totalRuns": total,
        "passRatio": pass_ratio,
        "threshold": threshold,
        "passed": passed,
        "runVariance": variance,
        "runs": run_entries,
    }
    if not passed:
        result["failReason"] = "通过率 " + str(pass_count) + "/" + str(total) + " 低于阈值 " + str(threshold) + "（U4 任务级门禁）"
    return result


# 通道级 U4 是全任务谓词：任一任务不过即整通道不过——这是评测退出码 1 的唯一来源（报告仍完整落盘供审计）。
def run_eval(
    tasks: List[Dict[str, Any]],
    runs: int = DEFAULT_RUN_COUNT,
    threshold: float = DEFAULT_PASS_RATIO_THRESHOLD,
    channel: str = "self-written",
) -> Dict[str, Any]:
    """整场评测：逐任务 n 次重复 → 任务级判定 → 通道级 U4 全任务谓词裁决。"""
    if runs < 1:
        raise ValueError("runs 必须 >= 1，实得 " + str(runs))
    task_results = []
    for task in tasks:
        run_entries = [run_single(task, index) for index in range(runs)]
        task_results.append(evaluate_task_gate(str(task["id"]), run_entries, threshold))
    passed = bool(task_results) and all(result["passed"] for result in task_results)
    report: Dict[str, Any] = {"channel": channel, "tasks": task_results, "passed": passed}
    if not passed:
        failed = [str(result["taskId"]) for result in task_results if not result["passed"]]
        report["failReason"] = "通道存在未达标任务（U4 全任务谓词）: " + ", ".join(failed)
    return report


def main(argv: Optional[Sequence[str]] = None) -> int:
    """CLI 主入口：跑评测并落盘报告 JSON；退出码 0=通道过 / 1=通道不过（门禁语义）。"""
    parser = argparse.ArgumentParser(
        prog="eval_stub.py",
        description="评测桩：输出形状对齐协议层 TaskGateResult/ChannelGateResult（真实执行接线在 T11）",
    )
    parser.add_argument("--tasks", type=str, default=None, help="任务集 JSON 路径（缺省用内嵌演示任务集）")
    parser.add_argument("--runs", type=int, default=DEFAULT_RUN_COUNT, help="每任务重复运行次数（默认 3）")
    parser.add_argument("--threshold", type=float, default=DEFAULT_PASS_RATIO_THRESHOLD, help="任务级通过率阈值（默认 2/3，含等号）")
    parser.add_argument("--channel", type=str, default="self-written", choices=["self-written", "held-out"], help="评测通道")
    parser.add_argument("--out", type=str, default="eval-report.json", help="报告 JSON 输出路径")
    args = parser.parse_args(argv)
    tasks = load_task_set(Path(args.tasks)) if args.tasks else default_task_set()
    report = run_eval(tasks, runs=args.runs, threshold=args.threshold, channel=args.channel)
    out_path = Path(args.out)
    out_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"ok": True, "out": str(out_path), "passed": report["passed"]}, ensure_ascii=False))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
