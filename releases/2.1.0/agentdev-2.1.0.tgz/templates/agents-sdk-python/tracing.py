"""T5 契约 trace 发射器（JSONL，跨模板同契约：agents-sdk-ts 的 src/tracing.ts 镜像本模块）。

事件契约：agentdev 协议层 trace-schema（agentdev://protocol/trace-schema.json）——
五类事件 task_start / tool_call / llm_call / assertion / complete；公共必填字段
type / ts / run_id / task_id；complete.status 取值 ok|error。发射目标由环境变量
AGENTDEV_TRACE_FILE 指定（缺省 ./trace.jsonl），逐行追加 JSON（UTF-8）。

安全约定：工具入参只发哈希摘要（tool_call.args_digest），明文不入 trace。
零第三方依赖（仅标准库）；真实执行接线（评测执行器）由 agentdev T11 消费本发射器。
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

TRACE_EVENT_TYPES = ("task_start", "tool_call", "llm_call", "assertion", "complete")
"""五类事件类型（与协议层 trace-validate.ts 的枚举严格镜像，漂移由测试锁定）。"""

COMPLETE_STATUSES = ("ok", "error")
"""complete.status 受控枚举（error 是合法事件内容，只锁枚举不判任务成败）。"""

DEFAULT_TRACE_FILE = "./trace.jsonl"
"""trace 落盘缺省路径（env AGENTDEV_TRACE_FILE 未设置时生效）。"""


def trace_file_path() -> Path:
    """解析 trace 落盘路径：env AGENTDEV_TRACE_FILE 优先，缺省 ./trace.jsonl。"""
    return Path(os.environ.get("AGENTDEV_TRACE_FILE") or DEFAULT_TRACE_FILE)


def iso_now() -> str:
    """当前 UTC 时间的 ISO 8601 字符串（毫秒精度、Z 后缀，契约 pattern 兼容）。"""
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def new_run_id() -> str:
    """生成一次运行的唯一 run_id（uuid4；跨事件串联键）。"""
    return "run-" + uuid.uuid4().hex


def args_digest(payload: Any) -> str:
    """敏感入参的 sha256 摘要（禁明文入 trace，防敏感信息泄漏）。"""
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _base_event(event_type: str, run_id: str, task_id: str) -> Dict[str, Any]:
    """构造公共必填四字段；未知事件类型在此显性报错（发射侧先于校验器拦截）。"""
    if event_type not in TRACE_EVENT_TYPES:
        raise ValueError("unknown trace event type: " + repr(event_type))
    if not run_id or not task_id:
        raise ValueError("run_id/task_id 必须是非空字符串")
    return {"type": event_type, "ts": iso_now(), "run_id": run_id, "task_id": task_id}


def emit_event(event: Dict[str, Any], trace_path: Optional[Path] = None) -> Dict[str, Any]:
    """把单条事件追加写入 JSONL（UTF-8、逐行、目录自动创建）；返回写入的事件对象。"""
    target = Path(trace_path) if trace_path is not None else trace_file_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
    return event


def emit_task_start(run_id: str, task_id: str, trace_path: Optional[Path] = None, **extra: Any) -> Dict[str, Any]:
    """task_start：任务开始（R2-F8 完整性必需事件之一）。"""
    event = _base_event("task_start", run_id, task_id)
    event.update(extra)
    return emit_event(event, trace_path)


# 安全不变量：明文工具入参只允许以摘要入 trace——本入口是「明文 → args_digest」的唯一收敛点，防止敏感参数经 JSONL 落盘泄漏。
def emit_tool_call(
    run_id: str,
    task_id: str,
    tool: str,
    tool_args: Optional[Dict[str, Any]] = None,
    trace_path: Optional[Path] = None,
    **extra: Any,
) -> Dict[str, Any]:
    """tool_call：工具调用（入参只发 args_digest 摘要，不落明文）。"""
    event = _base_event("tool_call", run_id, task_id)
    event["tool"] = tool
    event["args_digest"] = args_digest(tool_args or {})
    event.update(extra)
    return emit_event(event, trace_path)


# token 字段「缺席即未上报」：可选计数不落 0/缺省值，下游统计才能区分「真实 0 token」与「未采集」，指标不被默认值污染。
def emit_llm_call(
    run_id: str,
    task_id: str,
    model: str,
    tokens_in: Optional[int] = None,
    tokens_out: Optional[int] = None,
    trace_path: Optional[Path] = None,
    **extra: Any,
) -> Dict[str, Any]:
    """llm_call：模型调用（model 必填；token 计数可选，在场时须为非负整数）。"""
    event = _base_event("llm_call", run_id, task_id)
    event["model"] = model
    if tokens_in is not None:
        event["tokens_in"] = int(tokens_in)
    if tokens_out is not None:
        event["tokens_out"] = int(tokens_out)
    event.update(extra)
    return emit_event(event, trace_path)


# passed=False 是合法观测而非发射端故障：本入口绝不因断言失败抛错，评测门禁才能区分「任务失败」与「链路异常」。
def emit_assertion(
    run_id: str,
    task_id: str,
    assertion_id: str,
    passed: bool,
    trace_path: Optional[Path] = None,
    **extra: Any,
) -> Dict[str, Any]:
    """assertion：断言求值（断言失败是合法事件内容，passed 严格 boolean）。"""
    event = _base_event("assertion", run_id, task_id)
    event["assertion_id"] = assertion_id
    event["passed"] = bool(passed)
    event.update(extra)
    return emit_event(event, trace_path)


# 收尾事件参与 R2-F8 完整性对账：status 必须落在受控枚举，否则整条 trace 判无效，任务级门禁结果随之失真。
def emit_complete(
    run_id: str,
    task_id: str,
    status: str,
    trace_path: Optional[Path] = None,
    **extra: Any,
) -> Dict[str, Any]:
    """complete：任务收尾（R2-F8 完整性必需事件之一；status 取值 ok|error）。"""
    if status not in COMPLETE_STATUSES:
        raise ValueError("complete.status 必须是 'ok' 或 'error'，实得 " + repr(status))
    event = _base_event("complete", run_id, task_id)
    event["status"] = status
    event.update(extra)
    return emit_event(event, trace_path)
