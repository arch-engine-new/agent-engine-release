#!/usr/bin/env python3
"""R18 生产构建位（agentdev 模板注入锚点，v1.1 spec §5.3 / 红队 R1-F10）。

职责：生产构建 = 复制生产模块集（仓根 *.py + memory/ 若已注入）到 dist/，
**评测钩子入口剥离**——eval 模式（记忆隔离/时间回拨/内省导出）属开发依赖，
生产发布物不得含其代码路径（防提示注入触发记忆伪造原语）。剥离判据（三重，
任一命中即剥离并记录）：

1. 文件名：eval.py / eval_ 前缀（如 eval_stub.py）；
2. 路径段：eval/ 目录（评测桩目录整体属于开发面）；
3. 内容标记**行首注释锚**：``^(?://|#)\\s*AGENTDEV_EVAL_ONLY``（MULTILINE，
   memory/eval.py 首行形态）——只认整行以 # 起头的标记行；行中/块注释里的
   字面量提及（如生产入口 __init__.py 的出口纪律注释）**不算** eval 入口
   （防标记判据误剥生产文件，Task 7 fix）。

双保险（fail-closed）：判据 3 命中但文件名/路径段不属判据 1/2 → 标记语义
歧义，构造 issues **删除 dist、退出码 1**，不静默剥离。
保留文件若 import 评测模块（from/import 语句命中判据 1/2）→ 构造 issues，
**删除 dist、退出码 1**（fail-closed：宁可构建失败，不出带评测钩子的生产产物）。

why 模板自带本脚本：模板自测零依赖可跑（未注入 memory/ 时 dist=根生产模块纯拷贝）；
scaffold 注入 memory 运行时后同一位即生效，生产构建开关无需二次接线。

Usage: python build_prod.py    (在生成仓根目录执行)
"""

from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
OUT_DIR = ROOT / "dist"
EVAL_ONLY_MARKER = "AGENTDEV_EVAL_ONLY"
# 判据 3 行首注释锚：只认整行起头的标记行（eval.py 首行形态），行中/块注释提及不算
EVAL_MARKER_LINE = re.compile(r"^(?://|#)\s*" + EVAL_ONLY_MARKER, re.MULTILINE)
FROM_IMPORT = re.compile(r"^\s*from\s+([\w.]+)\s+import", re.MULTILINE)
PLAIN_IMPORT = re.compile(r"^\s*import\s+([\w.,\s]+)", re.MULTILINE)


def is_eval_named(rel: Path) -> bool:
    """判据 1/2（文件名 / 路径段）：命中即属 eval 面，静默剥离并记录。"""
    if rel.name == "eval.py" or rel.name.startswith("eval_"):
        return True
    return "eval" in rel.parts


def has_eval_marker_line(content: str) -> bool:
    """判据 3（行首标记行）：内容级识别锚，与判据 1/2 分离判定（双保险语义见模块 docstring）。"""
    return EVAL_MARKER_LINE.search(content) is not None


def is_eval_module(module: str) -> bool:
    """import 模块名是否指向评测模块（宁可误报不可漏放，fail-closed 取向）。"""
    parts = module.split(".")
    return "eval" in parts or any(part == "eval" or part.startswith("eval_") for part in parts)


def collect_sources() -> list[Path]:
    """生产集收集：仓根 *.py（不含本脚本）+ memory/**/*.py（若已注入）。"""
    sources = [p for p in sorted(ROOT.glob("*.py")) if p.name != "build_prod.py"]
    memory_dir = ROOT / "memory"
    if memory_dir.is_dir():
        sources.extend(sorted(memory_dir.rglob("*.py")))
    return sources


def main() -> int:
    """生产构建主流程（R18 评测钩子剥离：判据命中即排除/记 issue）。

    why 先收集后裁决、issues 非空即整体失败：生产产物是信任边界，「部分剥离」
    的半拉产物比构建失败更危险——dist 只在零 issue 时存在（清底重建 + 失败即删）。
    """
    copied: list[str] = []
    excluded: list[str] = []
    issues: list[str] = []
    if OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)  # 清底重建：dist 状态只反映本次生产集
    for source in collect_sources():
        rel = source.relative_to(ROOT)
        content = source.read_text(encoding="utf-8")
        rel_posix = rel.as_posix()
        if is_eval_named(rel):
            excluded.append(rel_posix)
            continue
        if has_eval_marker_line(content):
            # 双保险：非 eval 命名文件携带行首标记行 → 判据歧义，硬失败（不静默剥离）
            issues.append(
                f"{rel_posix}: 携带 {EVAL_ONLY_MARKER} 行首标记但非 eval 命名/路径"
                f"（R18 双保险 fail-closed，禁止静默排除）"
            )
            continue
        modules: list[str] = [m.group(1) for m in FROM_IMPORT.finditer(content)]
        for plain in PLAIN_IMPORT.finditer(content):
            modules.extend(part.strip() for part in plain.group(1).split(",") if part.strip())
        for module in modules:
            if is_eval_module(module):
                issues.append(f'{rel_posix}: 引用评测钩子模块 "{module}"（R18 fail-closed，生产产物禁止携带）')
        target = OUT_DIR / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        copied.append(rel_posix)
    if issues:
        if OUT_DIR.exists():
            shutil.rmtree(OUT_DIR)  # 拒绝产出半拉产物
        print(json.dumps({"ok": False, "issues": issues}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1
    print(json.dumps({"ok": True, "copied": len(copied), "excluded": excluded, "out": str(OUT_DIR)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
