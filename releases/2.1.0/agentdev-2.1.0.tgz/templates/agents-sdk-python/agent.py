"""agent '{{AGENT_NAME}}' 可启动入口（CLI）。

由 agentdev agent_scaffold 从模板 '{{TEMPLATE_ID}}' 渲染生成：
agent 名称与 description 来自 approved agent-spec，审批 hash 绑定见 SPEC_HASH。

Usage:
    python agent.py --task "your input"
    python agent.py --serve    # 服务模式（v0 为 stub，仅回报模式声明）

环境变量:
    AGENTDEV_TRACE_FILE        trace JSONL 落盘路径（缺省 ./trace.jsonl）
    AGENTDEV_MODEL_API_KEY     真实模型接线用（演示实现不依赖）
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict, Optional, Sequence

from demo_agent import run_task
from tracing import emit_complete, emit_task_start, new_run_id

AGENT_NAME = "{{AGENT_NAME}}"
"""agent 名称（来自 spec.identity.name；渲染后与本注释之外的占位符替换一致）。"""

AGENT_DESCRIPTION = "{{AGENT_DESCRIPTION_ESC}}"
"""agent 描述（来自 spec.identity.description；JSON 转义保证任意文本安全嵌入）。"""

SPEC_HASH = "{{SPEC_HASH}}"
"""来源 spec 的审批绑定 hash（U3；可追溯生成基线）。"""

TEMPLATE_ID = "{{TEMPLATE_ID}}"
"""生成所用模板 id。"""

GENERATED_AT = "{{GENERATED_AT}}"
"""生成时间（ISO 8601，与部署清单 generatedAt 同源）。"""


def build_parser() -> argparse.ArgumentParser:
    """构建 CLI 参数解析器（--task 任务输入；--serve 服务模式 stub）。"""
    parser = argparse.ArgumentParser(
        prog="agent.py",
        description=(AGENT_DESCRIPTION or "agentdev scaffolded agent") + " | spec: " + SPEC_HASH,
    )
    parser.add_argument("--task", type=str, default=None, help="任务输入文本（CLI 模式必填）")
    parser.add_argument("--serve", action="store_true", help="服务模式（v0 为 stub，仅回报模式声明）")
    return parser


def run_cli(task_input: str, task_id: str = "cli") -> Dict[str, Any]:
    """执行一次任务并发射 task_start / complete 事件，返回结构化结果。

    任务异常时发射 complete(status=error) 后原样上抛（发射器不吞错）。
    """
    run_id = new_run_id()
    emit_task_start(run_id, task_id)
    try:
        output = run_task(task_input)
    except Exception as err:
        emit_complete(run_id, task_id, "error", error=str(err))
        raise
    emit_complete(run_id, task_id, "ok")
    return {"agent": AGENT_NAME, "run_id": run_id, "task_id": task_id, "output": output}


def main(argv: Optional[Sequence[str]] = None) -> int:
    """CLI 主入口：--serve 回报 stub 声明；--task 执行单次任务并打印结果 JSON。"""
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.serve:
        # 服务模式留 stub（v0）：CLI 是唯一保证可跑的入口，服务化接线留后续版本
        print(json.dumps({"agent": AGENT_NAME, "mode": "serve", "status": "stub"}, ensure_ascii=False))
        return 0
    if not args.task:
        parser.error("--task 必填（或使用 --serve 查看服务模式 stub）")
        return 2
    result = run_cli(args.task)
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:  # CLI 边界兜底：错误落 stderr 非零退出，绝不静默
        print("agent failed: " + str(exc), file=sys.stderr)
        sys.exit(1)
