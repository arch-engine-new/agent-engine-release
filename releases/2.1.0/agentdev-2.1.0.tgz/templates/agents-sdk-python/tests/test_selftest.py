"""模板自测（pytest，零外部依赖：不装 langgraph 运行时、不调 LLM）。

覆盖（与 agentdev task-9 验收对齐）：
- 发射器：五类事件 JSONL 形状，对 trace-schema.json 手写断言（跨语言契约镜像）；
- 入口：CLI 子进程可跑、发射的 trace 含 task_start/complete（R2-F8）；
- 评测桩：报告键集与协议层 TaskGateResult/ChannelGateResult 精确一致（结构对齐）；
- 渲染安全：AGENT_NAME 等模块常量在「模板源态」与「渲染后态」都成立。
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

TEMPLATE_ROOT = Path(__file__).resolve().parents[1]
if str(TEMPLATE_ROOT) not in sys.path:
    sys.path.insert(0, str(TEMPLATE_ROOT))

import agent  # noqa: E402
import demo_agent  # noqa: E402
import eval_stub  # noqa: E402
import tracing  # noqa: E402

ISO_TS_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$")
EVENT_TYPE_ENUM = frozenset(("task_start", "tool_call", "llm_call", "assertion", "complete"))
# 各事件类型专有必填字段（公共必填 type/ts/run_id/task_id 之外；对齐 trace-schema.json）
TYPE_REQUIRED: Dict[str, set] = {
    "task_start": set(),
    "tool_call": {"tool", "args_digest"},
    "llm_call": {"model"},
    "assertion": {"assertion_id", "passed"},
    "complete": {"status"},
}


def assert_event_contract(event: Dict[str, Any]) -> None:
    """手写断言：单条事件满足 trace-schema 必填/类型/枚举（与 TS 校验器同口径）。"""
    for key in ("type", "ts", "run_id", "task_id"):
        assert key in event, "缺公共必填字段 " + key
    assert event["type"] in EVENT_TYPE_ENUM
    assert isinstance(event["ts"], str) and ISO_TS_PATTERN.match(event["ts"]) is not None
    assert isinstance(event["run_id"], str) and event["run_id"]
    assert isinstance(event["task_id"], str) and event["task_id"]
    for key in TYPE_REQUIRED[event["type"]]:
        assert key in event, event["type"] + " 缺专有必填字段 " + key
    if event["type"] == "complete":
        assert event["status"] in ("ok", "error")
    if event["type"] == "assertion":
        assert isinstance(event["passed"], bool)
    if event["type"] == "tool_call":
        assert isinstance(event["args_digest"], str) and event["args_digest"]


def read_events(trace_path: Path) -> List[Dict[str, Any]]:
    """读 JSONL 为事件列表（空白行容忍；坏行显性失败）。"""
    events = []
    for line in trace_path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            events.append(json.loads(line))
    return events


def test_demo_agent_runs_offline() -> None:
    """演示 agent 离线可跑：回显 + 词数（自测不依赖外部 API）。"""
    output = demo_agent.run_task("hello world")
    assert "echo" in output
    assert "2" in output


def test_agent_module_consts_render_safe() -> None:
    """模块常量在模板源态（未渲染）即合法：渲染后同断言成立（占位符形态也是非空字符串）。"""
    assert isinstance(agent.AGENT_NAME, str) and agent.AGENT_NAME
    assert isinstance(agent.AGENT_DESCRIPTION, str)
    # 模板源态为占位符 token；渲染后为 sha256: 前缀 hash——两种形态都必须是非空字符串
    assert isinstance(agent.SPEC_HASH, str) and agent.SPEC_HASH
    assert agent.SPEC_HASH == "" or agent.SPEC_HASH.startswith("sha256:") or agent.SPEC_HASH.startswith("{")
    assert isinstance(agent.TEMPLATE_ID, str) and agent.TEMPLATE_ID


def test_tracer_emits_contract_shaped_jsonl(tmp_path: Path) -> None:
    """发射器五类事件全部满足 trace-schema 手写断言；敏感入参只落摘要。"""
    trace = tmp_path / "trace.jsonl"
    run_id = tracing.new_run_id()
    tracing.emit_task_start(run_id, "t1", trace_path=trace)
    tracing.emit_tool_call(run_id, "t1", "echo", {"raw": "secret-input"}, trace_path=trace)
    tracing.emit_llm_call(run_id, "t1", "demo-model", tokens_in=1, tokens_out=2, trace_path=trace)
    tracing.emit_assertion(run_id, "t1", "a0", True, trace_path=trace)
    tracing.emit_complete(run_id, "t1", "ok", trace_path=trace)
    events = read_events(trace)
    assert len(events) == 5
    for event in events:
        assert_event_contract(event)
    assert events[0]["type"] == "task_start"
    assert events[-1]["type"] == "complete"
    assert str(events[1]["args_digest"]).startswith("sha256:")
    assert "secret-input" not in trace.read_text(encoding="utf-8")


def test_emit_complete_rejects_unknown_status(tmp_path: Path) -> None:
    """status 枚举在发射侧先于校验器拦截（fail-closed 镜像）。"""
    import pytest

    with pytest.raises(ValueError):
        tracing.emit_complete(tracing.new_run_id(), "t1", "maybe", trace_path=tmp_path / "x.jsonl")


def test_cli_entry_runnable(tmp_path: Path) -> None:
    """CLI 入口可启动：--task 跑通、stdout 结果 JSON 可解析、trace 完整性成立。"""
    trace = tmp_path / "cli-trace.jsonl"
    env = dict(os.environ)
    env["AGENTDEV_TRACE_FILE"] = str(trace)
    proc = subprocess.run(
        [sys.executable, str(TEMPLATE_ROOT / "agent.py"), "--task", "hello trace"],
        capture_output=True,
        text=True,
        env=env,
        timeout=60,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr
    payload = json.loads(proc.stdout.strip().splitlines()[-1])
    assert "echo" in payload["output"]
    assert payload["agent"] == agent.AGENT_NAME
    events = read_events(trace)
    assert any(event["type"] == "task_start" for event in events)
    assert any(event["type"] == "complete" and event["status"] == "ok" for event in events)
    for event in events:
        assert_event_contract(event)


def test_eval_stub_report_shape_matches_protocol(tmp_path: Path) -> None:
    """评测桩报告键集与协议层 ChannelGateResult/TaskGateResult/RunGateEntry 精确一致。"""
    trace = tmp_path / "eval-trace.jsonl"
    report_path = tmp_path / "report.json"
    env = dict(os.environ)
    env["AGENTDEV_TRACE_FILE"] = str(trace)
    proc = subprocess.run(
        [sys.executable, str(TEMPLATE_ROOT / "eval_stub.py"), "--runs", "2", "--out", str(report_path)],
        capture_output=True,
        text=True,
        env=env,
        timeout=60,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert set(report.keys()) >= {"channel", "tasks", "passed"}
    assert report["channel"] == "self-written"
    assert report["passed"] is True
    for task in report["tasks"]:
        assert set(task.keys()) - {"failReason"} == set(eval_stub.TASK_GATE_KEYS)
        assert task["threshold"] == eval_stub.DEFAULT_PASS_RATIO_THRESHOLD
        assert task["passed"] is True
        assert task["totalRuns"] == 2
        for run_entry in task["runs"]:
            assert set(run_entry.keys()) == set(eval_stub.RUN_GATE_KEYS)
    events = read_events(trace)
    assert any(event["type"] == "task_start" for event in events)
    assert any(event["type"] == "complete" for event in events)
    for event in events:
        assert_event_contract(event)


def test_eval_stub_fail_path_fail_closed(tmp_path: Path) -> None:
    """失败路径：断言不过 → 任务/通道 passed=false + failReason 在场（fail-closed 对齐）。"""
    task_set = tmp_path / "tasks.json"
    task_set.write_text(
        json.dumps([{"id": "t-fail", "input": "hello", "assertions": [{"type": "contains", "value": "NEVER"}]}]),
        encoding="utf-8",
    )
    report_path = tmp_path / "fail-report.json"
    env = dict(os.environ)
    env["AGENTDEV_TRACE_FILE"] = str(tmp_path / "trace.jsonl")
    proc = subprocess.run(
        [sys.executable, str(TEMPLATE_ROOT / "eval_stub.py"), "--tasks", str(task_set), "--runs", "1", "--out", str(report_path)],
        capture_output=True,
        text=True,
        env=env,
        timeout=60,
        check=False,
    )
    assert proc.returncode == 1, "通道不过必须以退出码 1 表达（门禁语义）"
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["passed"] is False
    assert isinstance(report.get("failReason"), str)
    task = report["tasks"][0]
    assert task["passed"] is False
    assert isinstance(task.get("failReason"), str)
