# install.ps1 - agentdev one-command MACHINE (user-level) install for Windows PowerShell.
#
# Steps (mirrors install.sh on POSIX):
#   1. node check (>= 22)
#   2. npm ci (layout-adaptive: commercial package root if .\package.json exists,
#      else agentdev\mcp dev-mode entry deps: tsx + MCP SDK)
#   3. agentdev/install-global.mjs: agentdev-mcp registered into every supported
#      platform's USER-LEVEL MCP config (merge semantics; existing config files
#      backed up before first write; no AGENTDEV_PROJECT_ROOT is set - project
#      root is discovered at runtime by walking up to the nearest .agentdev/
#      marker) + eight agentdev-* commands distributed to each platform's
#      user-level command directory (~\.claude\commands, ~\.cursor\commands, ...)
#   4. smoke: bare stdio boot handshake (initialize -> tools/list = 7 tools)
#
# Usage:
#   .\install.ps1                        # full install (all seven platforms)
#   .\install.ps1 -DryRun                # preview only (skips npm ci and smoke)
#   .\install.ps1 -Uninstall             # remove agentdev-* registrations + commands
#   .\install.ps1 --ide=cursor           # limit scope (flag forwarded to core)
#
# Rollback: .\install.ps1 -Uninstall  (agentdev-* only; other entries kept)
param(
  [switch]$DryRun,
  [switch]$Uninstall
)
$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$core = Join-Path $repoRoot "agentdev\install-global.mjs"
$mcpDir = Join-Path $repoRoot "agentdev\mcp"

if (-not (Test-Path $core)) {
  Write-Host "ERROR: install: core script not found: $core" -ForegroundColor Red
  exit 1
}

# Forward extra args verbatim (e.g. --ide=cursor / --repo-root=...); native
# switches translate to the core's flag spellings
$forward = @()
foreach ($a in $args) { $forward += $a }
if ($DryRun) { $forward += "--dry-run" }
if ($Uninstall) { $forward += "--uninstall" }

# [1/4] node check
$nodeCmd = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeCmd) {
  Write-Host "ERROR: install: node not found on PATH - install Node.js >= 22 first: https://nodejs.org/" -ForegroundColor Red
  exit 2
}
$nodeVersion = (node --version).Trim()   # e.g. v22.11.0 (no nested quoting: PS 5.1 native arg passing eats inner quotes)
$nodeMajor = [int]$nodeVersion.TrimStart('v').Split('.')[0]
if ($nodeMajor -lt 22) {
  Write-Host "ERROR: install: Node >= 22 required, found $nodeVersion" -ForegroundColor Red
  exit 2
}
Write-Host "==> [1/4] node $nodeVersion OK"

# [2/4] deps (not exercised by a dry-run preview).
# Layout-adaptive (ships unchanged inside the v2.1.0 commercial package): package
# root has package.json -> npm ci at package root (compiled mcp\src\index.js entry);
# repo layout -> npm ci in agentdev\mcp (dev tsx entry).
if ($DryRun) {
  Write-Host "==> [2/4] skip npm ci (-DryRun preview needs no deps)"
} elseif (Test-Path (Join-Path $repoRoot "package.json")) {
  Write-Host "==> [2/4] npm ci (commercial package root)"
  Push-Location $repoRoot
  try { npm ci } finally { Pop-Location }
  if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: install: npm ci failed (exit $LASTEXITCODE) - nothing was written to any config" -ForegroundColor Red
    exit 1
  }
} else {
  Write-Host "==> [2/4] npm ci (agentdev\mcp)"
  Push-Location $mcpDir
  try { npm ci } finally { Pop-Location }
  if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: install: npm ci failed (exit $LASTEXITCODE) - nothing was written to any config" -ForegroundColor Red
    exit 1
  }
}

# [3/4] user-level registration + command distribution (core fail-closed: any
# broken target config -> nonzero exit and NOTHING is written)
Write-Host "==> [3/4] user-level registration (MCP x7 + eight commands)"
node $core @forward
if ($LASTEXITCODE -ne 0) {
  Write-Host "ERROR: install: registration failed (exit $LASTEXITCODE)" -ForegroundColor Red
  exit 1
}

# [4/4] smoke (install/upgrade only)
if ($DryRun) {
  Write-Host "==> [4/4] skip smoke (-DryRun)"
} elseif ($Uninstall) {
  Write-Host "==> [4/4] skip smoke (-Uninstall)"
} else {
  Write-Host "==> [4/4] smoke: stdio boot handshake"
  node $core --smoke
  if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: install: smoke failed - registrations were written but the runtime did not verify." -ForegroundColor Red
    Write-Host "       Fix the error above and re-run, or roll back: .\install.ps1 -Uninstall (agentdev-* only; other entries kept)." -ForegroundColor Red
    exit 1
  }
}
Write-Host "install: done"
