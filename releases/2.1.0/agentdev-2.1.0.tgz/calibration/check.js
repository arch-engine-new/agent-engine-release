/**
 * 校准集 v0 结构校验器（held-out 质量门 L1，spec §5.6 + Task 6）。
 *
 * 职责：对 `domains/<domain>/tasks.json` 两域校准集与 `routing.json` 域路由表做
 * fail-closed 结构校验，全过 exit 0，任一问题 exit 1 并逐条列出。本脚本是
 * release-checklist.md 的 L1 门禁执行器——L1 不过，校准集不得发布。
 *
 * 校验判据（与协议层对齐，勿随意放宽）：
 * - 每域任务数 ≥ 8（held-out 集门槛，高于协议层自写集的 MIN_TASKS_PER_DOMAIN=5）；
 * - 断言类型仅限 exact/contains/regex（U6 裁决：semantic/manual 不入校准通道——
 *   校准集是双人评审的金标准，语义判定不可复现，不构成金标准）；
 * - 机械判据承载字段与协议层 SpecAssertion 一致（value），regex 额外要求可编译；
 * - 断言集与金标准一致：每任务全部断言按协议层同语义（exact=全等不 trim、
 *   contains=子串、regex=无标志 test，见 protocol/assertions.ts 的
 *   evaluateMechanicalCriteria）对 ground_truth.expected 求值必须全部通过——
 *   金标准自身过不了断言集即「断言与金标准矛盾」（不存在能通过全部断言的输出，
 *   dp-005 v0 评审发现的致命类缺陷），fail-closed 拦截；
 * - ground_truth 双人评审：reviewers 恰 2 人、不同人（同一人不构成双评）；
 * - version 存在且 semver（任务集变更必须升版本，见 release-checklist.md）；
 * - 任务 id 域内不重复；文件级 domain 与目录一致；
 * - routing.json：受控三域映射完整且各出现一次；workflow-automation 因 v0 无专属
 *   校准集必须带 fallback: true 兜底标注；default_domain 必须为 general（未匹配域
 *   统一兜底）；兜底不降级——路由兜底仍走双通道，只是 held-out 通道换用 general 集。
 *
 * 结构兼容性：任务条目含协议层 EvalTask 全部必填字段（id/input/step_constraints/
 * assertions，判据字段同 SpecAssertion.value），另加校准集扩展字段 ground_truth
 * （校准集是独立数据资产，不内嵌进 agent-spec，故不受 schema additionalProperties
 * 约束；若未来回填 spec，剥除 ground_truth 即结构兼容）。
 *
 * 零第三方依赖；CommonJS（仓库根无 package.json，.js 默认 CJS）。Node >= 22。
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');

/** 每域最少任务数（held-out 校准集 v0 门槛） */
const MIN_TASKS_PER_DOMAIN = 8;

/** 校准通道允许的断言类型（U6：semantic/manual 不入校准通道） */
const MECHANICAL_ASSERTION_TYPES = ['exact', 'contains', 'regex'];

/** 受控域枚举运行时镜像（镜像 protocol/types.ts 的 DomainCategory，两处漂移即路由失效） */
const KNOWN_DOMAINS = ['doc-processing', 'workflow-automation', 'general'];

/** 兜底域：v0 未匹配域与 workflow-automation 均兜底到此域 */
const FALLBACK_DOMAIN = 'general';

/** v0 无专属校准集、必须以 fallback 兜底标注的域 */
const REQUIRED_FALLBACK_DOMAIN = 'workflow-automation';

/** 语义化版本（发布门要求任务集/路由表均可版本化追溯） */
const SEMVER_PATTERN = /^\d+\.\d+\.\d+$/;

/** 任务 id 形态（与 protocol/agent-spec.schema.json 的 EvalTask.id pattern 一致） */
const TASK_ID_PATTERN = /^[a-z0-9][a-z0-9._-]*$/;

/** 评审日期：ISO 8601 日期（允许带时间部分） */
const REVIEWED_AT_PATTERN = /^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2})?)?$/;

/** 两域校准集相对路径（routing.json 兜底与 L1 直读共用，单一真源） */
const DOMAIN_SET_PATHS = {
  'doc-processing': 'domains/doc-processing/tasks.json',
  general: 'domains/general/tasks.json',
};

/**
 * 读取并解析 JSON 文件。
 * fail-closed：文件缺失或解析失败不抛异常，返回 { ok: false, error }，由调用方汇总成
 * 逐条错误——发布门宁可报错阻断，也不容忍半可用的校准集静默通过。
 * @param {string} filePath 文件绝对路径
 * @returns {{ ok: boolean, data?: unknown, error?: string }}
 */
function readJsonFile(filePath) {
  let raw;
  try {
    raw = fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    // 读取失败（不存在/无权限）必须显性上报，禁止静默跳过
    return { ok: false, error: `文件不可读: ${err.message}` };
  }
  try {
    return { ok: true, data: JSON.parse(raw) };
  } catch (err) {
    // 解析失败同样 fail-closed：坏 JSON 不是合法校准集
    return { ok: false, error: `JSON 解析失败: ${err.message}` };
  }
}

/** 防御性判断：非空字符串（运行时数据不可信，校验入口统一收口） */
function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

/**
 * 校验单域校准集文档（文件级 + 逐任务），返回错误列表（空数组即通过）。
 * @param {unknown} doc 解析后的 tasks.json
 * @param {string} expectedDomain 文件所在目录对应的域（文件级 domain 必须一致）
 * @param {string} label 错误定位前缀（如 "doc-processing/tasks.json"）
 * @returns {string[]}
 */
function validateTasksDocument(doc, expectedDomain, label) {
  const errors = [];
  if (doc === null || typeof doc !== 'object' || Array.isArray(doc)) {
    return [`${label}: 顶层必须是对象`];
  }

  // 版本化是发布门硬要求：无版本的任务集变更不可追溯
  if (!isNonEmptyString(doc.version)) {
    errors.push(`${label}: 缺少 version 字段`);
  } else if (!SEMVER_PATTERN.test(doc.version)) {
    errors.push(`${label}: version "${doc.version}" 不是 semver（应为 x.y.z）`);
  }

  // 文件级 domain 必须与目录一致：跨域错放会让路由表指向错误校准集
  if (doc.domain !== expectedDomain) {
    errors.push(`${label}: domain "${String(doc.domain)}" 与预期域 "${expectedDomain}" 不一致`);
  }

  if (!Array.isArray(doc.tasks)) {
    errors.push(`${label}: tasks 必须是数组`);
    return errors; // tasks 缺失时逐任务校验无从谈起，就此收口（其余问题已在上文暴露）
  }
  if (doc.tasks.length < MIN_TASKS_PER_DOMAIN) {
    errors.push(
      `${label}: 任务数 ${doc.tasks.length} < ${MIN_TASKS_PER_DOMAIN}（held-out 集样本过少无统计意义）`
    );
  }

  // id 域内唯一性：重复 id 会让评测报告与门禁判定无法定位到唯一任务
  const seenIds = new Set();
  doc.tasks.forEach((task, index) => {
    const location = `${label}#tasks[${index}]`;
    const idErrors = validateTaskEntry(task, location, seenIds);
    errors.push(...idErrors);
  });

  return errors;
}

/**
 * 校验单个任务条目（协议层 EvalTask 全字段 + ground_truth 扩展）。
 * @param {unknown} task 任务对象
 * @param {string} location 错误定位前缀
 * @param {Set<string>} seenIds 同域已见任务 id 集合（用于唯一性判定）
 * @returns {string[]}
 */
function validateTaskEntry(task, location, seenIds) {
  const errors = [];
  if (task === null || typeof task !== 'object' || Array.isArray(task)) {
    return [`${location}: 任务必须是对象`];
  }

  // id：非空 + 形态与协议层一致 + 域内唯一（三重校验缺一不可）
  if (!isNonEmptyString(task.id)) {
    errors.push(`${location}: 缺少 id`);
  } else {
    if (!TASK_ID_PATTERN.test(task.id)) {
      errors.push(`${location}: id "${task.id}" 不匹配 ${TASK_ID_PATTERN}`);
    }
    if (seenIds.has(task.id)) {
      errors.push(`${location}: 任务 id "${task.id}" 在域内重复`);
    }
    seenIds.add(task.id);
  }

  // input：任务输入原文，内联 fixtures（校准集自包含，禁止外部文件引用）
  if (!isNonEmptyString(task.input)) {
    errors.push(`${location}(${String(task.id)}): input 必须是非空字符串（内联任务输入）`);
  }

  // step_constraints：协议层 EvalTask 必填字段，结构兼容性校验点之一
  if (!Array.isArray(task.step_constraints)) {
    errors.push(`${location}(${String(task.id)}): step_constraints 必须是数组（协议层 EvalTask 必填）`);
  } else if (task.step_constraints.some((item) => !isNonEmptyString(item))) {
    errors.push(`${location}(${String(task.id)}): step_constraints 含非空字符串以外的元素`);
  }

  // assertions：金标准判据，空断言任务无法判定任何输出
  if (!Array.isArray(task.assertions) || task.assertions.length === 0) {
    errors.push(`${location}(${String(task.id)}): assertions 必须是非空数组`);
  } else {
    task.assertions.forEach((assertion, aIndex) => {
      errors.push(...validateAssertionEntry(assertion, `${location}(${String(task.id)}).assertions[${aIndex}]`));
    });
  }

  // ground_truth：双人评审金标准记录（校准集区别于普通任务集的核心字段）
  errors.push(...validateGroundTruth(task.ground_truth, `${location}(${String(task.id)}).ground_truth`));

  // 断言 vs 金标准一致性：全部断言必须能对 ground_truth.expected 通过（协议层同语义求值）。
  // expected 缺失/非字符串时结构问题已由 validateGroundTruth 报过，此处跳过避免重复报错。
  if (
    Array.isArray(task.assertions) &&
    task.assertions.length > 0 &&
    task.ground_truth !== null &&
    typeof task.ground_truth === 'object' &&
    !Array.isArray(task.ground_truth) &&
    isNonEmptyString(task.ground_truth.expected)
  ) {
    errors.push(
      ...validateAssertionsAgainstGroundTruth(task.assertions, task.ground_truth.expected, `${location}(${String(task.id)})`)
    );
  }

  return errors;
}

/**
 * 断言 vs 金标准一致性校验：每条机械断言对金标准 expected 按协议层同语义求值，
 * 任一不过即断言集与金标准矛盾——不存在能同时通过全部断言的输出，评测必然误杀
 * 正确输出，必须在发布门拦截（fail-closed）。
 *
 * 求值语义与 protocol/assertions.ts 的 evaluateMechanicalCriteria 逐字对齐：
 * exact=全等（不 trim）、contains=子串、regex=new RegExp(criteria).test(expected)
 * （无标志）。两处语义漂移即校准门与评测执行判负口径分叉，禁止单边修改。
 *
 * @param {unknown[]} assertions 断言数组（结构合法性已由 validateAssertionEntry 单独校验）
 * @param {string} expected 金标准期望输出
 * @param {string} location 错误定位前缀（任务级，不含 .assertions 段）
 * @returns {string[]}
 */
function validateAssertionsAgainstGroundTruth(assertions, expected, location) {
  const errors = [];
  assertions.forEach((assertion, aIndex) => {
    // 结构非法/类型非法/判据缺失的问题已由 validateAssertionEntry 报过，此处跳过，
    // 只对「结构合法且可求值」的断言做一致性判定，避免叠加误导性错误
    if (
      assertion === null ||
      typeof assertion !== 'object' ||
      Array.isArray(assertion) ||
      !MECHANICAL_ASSERTION_TYPES.includes(assertion.type) ||
      !isNonEmptyString(assertion.value)
    ) {
      return;
    }
    if (!evaluateAssertionAgainstExpected(assertion.type, assertion.value, expected)) {
      errors.push(
        `${location}.assertions[${aIndex}]: ${assertion.type} 断言对金标准 expected 求值不通过` +
          '（断言与金标准矛盾，金标准自身无法通过全部断言，不存在可满足的输出）'
      );
    }
  });
  return errors;
}

/**
 * 按协议层同语义对金标准 expected 求值单条机械断言（exact/contains/regex）。
 * @param {'exact'|'contains'|'regex'} type 断言类型
 * @param {string} criteria 判据（assertion.value）
 * @param {string} expected 金标准期望输出
 * @returns {boolean} true=该断言对 expected 通过
 */
function evaluateAssertionAgainstExpected(type, criteria, expected) {
  if (type === 'exact') {
    return expected === criteria; // 全等不 trim，与协议层最严口径一致
  }
  if (type === 'contains') {
    return expected.includes(criteria);
  }
  try {
    return new RegExp(criteria).test(expected); // 无标志编译：与协议层求值同口径
  } catch {
    // 不可编译已由 validateAssertionEntry 单独报错；一致性判定 fail-closed 不放行
    return false;
  }
}

/**
 * 校验单条机械断言（类型收窄 + 判据在场 + regex 可编译）。
 * @param {unknown} assertion 断言对象
 * @param {string} location 错误定位前缀
 * @returns {string[]}
 */
function validateAssertionEntry(assertion, location) {
  const errors = [];
  if (assertion === null || typeof assertion !== 'object' || Array.isArray(assertion)) {
    return [`${location}: 断言必须是对象`];
  }

  // U6 fail-closed：semantic/manual 一律拒绝——金标准判据必须可机械复现，
  // 语义判定依赖判官模型、不可复现，不得作为校准集判据
  if (!MECHANICAL_ASSERTION_TYPES.includes(assertion.type)) {
    errors.push(
      `${location}: 断言类型 "${String(assertion.type)}" 不在 ${MECHANICAL_ASSERTION_TYPES.join('/')} 内` +
        '（semantic/manual 不入校准通道）'
    );
    return errors; // 类型非法时判据校验无意义，避免叠加误导性错误
  }

  // 机械判据承载字段与协议层 SpecAssertion 一致（value），空判据即恒真断言
  if (!isNonEmptyString(assertion.value)) {
    errors.push(`${location}: ${assertion.type} 断言缺少非空 value 判据`);
  } else if (assertion.type === 'regex') {
    // regex 判据必须可编译：坏模式在评测执行期才会爆雷，提前在发布门拦截
    try {
      new RegExp(assertion.value);
    } catch (err) {
      errors.push(`${location}: regex 不可编译（${err.message}）`);
    }
  }

  return errors;
}

/**
 * 校验 ground_truth 双人评审记录。
 * @param {unknown} groundTruth ground_truth 对象
 * @param {string} location 错误定位前缀
 * @returns {string[]}
 */
function validateGroundTruth(groundTruth, location) {
  const errors = [];
  if (groundTruth === null || typeof groundTruth !== 'object' || Array.isArray(groundTruth)) {
    return [`${location}: 缺少 ground_truth（校准集任务必须携带双人评审金标准）`];
  }

  // expected：金标准期望输出（同输入同期望，确定性锚点）
  if (!isNonEmptyString(groundTruth.expected)) {
    errors.push(`${location}: expected 必须是非空字符串`);
  }

  // reviewers：恰 2 人且不同人——单人评审无交叉校验，同一个人签两次同样无效
  const reviewers = groundTruth.reviewers;
  if (!Array.isArray(reviewers) || reviewers.length !== 2) {
    errors.push(`${location}: reviewers 必须恰为 2 人（双人评审）`);
  } else if (reviewers.some((name) => !isNonEmptyString(name))) {
    errors.push(`${location}: reviewers 含非空字符串以外的元素`);
  } else if (reviewers[0] === reviewers[1]) {
    errors.push(`${location}: reviewers 两人相同（"${String(reviewers[0])}"），不构成双评`);
  }

  // reviewed_at：可解析的 ISO 日期，评审记录需可追溯时间线
  if (!isNonEmptyString(groundTruth.reviewed_at)) {
    errors.push(`${location}: reviewed_at 必须是 ISO 日期字符串`);
  } else {
    const isShaped = REVIEWED_AT_PATTERN.test(groundTruth.reviewed_at);
    // 形态 + 语义双重校验：正则过但日期不存在（如 2026-02-30）同样拒绝
    if (!isShaped || Number.isNaN(Date.parse(groundTruth.reviewed_at))) {
      errors.push(`${location}: reviewed_at "${groundTruth.reviewed_at}" 不是合法 ISO 日期`);
    }
  }

  return errors;
}

/**
 * 校验域路由表（映射完整性 + 兜底标注 + 被引文件可用性）。
 * @param {unknown} routing 解析后的 routing.json
 * @param {string} baseDir 校准目录绝对路径（解析校准集相对路径用）
 * @returns {string[]}
 */
function validateRoutingDocument(routing, baseDir) {
  const label = 'routing.json';
  const errors = [];
  if (routing === null || typeof routing !== 'object' || Array.isArray(routing)) {
    return [`${label}: 顶层必须是对象`];
  }

  if (!isNonEmptyString(routing.version)) {
    errors.push(`${label}: 缺少 version 字段`);
  } else if (!SEMVER_PATTERN.test(routing.version)) {
    errors.push(`${label}: version "${routing.version}" 不是 semver（应为 x.y.z）`);
  }

  // 未匹配域统一兜底到 general（spec §5.1）：default_domain 非 general 即兜底链断裂
  if (routing.default_domain !== FALLBACK_DOMAIN) {
    errors.push(`${label}: default_domain 必须是 "${FALLBACK_DOMAIN}"（未匹配域的统一兜底）`);
  }

  if (!Array.isArray(routing.routes) || routing.routes.length === 0) {
    errors.push(`${label}: routes 必须是非空数组`);
    return errors;
  }

  // 映射完整性：受控三域各出现恰好一次，多映射/漏映射都会让路由不确定
  const seenRouteDomains = new Map(); // domain -> route
  routing.routes.forEach((route, index) => {
    const location = `${label}#routes[${index}]`;
    if (route === null || typeof route !== 'object' || Array.isArray(route)) {
      errors.push(`${location}: 路由项必须是对象`);
      return;
    }
    if (!KNOWN_DOMAINS.includes(route.domain)) {
      errors.push(`${location}: domain "${String(route.domain)}" 不在受控枚举 ${KNOWN_DOMAINS.join('/')} 内`);
      return;
    }
    if (seenRouteDomains.has(route.domain)) {
      errors.push(`${location}: 域 "${route.domain}" 重复映射`);
    }
    seenRouteDomains.set(route.domain, route);

    if (!isNonEmptyString(route.calibration_set)) {
      errors.push(`${location}: calibration_set 必须是非空字符串（校准集文件相对路径）`);
    }
    // fallback 必须是严格 boolean：宽松真值（"false" 字符串等）会让兜底判定不可靠
    if (typeof route.fallback !== 'boolean') {
      errors.push(`${location}: fallback 必须是 boolean`);
    }
  });

  for (const domain of KNOWN_DOMAINS) {
    if (!seenRouteDomains.has(domain)) {
      errors.push(`${label}: 受控域 "${domain}" 缺少路由映射`);
    }
  }

  // v0 裁决：workflow-automation 无专属校准集，必须显式 fallback 兜底（不静默错映射）
  const workflowRoute = seenRouteDomains.get(REQUIRED_FALLBACK_DOMAIN);
  if (workflowRoute && workflowRoute.fallback !== true) {
    errors.push(
      `${label}: 域 "${REQUIRED_FALLBACK_DOMAIN}" v0 无专属校准集，必须标注 fallback: true（路由到 general 兜底）`
    );
  }

  // 逐路由落地检查：被引文件存在、可解析、域归属与兜底语义一致
  for (const [domain, route] of seenRouteDomains) {
    if (!isNonEmptyString(route.calibration_set)) {
      continue; // 路径缺失已在上文报错，此处跳过文件探测避免重复错误
    }
    const resolved = path.resolve(baseDir, route.calibration_set);
    const file = readJsonFile(resolved);
    if (!file.ok) {
      errors.push(`${label}: 域 "${domain}" 指向的校准集 ${route.calibration_set} ${file.error}`);
      continue;
    }
    const setData = file.data;
    const fileDomain = setData && typeof setData === 'object' ? setData.domain : undefined;
    if (route.fallback === true) {
      // 兜底路由只能指向 general 集：指向其他域的集是错映射而非兜底
      if (fileDomain !== FALLBACK_DOMAIN) {
        errors.push(
          `${label}: 域 "${domain}" 的兜底路由必须指向 ${FALLBACK_DOMAIN} 域校准集，实得 domain "${String(fileDomain)}"`
        );
      }
    } else if (fileDomain !== domain) {
      errors.push(
        `${label}: 域 "${domain}" 的非兜底路由指向的校准集 domain 为 "${String(fileDomain)}"，两者必须一致`
      );
    }
  }

  return errors;
}

/**
 * 汇总执行全部 L1 校验（两域任务集 + 路由表），返回完整错误列表。
 * @param {string} baseDir 校准目录绝对路径（即本文件所在目录）
 * @returns {string[]}
 */
function collectValidationErrors(baseDir) {
  const errors = [];

  for (const domain of ['doc-processing', 'general']) {
    const relativePath = DOMAIN_SET_PATHS[domain];
    const file = readJsonFile(path.resolve(baseDir, relativePath));
    if (!file.ok) {
      errors.push(`${relativePath}: ${file.error}`);
      continue; // 文件不可读时无法逐任务校验，fail-closed 跳到下一域
    }
    errors.push(...validateTasksDocument(file.data, domain, relativePath));
  }

  const routingFile = readJsonFile(path.resolve(baseDir, 'routing.json'));
  if (!routingFile.ok) {
    errors.push(`routing.json: ${routingFile.error}`);
  } else {
    errors.push(...validateRoutingDocument(routingFile.data, baseDir));
  }

  return errors;
}

module.exports = {
  // 导出供内部测试/上层工具复用同一套判据（发布门判据必须单源，禁止复制粘贴分叉）
  MIN_TASKS_PER_DOMAIN,
  MECHANICAL_ASSERTION_TYPES,
  KNOWN_DOMAINS,
  readJsonFile,
  validateTasksDocument,
  validateTaskEntry,
  validateAssertionEntry,
  validateAssertionsAgainstGroundTruth,
  evaluateAssertionAgainstExpected,
  validateGroundTruth,
  validateRoutingDocument,
  collectValidationErrors,
};

// CLI 入口：node agentdev/calibration/check.js —— 逐条打印错误并以退出码承载门禁结论
if (require.main === module) {
  const errors = collectValidationErrors(__dirname);
  if (errors.length > 0) {
    console.error(`[L1 校准门] FAIL：${errors.length} 项问题`);
    for (const error of errors) {
      console.error(`  - ${error}`);
    }
    process.exitCode = 1;
  } else {
    console.log('[L1 校准门] PASS：两域校准集与路由表全部通过结构校验');
  }
}
