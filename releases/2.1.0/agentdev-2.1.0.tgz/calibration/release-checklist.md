# 校准集 v0 内部发布门（held-out）

> 适用范围：`agentdev/calibration/` 下的两域校准集（`domains/doc-processing/tasks.json`、`domains/general/tasks.json`）与域路由表（`routing.json`）。
> 定位：校准集是**内部发布门**下的受控资产——L1 自动门必过 + 抽样 L3 人工验证可达 + 双人评审记录可核对。未过本清单，校准集不得并入发布。

## L1：结构门（全自动，必过）

执行 `node agentdev/calibration/check.js`，**exit 0 才算通过**。该脚本零依赖、fail-closed，自动校验：

- 每域任务数 ≥ 8；
- 断言类型全在 exact/contains/regex（semantic/manual 不入校准通道，U6）；
- 机械判据承载于 `value` 字段且非空（与协议层 `SpecAssertion` 一致）；regex 可编译；
- 断言集与金标准一致：每任务全部断言按协议层同语义（exact=全等不 trim、contains=子串、regex=无标志 `test`，见 `agentdev/protocol/assertions.ts`）对 `ground_truth.expected` 求值必须**全部通过**——金标准自身过不了断言集即断言与金标准矛盾（不存在能通过全部断言的输出，dp-005 v0 评审发现的致命类缺陷）；
- `ground_truth.reviewers` 恰 2 人、不同人；`reviewed_at` 为合法 ISO 日期；
- 每域文件带 `version`（semver）且 `domain` 与目录一致；任务 id 域内不重复；
- 路由表 `version` 为 semver；受控三域映射完整且各出现一次；
- `workflow-automation` 路由带 `fallback: true`（v0 无专属校准集 → general 兜底）；
- `default_domain === "general"`（未匹配域统一兜底）；被引校准集文件存在且域归属一致。

任务条目结构与协议层 `EvalTask`（`agentdev/protocol/types.ts`）兼容：`id/input/step_constraints/assertions` 齐备，判据字段同 `SpecAssertion.value`；`ground_truth` 为校准集扩展字段，回填 agent-spec 时剥除即可。

## 断言书写口径（全域统一）

- **regex 全串锚定容忍尾随空白**：同时以 `^` 开头、`$` 结尾覆盖整个输出的 regex（如 `^\d+$`、逐行枚举模式），末尾一律写成 `...\s*$`——输出末尾多一个换行/空格不判负（CLI 与文件输出普遍带末尾换行，机械断言不应因传输层空白误杀正确输出）。非全串锚定的子串/前缀型 regex（如 `^\s*\[`、`租期[：:].*`）不受此约束。
- **多行输出用逐行锚定**：多行任务的形态约束写成「单行模式 + `(\n单行模式)*`」的整串匹配（如 dp-005 邮箱逐行模式），不得用单行全串锚定去约束多行输出（断言与金标准必然矛盾，L1 一致性校验会拦截）。
- **`ground_truth.expected` 必须是纯净期望输出**：它是断言一致性比对的直接对象，评审注记（格式说明、判据容忍口径等）一律放 `ground_truth.note`，不得混入 expected。
- `exact` 断言仍为协议层最严全等口径（不 trim、不容忍尾随空白），与上述 regex 口径并行不悖；需要容忍末尾换行的输出格式校验用 regex 承载，不用 exact。

## 抽样 L3：期望可达性（人工，每域抽 2 任务）

每域各抽 2 个任务（建议：1 个 `exact` 主导任务 + 1 个 `regex/contains` 主导任务），用 demo agent 实跑验证：

- [ ] doc-processing 抽样任务 1：`dp-002-invoice-total`（exact）——跑 3 次（对齐协议层 `DEFAULT_RUN_COUNT`），期望 `12800` 可稳定复现；
- [ ] doc-processing 抽样任务 2：`dp-001-meeting-action-items`（contains/regex）——行动项成条、日期归一、顺序正确；
- [ ] general 抽样任务 1：`gen-003-json-merge`（exact）——紧凑 JSON、键序、覆盖语义全部成立；
- [ ] general 抽样任务 2：`gen-006-csv-active-filter`（contains/regex）——筛选正确且非 active 行不残留。

判定口径：逐条断言按协议层语义求值（exact=整行等值、contains=子串、regex=模式匹配，见 `agentdev/protocol/assertions.ts`）。**期望不可达时修任务措辞（input/step_constraints），不得放宽或删除断言**；任何修改都触发下述版本变更规则。

## 双人评审记录核对

- [ ] 每个任务的 `ground_truth.reviewers` 为 2 名不同评审人（check.js 已锁结构，此处核对**人名与实际评审记录一致**）；
- [ ] 评审记录（PR review / 评审文档）可追溯到 `reviewed_at` 时间线，且不晚于发布时间；
- [ ] 期望值分歧的裁决记录已留档（谁裁决、依据什么）。

## 版本变更规则

- 任务集任何变更（增/删/改任务、断言、期望值、step_constraints）**必须升该域 tasks.json 的 `version`**：
  - 新增任务：minor +1；
  - 修改期望值/断言判据/删除任务：minor +1 并在 commit message 注明受影响任务 id（重大口径翻转才用 major）；
  - 纯文案勘误（不改判据）：patch +1。
- `routing.json` 的映射/兜底关系变更必须升其 `version`；校准集内容变更不需要动路由表版本。
- 版本变更后的变更必须重跑 L1；抽样 L3 覆盖被改任务所在域。

## 兜底不降级声明

`workflow-automation` 域 v0 无专属校准集，路由到 general 兜底（`fallback: true`）。**路由兜底 ≠ 评测降级**：该域 agent 的评测仍按双通道（self-written + held-out）全量执行，仅 held-out 通道换用 general 域任务集；待专属校准集建成后改路由映射并升 routing `version`，不影响双通道结构。

## 发布签字

| 项 | 责任人 | 结论 | 日期 |
|----|--------|------|------|
| L1 门（check.js exit 0） | 执行人自动 | ☐ | |
| 抽样 L3（每域 2 任务可达） | 评审人 A | ☐ | |
| 抽样 L3（每域 2 任务可达） | 评审人 B | ☐ | |
| 双人评审记录核对 | 评审人 A/B | ☐ | |
| 版本变更规则核查 | 发布负责人 | ☐ | |
