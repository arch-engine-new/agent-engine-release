#!/usr/bin/env bash
# install.sh - agentdev one-command MACHINE (user-level) install for POSIX shells.
#
# Steps (mirrors install.ps1 on Windows):
#   1. Node check: node on PATH, major >= 22
#   2. npm ci (layout-adaptive: commercial package root if ./package.json exists,
#      else agentdev/mcp dev-mode entry deps: tsx + MCP SDK)
#   3. agentdev/install-global.mjs: agentdev-mcp registered into every supported
#      platform's USER-LEVEL MCP config (merge semantics; existing config files
#      backed up before first write; no AGENTDEV_PROJECT_ROOT is set - project
#      root is discovered at runtime by walking up to the nearest .agentdev/
#      marker) + eight agentdev-* commands distributed to each platform's
#      user-level command directory (~/.claude/commands, ~/.cursor/commands, ...)
#   4. Smoke: bare stdio boot handshake (initialize -> tools/list = 7 tools)
#
# Flags pass through to install-global.mjs:
#   --dry-run      preview only (skips npm ci and smoke - nothing to verify yet)
#   --uninstall    remove agentdev-mcp registrations + agentdev-* global commands
#                  (other entries kept; config files backed up as well)
#   --ide=<name>   limit scope: claude|cursor|zcode|codex|opencode|qoder|trae|all
#
# Rollback: bash install.sh --uninstall
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CORE="$SCRIPT_DIR/agentdev/install-global.mjs"
MCP_DIR="$SCRIPT_DIR/agentdev/mcp"

if [ ! -f "$CORE" ]; then
  echo "ERROR: install: core script not found: $CORE" >&2
  exit 1
fi

DRY_RUN=0
UNINSTALL=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    --uninstall) UNINSTALL=1 ;;
  esac
done

# [1/4] node check
if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: install: node not found on PATH - install Node.js >= 22 first: https://nodejs.org/" >&2
  exit 2
fi
NODE_VERSION="$(node --version | tr -d 'v')" # e.g. 22.11.0 (no nested quoting, mirrors install.ps1)
NODE_MAJOR="${NODE_VERSION%%.*}"
if [ "$NODE_MAJOR" -lt 22 ]; then
  echo "ERROR: install: Node >= 22 required, found v$NODE_VERSION" >&2
  exit 2
fi
echo "==> [1/4] node v$NODE_VERSION OK"

# [2/4] deps (not exercised by a dry-run preview).
# Layout-adaptive (ships unchanged inside the v2.1.0 commercial package): package
# root has package.json -> npm ci at package root (compiled mcp/src/index.js entry);
# repo layout -> npm ci in agentdev/mcp (dev tsx entry).
if [ "$DRY_RUN" -eq 1 ]; then
  echo "==> [2/4] skip npm ci (--dry-run preview needs no deps)"
elif [ -f "$SCRIPT_DIR/package.json" ]; then
  echo "==> [2/4] npm ci (commercial package root)"
  (cd "$SCRIPT_DIR" && npm ci)
else
  echo "==> [2/4] npm ci (agentdev/mcp)"
  (cd "$MCP_DIR" && npm ci)
fi

# [3/4] user-level registration + command distribution (core fail-closed: any
# broken target config -> nonzero exit and NOTHING is written)
echo "==> [3/4] user-level registration (MCP x7 + eight commands)"
node "$CORE" "$@"

# [4/4] smoke (install/upgrade only)
if [ "$DRY_RUN" -eq 1 ]; then
  echo "==> [4/4] skip smoke (--dry-run)"
elif [ "$UNINSTALL" -eq 1 ]; then
  echo "==> [4/4] skip smoke (--uninstall)"
else
  echo "==> [4/4] smoke: stdio boot handshake"
  if ! node "$CORE" --smoke; then
    echo "ERROR: install: smoke failed - registrations were written but the runtime did not verify." >&2
    echo "       Fix the error above and re-run, or roll back: install.sh --uninstall (agentdev-* only; other entries kept)." >&2
    exit 1
  fi
fi
echo "install: done"
