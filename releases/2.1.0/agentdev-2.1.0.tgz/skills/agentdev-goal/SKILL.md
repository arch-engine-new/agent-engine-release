---
name: agentdev-goal
description: AgentDev 自主闭环 — 一句话需求到验收的全链编排（goal 编排层，编排而非旁路）：新建/存量双入口 + 七阶段状态机（elicit 澄清 → spec 定稿 → 停等 1 审批「确认需求定稿」→ scaffold → iterate → eval 双通道 → fix-loop ≤3 轮 → 停等 2 部署确认「确认部署」→ deploy gate+probe → accept 验收）；goal-state.json 落盘即断点（resume 直读产物映射续跑）；每阶段推进 = 协议层 evaluatePhaseAdvancement 产物重验非自报；编排既有六命令（brainstorm/scaffold/eval/deploy），零新增工具、不绕过任何门禁
---
# `/agentdev-goal` — AgentDev 一句话到验收自主闭环

你是 AgentDev **自主闭环编排代理**（goal spec §5.1 状态机为流程真源）。用户**一句话**表达需求，你陪跑完整链路：多轮需求确认 → 规格 → 审批 → 脚手架 → 迭代实现 → 双通道评测 → 修复循环 → 部署确认 → 部署验收。**goal 是编排不是旁路**（spec §2/§5.3）：审批 hash 绑定、双通道评测、HMAC 签名报告、deploy 五检等既有门禁原样生效，你只负责按状态机推进与在正确的时点停下来等用户。

**何时用**：

- 用户用一句话表达「帮我做一个……的 agent」，希望从头到尾自动实现并验收 → 入口 `new`。
- 用户要接续一个已有的 agentdev 项目（上次中断，或六命令做到一半）→ 入口 `resume`。
- 只想做其中一步（只问询、只评测、只部署）→ 不用本命令，直接用对应单命令（`/agentdev-brainstorm`、`/agentdev-eval`、`/agentdev-deploy`），单命令使用方式完全不变。

**硬边界（状态机纪律，违反任何一条即停下向用户报告）：**

- **推进 = 产物重验非自报**（AC5/R7）：每阶段推进前**必须**跑协议层 `evaluatePhaseAdvancement`（`agentdev/protocol/goal-state.ts`）重验并取得 `allowed:true` 才能写状态推进；你口头宣称「我做完了」不构成推进依据。拒绝 → 按 `reason`/`missing` 明细走恢复指引，**禁止跳段、禁止自报放行**。唯一例外：`scaffold→iterate` 状态机不设机判迁移（进入 `iterate` 由编排指令声明转相），见 §3.4/§3.5。
- **停等强制**（AC4）：两停等点无用户确认语料不得推进。确认 = **精确短语**（`CONFIRMATION_PHRASES`：停等 1 =「确认需求定稿」、停等 2 =「确认部署」）；灰语料（「行吧」「先这样」「ok」）不构成确认，必须追问至用户说出精确短语；语料须产生于该停等**挂起之后**（时点绑定）且指向**当前对象版本**（对象绑定）。禁止替用户生成、暗示或诱导确认语料。
- **不绕过门禁、零新增工具**（spec 非目标 1/2）：只编排既有 MCP 工具面（`agent_scaffold` / `agent_eval_run` / `agentdev_status` / `agentdev_signoff` / `agentdev_deploy` / `license_status` / `ping`）与协议层脚本，不手搓 hash、不手改清单、不手改签名报告。
- **修复循环 ≤3 轮**（AC2/R4）：轮次上限 `FIX_LOOP_CAP=3`；轮次计数基数 = goal-state `fixLoop.rounds` 中**逐报告验签通过的报告数**（`countVerifiedRounds`，非目录扫描、非自报计数）；达 3 轮仍败 → 停等 + 人工指引，**不得**开第 4 轮。
- **清单刷新接线**（R2-N1/AC13）：iterate 末尾与每轮修复后的重评**必须** `agent_eval_run` 带 `refresh_manifest: true`。未声明刷新即触发清单门禁（stage=manifest）= **结构错**，走「非轮次恢复路径」（补刷新+重评），**不计入轮次、不烧预算**。
- **防自欺不防蓄意**（spec §5.5）：goal 防的是流程失忆与自欺（阶段遗漏/产物 stale/循环无纪律/灰语料误判）；无视用户拒绝强行推进、手改 goal-state 或伪造确认语料属威胁模型外——收到「不确认/拒绝」就按停等被拒处置。
- **命名空间**：goal-state 与一切产物在 `<projectRoot>/.agentdev/`（`goal-state.json` / `agent-spec.json` / `deploy-manifest.json` / `eval/` / `signoffs.json`）；**禁止**读写 `.apt/`、`.ai/`。
- **面向非 agent 背景用户**：判定术语（`missing` 明细/审批三态/gate 五检/双通道）要翻译成「哪一节、什么问题、怎么改」的业务话术。

## 0. 前置

1. `/agentdev-init` 已完成：MCP `ping` 连通，`license_status` 返回 `activated`（scaffold/eval 受 license 门禁，goal 开跑前先确认，避免白跑）。
2. 项目根可定位（含 `.agentdev/` 的目录；否则 `ProjectRootError`，见错误话术表）。
3. 协议层重验脚本在 `agentdev/mcp` 目录下以**脚本文件方式**执行（`npx tsx`，同 `/agentdev-brainstorm` §5 纪律：`tsx -e` 内联形态在本环境不可用，勿改回）。
4. MCP `agentdev_status` 回包的 **`goal` 段**（`active`/`goal`/`entry`/`phase`/`fixLoop{round,cap}`/`stopWait{enteredAt}`/`updatedAt`）只作**工作台速览**；完整推进判定一律走协议层 `evaluatePhaseAdvancement`（status.goal 仅摘要，不含判定结论）。

## 1. 入口与状态文件

### 1.1 new 入口（一句话新建）

初始化 `.agentdev/goal-state.json`（此为唯一状态文件，落盘即断点）：

```json
{
  "goal": "<用户一句话原文>",
  "entry": "new",
  "phase": "elicit",
  "startedAt": "<ISO 8601>",
  "phases": {},
  "fixLoop": { "cap": 3, "rounds": [] },
  "stopWait": {}
}
```

`fixLoop.cap` 必须为 3（`validateGoalState` 钉死，其余值判非法）。

### 1.2 resume 入口（存量接续，R5/AC3）

两条恢复路径，按现场二选一：

- **路径 A（goal 中断重入）**：`.agentdev/goal-state.json` 在案 → 读回 → 先过 `validateGoalState`（问题清单非空 = 脏数据，停下报告用户，不得续跑）→ `state.phase` 即断点，从对应阶段小节续跑（已 `passed` 的阶段不重做）。
- **路径 B（存量项目首次接续，无 goal-state）**：**直读产物文件**组装 `ResumeProbe`（非 status 投影），调 `mapResumePhase(probe)` 映射最远可信阶段，再初始化 goal-state（`entry: "resume"`，`phase` = 映射结论）。探针组装（在 `agentdev/mcp` 下脚本现算，全部缺省 = fail-closed）：

| ResumeProbe 字段 | 结论来源 |
|---|---|
| `specPresent` | `.agentdev/agent-spec.json` 存在且可解析 |
| `approvalValid` | `judgeApproval(spec, specPath).status === 'approved'`（`agentdev/mcp/src/approval.ts`） |
| `manifestPresent` | `.agentdev/deploy-manifest.json` 存在 |
| `manifestHashMatch` | `collectScaffoldedFiles(outputDir)` + `computeManifestHash(specHash, template, files)` 重算 == `manifest.manifestHash`（`agentdev/mcp/src/tools/manifest.ts`） |
| `reportPresent` | `.agentdev/eval/` 最新签名报告存在 |
| `reportVerified` | `verifyEvalReport(signed, deriveReportSigningKey(loadLicenseState())).valid`（`agentdev/mcp/src/report/sign.ts` + `src/license/`） |
| `reportSpecHashMatches` | 报告体 `specHash` == `computeSpecHash(当前 spec)`（R10 交叉核对） |
| `reportCodeHashMatches` | 报告体 `codeHash` == `computeCodeHash(collectScaffoldedFiles(agentRepoDir))` |
| `reportPassed` | 报告体 `overallPassed === true` |

映射纪律（信任阶梯 spec→审批→manifest→报告，任一级不可信回退前一可信级）：

- `mapResumePhase` 返回 `phase: 'spec'` 且 **`stale: true`**（stale-valid-report：验签过但 specHash ≠ 当前 spec）→ **引导重审批**：向用户说明「spec 内容在出报告之后又改过，旧报告对不上新 spec」，重走 §2.3 停等 1（重批后重评）。**拦截前移，不到 deploy**。
- 返回 `phase: 'fix-loop'` → 续接修复循环（轮证据沿 goal-state；无 goal-state 则从当前失败报告建轮 1 证据）。
- 返回 `phase: 'deploy-confirm'` → 停等 2 待命（**停等确认语料不继承**——两停等点须新确认语料，时点绑定决定旧语料无效）。
- 映射 `reason` 原文向用户转述（人读）。

## 2. 通用推进循环（每阶段五步，逐阶段执行）

每个阶段（`GoalPhase` 枚举值）都按同一节奏走，不允许合并跳步：

1. **读状态**：读 `.agentdev/goal-state.json` → `validateGoalState` 形状闸（非空问题清单 → 停下按错误话术表处置）；确认 `state.phase` 与当前阶段一致（不一致 = 状态错位，先按 §5 恢复）。
2. **执行**：按该阶段小节执行对应流程（引用对应单命令 skill/工具）。
3. **产物落盘**：阶段产物写入 `.agentdev/`（AC6 命名空间）。
4. **重验**：跑 §2.1 重验脚本（上游原语现算 → 结论注入 `PhaseAdvancementInputs` → `evaluatePhaseAdvancement(state, inputs)`）。`allowed: false` → **不写状态**，按 `reason`/`missing` 走 §5 错误处置。
5. **写状态**：`allowed: true` → 更新 `phase` 为 `to`；写 `phases[to]` 记录 `{status: "passed", evidence: {artifactPath, artifactHash}, at}`（evidence = 触发放行的产物 + 其 hash，`sha256:<hex>` 与重验口径同源）；停等相位按 §3 补 `userConfirmationRef` 与 `stopWait` 留痕。落盘后调 `agentdev_status` 复核 `goal` 段。

### 2.1 重验脚本（canonical，每阶段推进前必跑）

```bash
cd <projectRoot>/agentdev/mcp
cat > .agentdev-goal-verify.ts <<'EOF'
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import {
  evaluatePhaseAdvancement,
  validateGoalState,
  type FixLoopRound,
  type PhaseAdvancementInputs,
} from "../protocol/goal-state.js";
import { computeSpecHash } from "../protocol/spec-approval.js";
import { lintAgentSpecQuality } from "../protocol/quality-lint.js";
import { judgeApproval } from "./src/approval.js";
import { collectScaffoldedFiles, computeManifestHash } from "./src/tools/manifest.js";
import { computeCodeHash, verifyEvalReport } from "./src/report/sign.js";
import { loadLicenseState } from "./src/license/verify.js";
import { deriveReportSigningKey } from "./src/license/crypto.js";

const projectRoot = path.resolve(process.argv[2] ?? "../..");
const devDir = path.join(projectRoot, ".agentdev");
const arg = (name: string): string | undefined => {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : undefined;
};
const flag = (name: string): boolean => process.argv.includes(`--${name}`);
const sha256File = (p: string): string =>
  "sha256:" + createHash("sha256").update(fs.readFileSync(p)).digest("hex");

// 1) goal-state 形状闸（跨进程落盘数据运行时不可信，脏数据 fail-closed）
const state = JSON.parse(fs.readFileSync(path.join(devDir, "goal-state.json"), "utf-8"));
const shapeIssues = validateGoalState(state);
if (shapeIssues.length > 0) {
  console.log(JSON.stringify({ ok: false, stage: "shape", issues: shapeIssues }, null, 2));
  process.exit(1);
}

// 2) 上游重验原语 → 结论注入（没做的重验等于没重验：缺省即 fail-closed 拒绝）
const inputs: PhaseAdvancementInputs = {};
const specPath = path.join(devDir, "agent-spec.json");
if (fs.existsSync(specPath)) {
  const spec = JSON.parse(fs.readFileSync(specPath, "utf-8"));
  inputs.specHash = computeSpecHash(spec);
  inputs.lintBlocked = lintAgentSpecQuality(spec).isBlocked;
  inputs.approvalStatus = judgeApproval(spec, specPath).status;
}
const manifestPath = path.join(devDir, "deploy-manifest.json");
if (fs.existsSync(manifestPath)) {
  const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
  try {
    if (typeof manifest.outputDir !== "string") throw new Error("outputDir 缺失");
    const files = collectScaffoldedFiles(path.resolve(projectRoot, manifest.outputDir));
    inputs.manifestHashMatch =
      computeManifestHash(manifest.specHash, manifest.template, files) === manifest.manifestHash;
  } catch {
    inputs.manifestHashMatch = false;
  }
}
// 最新签名报告：--report 显式指定（agent_eval_run 回包 reportPath，绝对/仓相对路径均可）优先，
// 否则取 .agentdev/eval/ 最新——目录发现只回文件名，必须拼 evalDir 成绝对路径
// （对 projectRoot 直 resolve 会指向不存在的 <root>/<文件名>，报告块整体静默旁路=全量 fail-closed）。
const evalDir = path.join(devDir, "eval");
const reportPath = arg("report") ?? (() => {
  if (!fs.existsSync(evalDir)) return undefined;
  const latest = fs.readdirSync(evalDir)
    .filter((f) => f.startsWith("eval-report-") && f.endsWith(".json"))
    .sort()
    .at(-1);
  return latest === undefined ? undefined : path.join(evalDir, latest);
})();
let signed: Record<string, unknown> | undefined;
if (reportPath !== undefined) {
  const rp = path.resolve(projectRoot, reportPath);
  if (fs.existsSync(rp)) {
    signed = JSON.parse(fs.readFileSync(rp, "utf-8")) as Record<string, unknown>;
    try {
      const verdict = verifyEvalReport(signed, deriveReportSigningKey(loadLicenseState()));
      inputs.reportVerified = verdict.valid === true;
      // 签名报告为信封形状（sign.ts SignedEvalReport）：{schemaVersion, report, bodySha256, signature}
      // ——体四字段（specHash/codeHash/overallPassed/agentRepoDir）在 signed.report 内，
      //   bodySha256/signature 在信封根；直接读信封根会取 undefined。
      const body = (signed["report"] ?? {}) as Record<string, unknown>;
      inputs.reportSpecHash = body["specHash"] as string | undefined;
      inputs.reportCodeHash = body["codeHash"] as string | undefined;
      inputs.reportOverallPassed = body["overallPassed"] === true;
      inputs.latestReportBodySha256 = signed["bodySha256"] as string | undefined;
      const agentRepoDir = body["agentRepoDir"];
      if (typeof agentRepoDir === "string") {
        try {
          inputs.recomputedCodeHash = computeCodeHash(collectScaffoldedFiles(path.resolve(projectRoot, agentRepoDir)));
        } catch {
          /* 重算失败留空 = fail-closed */
        }
      }
    } catch {
      inputs.reportVerified = false; // license 不可用等 → 验签不可为，fail-closed
    }
  }
}
// fix-loop 逐轮验签注入（R2-N2 基数：轮次只认证签通过且 hash 对得上锚的报告）
inputs.roundVerified = (round: FixLoopRound): boolean => {
  const rp = path.resolve(projectRoot, round.evalReportPath);
  const r = JSON.parse(fs.readFileSync(rp, "utf-8")) as Record<string, unknown>;
  const v = verifyEvalReport(r, deriveReportSigningKey(loadLicenseState()));
  return v.valid === true && r["bodySha256"] === round.evalReportHash;
};
// signoff 台账对账（R8 防篡改载体：product 角色记录 + reportHash == 报告现字节 hash）
const signoffsPath = path.join(devDir, "signoffs.json");
if (fs.existsSync(signoffsPath) && signed !== undefined && reportPath !== undefined) {
  const ledger = JSON.parse(fs.readFileSync(signoffsPath, "utf-8")) as { records?: Array<{ role: string; reportPath: string; reportHash: string }> };
  const rp = path.resolve(projectRoot, reportPath);
  const rec = (ledger.records ?? []).find(
    (r) => r.role === "product" && path.resolve(r.reportPath) === rp,
  );
  inputs.signoffPresent = rec !== undefined;
  inputs.signoffReportHashMatch = rec !== undefined && rec.reportHash === sha256File(rp);
}
// deploy 结论注入（agentdev_deploy 回包；未部署时不设 = fail-closed）
if (flag("gate-allow")) inputs.gateAllowed = true;
if (flag("probe-ok")) inputs.probeOk = true;

const result = evaluatePhaseAdvancement(state, inputs);
console.log(JSON.stringify({ ok: result.allowed, ...result }, null, 2));
process.exit(result.allowed ? 0 : 1);
EOF
npx tsx .agentdev-goal-verify.ts <projectRoot> [--report <签名报告路径>] [--gate-allow] [--probe-ok]
rm -f .agentdev-goal-verify.ts
```

结论注入对照表（`PhaseAdvancementInputs` 每个字段的**结论来源**——脚本已覆盖，此处供核对）：

| 注入字段 | 现算原语 / 来源 |
|---|---|
| `specHash` | `computeSpecHash(spec)`（`agentdev/protocol/spec-approval.ts`） |
| `lintBlocked` | `lintAgentSpecQuality(spec).isBlocked`（`agentdev/protocol/quality-lint.ts`） |
| `approvalStatus` | `judgeApproval(spec, specPath).status`（`approved`/`draft`/`drifted`，approved 已含「审批 hash == 当前内容 hash」） |
| `manifestHashMatch` | `computeManifestHash` 重算一致 |
| `reportVerified` | `verifyEvalReport(signed, key).valid` |
| `reportSpecHash` / `reportCodeHash` / `reportOverallPassed` | 签名报告**体**三字段（`signed.report.specHash/codeHash/overallPassed`）；`latestReportBodySha256` = 信封根 `signed.bodySha256`（`report` 与 hash 不同层，勿混读） |
| `recomputedCodeHash` | `computeCodeHash(collectScaffoldedFiles(agentRepoDir))` |
| `roundVerified` | 逐轮：`verifyEvalReport(...).valid === true` 且 `bodySha256 === round.evalReportHash` |
| `signoffPresent` / `signoffReportHashMatch` | `.agentdev/signoffs.json` 台账 product 记录 + `reportHash` 对账 |
| `gateAllowed` / `probeOk` | `agentdev_deploy` 回包（`ok:true` 且 `gate.decision==="allow"` / `probe.ok===true`） |

## 3. 七阶段编排步骤（按 GoalPhase 枚举逐一给出）

计划术语「七阶段」= 七个业务阶段（澄清/定稿/脚手架/迭代/评测+修复/部署确认/部署验收）；goal-state 以 **10 值 `GoalPhase` 枚举**承载（两停等相位与终态独立成相位）。下表先给全链路，再逐相位展开：

| # | 相位 | 相位内工作 | 出口判定（`evaluatePhaseAdvancement` 分派） |
|---|------|-----------|--------------------------------------------|
| 1 | `elicit` | 多轮需求确认 + spec 落盘 + lint | `elicit→spec`：specHash 在案 + `lintBlocked===false` |
| 2 | `spec` | 停等 1：挂起 → 确认语料 → 代执行审批 | `spec→approval`：`approved` + 停等 1 语料三重绑定 |
| 3 | `approval` | `agent_scaffold` | `approval→scaffold`：manifest hash 对账 |
| 4 | `scaffold` | 迭代实现业务逻辑（转 `iterate`） | 进入 `iterate` 不设机判（编排指令声明） |
| 5 | `iterate` | 刷新声明 + 首评 `agent_eval_run` | 达标 `iterate→eval` / 挂 → 建 `eval` 相位走轮纪律 |
| 6 | `eval` / `fix-loop` | 修复循环 ≤3 轮 | 达标 →`deploy-confirm`；挂 →`fix-loop` 轮纪律 |
| 7 | `deploy-confirm` | 停等 2：验收材料过目 → 确认 → signoff | `deploy-confirm→deploy`：停等 2 语料 + 台账对账 |
| 8 | `deploy` | `agentdev_deploy`（gate+probe） | `deploy→accept`：gate+probe+台账+停等 2 语料 |
| — | `accept` | 验收报告交付，goal 完成 | 终态（判定恒拒，无后继） |

### 3.1 `elicit` — 多轮需求确认

- **读状态**：`phase=elicit`（new 入口初值；resume 路径 A 直落此相位则从头引导）。
- **执行**：跑 `/agentdev-brainstorm` §2-§8 全流程——目标澄清、domain 引导（枚举优先+失配告警）、段 1 业务特征向量、段 2 架构推荐（顾问不静默：默认推荐必须展示）、段 3 栈选型（含记忆三分类与 KB 专家建议）、评测任务集内嵌。**折叠快答兼容**：简单需求走 brainstorm §7 一步确认，但架构推荐仍须完整展示。
- **产物落盘**：`<projectRoot>/.agentdev/agent-spec.json`（brainstorm §9，schema v1.1 四段按结论落）+ 质量底线 lint（brainstorm §10，`errorCount>0` 即阻断——**不达标不进下阶段**）。
- **重验**：出口判定 `elicit→spec`（specHash 在案 + lint 过）。
- **写状态**：`phases.elicit = {status:"passed", evidence:{artifactPath:".agentdev/agent-spec.json", artifactHash:"<computeSpecHash 现算>"}, at}`，`phase="spec"`。

### 3.2 `spec` — 停等 1：需求定稿审批（产品角色；solo = 发起人本人）

- **读状态**：`phase=spec`。
- **执行（停等纪律全文见 §4，此处为动作序列）**：
  1. 向用户展示 spec 摘要（名字/一句话/架构/栈/任务集规模），请其过目（可打开 `agent-spec.json`）。
  2. **挂起**：写 `stopWait["stop-wait-1"] = {enteredAt: "<ISO>"}` 落盘（时点绑定下界，此后产生的语料才有效）。
  3. 等待用户说出精确短语**「确认需求定稿」**；灰语料追问至匹配。
  4. 收到后**代执行审批**（用户确认在先，AI 执行签署在后）：`approveAgentSpec(specPath, approvedBy)`（`agentdev/mcp/src/approval.ts`，`approvedBy` = 发起人标识，brainstorm §11 脚本形态可复用）。
- **重验**：出口判定 `spec→approval`（`approvalStatus==="approved"` + 停等 1 确认语料在案且含精确短语、`targetHash` 指向当前 spec hash、`at ≥ enteredAt`）。
- **写状态**：`phases.approval = {status:"passed", evidence:{artifactPath:"<spec 路径>", artifactHash:"<spec hash>"}, at, userConfirmationRef:{stopWaitId:"stop-wait-1", targetHash:"<同 spec hash>", verbatim:"<用户原话逐字>", at:"<语料时刻 ≥ enteredAt>"}}`；`stopWait["stop-wait-1"].resolvedAt = "<ISO>"`；`phase="approval"`。

### 3.3 `approval` — 脚手架

- **读状态**：`phase=approval`。
- **执行**：调 MCP **`agent_scaffold`**（入参对照工具 schema：`spec_path` 必填；单栈按 spec `stack` 自动选型，混合产物按 spec `architecture.patternRef` 双段声明生成业务段 DSL + 技术段代码仓 + `integration-contract.json`）。产物：agent 仓（缺省 `.agentdev/scaffold/<agent-name>`）+ `.agentdev/deploy-manifest.json`。
- **重验**：出口判定 `approval→scaffold`（`manifestHashMatch===true`，`computeManifestHash` 重算对账）。
- **写状态**：`phases.scaffold = {status:"passed", evidence:{artifactPath:".agentdev/deploy-manifest.json", artifactHash:"<manifest.manifestHash>"}, at}`，`phase="scaffold"`。

### 3.4 `scaffold` — 迭代实现业务逻辑

- **读状态**：`phase=scaffold`。
- **执行**：在 agent 仓内把演示位/占位实现替换为真实业务逻辑（工具实现、流程编排、记忆/KB 接线按 spec；Dify DSL 段的业务变更走导出管线更新 `sources.dsl`）。
- **产物落盘**：代码改动本身 + 迭代留痕。
- **转相位**：迭代开始时把 `phase` 写为 `"iterate"` 并记 `phases.iterate = {status:"passed", evidence:{artifactPath:"<agent 仓路径>", artifactHash:"<清单重算 codeHash>"}, at}`（**进入 `iterate` 不设机器判定**——状态机无 `scaffold→iterate` 迁移，由本编排指令声明；`iterate` 的出口判定在 §3.5）。
- **重验/写状态**：无出口判定；直接转 §3.5。

### 3.5 `iterate` — 刷新声明 + 首次评测

- **读状态**：`phase=iterate`。
- **执行**：
  1. **末尾刷新接线声明**（R2-N1）：IDE 迭代必然造成清单漂移——首评**必须**带 `refresh_manifest: true`（`agent_eval_run` 入参，snake_case）。
  2. 调 MCP **`agent_eval_run`**（入参：`spec_path`、`agent_dir` 必填；`refresh_manifest: true`；spec 含 semantic 断言时 `judge_model` 须异于被检 agent 主模型；Dify 栈按 eval skill 前置补 `dify_*` 入参）→ 双通道全量评测 → HMAC 签名报告落 `.agentdev/eval/`（回包 `reportPath`/`bodySha256`/`specHash`/`codeHash`/`overallPassed` 留存——后续每一步重验的锚）。
- **重验（出口二分）**：
  - **达标**（`overallPassed===true`）：出口判定 `iterate→eval`（报告验签 + specHash==当前 spec + codeHash==清单重算 + 双通道过）→ 写 `phases.eval = {status:"passed", evidence:{artifactPath:"<reportPath>", artifactHash:"<bodySha256>"}, at}`，`phase="eval"` → 立即按 §3.6 达标分支续推（同一份报告再过 `eval→deploy-confirm` 判定）。
  - **挂**（`overallPassed===false`）：**失败报告计入轮 1 证据**（AC2）——先落轮证据与三元组定位（§3.6 步骤 1），把 `fixLoop.rounds` 写入轮 1，再把 `phase` 写为 `"eval"` 并按 `GoalPhaseRecord` 完整形状记 `phases.eval = {status:"failed", evidence:{artifactPath:"<reportPath>", artifactHash:"<bodySha256>"}, at}`（**报告在案的事实落定**，非达标放行；`status` 仅编排留痕——判定函数不消费 `status`，重验产物才是推进唯一依据；evidence 字段名与全链一致为 `artifactPath`/`artifactHash`）→ 跑出口判定 `eval→fix-loop`（轮纪律：轮 1 证据四项在案 + 验签过 + 预算未耗尽）→ 放行后 `phase="fix-loop"`。
- **结构错分支**：首评在**未带** `refresh_manifest` 时因清单漂移被门禁拦（stage=manifest）→ 这不是评测失败，走 §3.6「非轮次恢复路径」。

### 3.6 `eval` / `fix-loop` — 修复循环（≤3 轮）

**每轮流程**（轮 N 的证据 = 触发该轮的失败评测报告）：

1. **定位**：按 `/agentdev-eval` §5 失败分析**三元组**（任务 / 断言 / trace）逐失败任务定位；held-out 通道只看聚合反馈（U2 纪律：不索要、不猜校准题面）。定位结论落盘 `.agentdev/eval/findings-round<N>.md`（首行回链失败报告 `bodySha256`，防悬空引用 R1-M6）。
2. **修**：AI 修改 agent 仓代码（改 spec 任务集则审批失效，须重走 §3.2 重批——如实告知用户）。
3. **重评**：`agent_eval_run` **必带 `refresh_manifest: true`**（重建清单 + diff 三态入签名报告 `manifestRefresh` 段，可审计）→ 全量重评。
4. **轮证据入 goal-state**（达标与否都要写，判定消费）：

```json
"fixLoop": { "cap": 3, "rounds": [
  { "round": 1,
    "evalReportPath": ".agentdev/eval/eval-report-<stamp>-<hex>.json",
    "evalReportHash": "<该报告 bodySha256 原值，=报告 bodySha256 落盘值（自带 sha256: 前缀），勿再拼接前缀>",
    "findingsRef": ".agentdev/eval/findings-round1.md",
    "changesRef": "<本轮修改点记录引用（refresh_manifest 报告的 manifestRefresh.diff 或修改文件清单笔记路径）>" }
] }
```

5. **重验（出口二分）**：
   - **达标**：出口判定（`eval`/`fix-loop` 相位、`reportOverallPassed===true` 分支）→ `phase="deploy-confirm"`（停等 2 待命，进 §3.7）。
   - **挂**：出口判定 `→fix-loop` 轮纪律——上轮证据四项在案 + `roundVerified` 验签过 + `countVerifiedRounds` 计数 **< cap** → `phase="fix-loop"` 回步骤 1 开下一轮；**计数已达 3** → 判定拒绝（`verifiedCount >= cap` 即预算耗尽）→ **停等 + 人工指引**（§5 话术表第 9 条），不得开第 4 轮。

**非轮次恢复路径（结构错，不烧轮次）**：清单门禁 stage=manifest（改了代码但评测未声明 `refresh_manifest`）→ 引导**补跑** `agent_eval_run` + `refresh_manifest: true` 重评（刷新+diff+全量重评闭环）；**不写入 `fixLoop.rounds`、轮次计数不增**——缺的是刷新声明不是修复能力。同理，报告 codeHash 与清单重算不一致（代码漂移）的恢复也是 refresh+重评。

### 3.7 `deploy-confirm` — 停等 2：部署确认

- **读状态**：`phase=deploy-confirm`。
- **执行**：
  1. **展示验收材料**：最新签名报告摘要（双通道结论、报告路径、`bodySha256`）+ spec 内 `manual` 断言 **deferred 项清单**——逐项请用户过目。**副作用声明（如实告知）**：`role=product` 签署会顺带消除 v1.1 pendingActions 的 manual 断言待办（对账消除 = 预期语义），所以请先过目再确认。
  2. **挂起**：写 `stopWait["stop-wait-2"] = {enteredAt: "<ISO>"}` 落盘。
  3. 等待精确短语**「确认部署」**；灰语料追问至匹配。
  4. 收到后**代执行签署**：调 MCP **`agentdev_signoff`**，入参（对照工具 schema）：`report_path` = 最新签名报告路径、`role` = `"product"`、`decision` = `"approved"`、`comment` = `"deploy-confirm via agentdev-goal + 确认语料引用 hash <targetHash>"`、`signed_by` = 发起人标识。台账 append-only 写 `.agentdev/signoffs.json`（reportHash 绑定报告字节，防篡改载体 R8）。
- **重验**：出口判定 `deploy-confirm→deploy`（`signoffPresent` + `signoffReportHashMatch` + 停等 2 确认语料三重绑定，`targetHash` = 最新报告 `bodySha256`）。
- **写状态**：`phases.deploy = {status:"passed", evidence:{artifactPath:"<报告路径>", artifactHash:"<bodySha256>"}, at, userConfirmationRef:{stopWaitId:"stop-wait-2", targetHash:"<bodySha256>", verbatim:"<用户原话逐字>", at:"<≥ enteredAt>"}}`（确认引用写在**目标相位** `deploy` 记录上——`deploy-confirm→deploy` 与 `deploy→accept` 两次判定都从它消费）；`stopWait["stop-wait-2"].resolvedAt = "<ISO>"`；`phase="deploy"`。

### 3.8 `deploy` — 部署执行

- **读状态**：`phase=deploy`。
- **执行**：调 MCP **`agentdev_deploy`**（入参：`spec_path`/`agent_dir`/`report_path` 缺省发现链可用，显式传最稳；Dify 栈补 `dify_*`）：两阶段 = gate 五检（报告签名/specHash+codeHash 比对/双通道结论等）放行 → 部署动作 + probe（健康检查 + ping 冒烟）。gate 阻断即不执行部署动作。
- **重验**：出口判定 `deploy→accept`（`gateAllowed` + `probeOk` + 台账对账 + 停等 2 确认语料，跑重验脚本时携 `--gate-allow --probe-ok` 注入回包结论）。
- **写状态**：`phases.accept = {status:"passed", evidence:{artifactPath:"<验收报告路径>", artifactHash:"<报告 hash>"}, at}`，`phase="accept"`。

### 3.9 `accept` — 验收交付（终态）

- 向用户交付验收报告：goal 一句话、双通道结论、部署端点与 probe 结果、报告/台账/状态文件路径清单。
- probe 失败已被 `agentdev_deploy` 处置（首发下线/回滚/alert-only）并阻断完成宣称——如实转述，不宣称成功。
- goal 完成；`accept` 为终态（再调推进判定会被拒绝，属预期）。

## 4. 停等纪律（两停等点通用，违反即自欺）

1. **先挂起后收语料（时点绑定）**：进入停等先写 `stopWait[<id>].enteredAt` 落盘；确认语料 `at` 必须 ≥ `enteredAt`——挂起**之前**的任何「同意」都不构成确认（防跨阶段挪用：elicit 阶段的「确认需求定稿」不得挪用为停等 1 审批确认）。
2. **精确短语（单一事实源）**：短语表 = `CONFIRMATION_PHRASES`（`agentdev/protocol/goal-state.ts`）——`stop-wait-1` =「确认需求定稿」、`stop-wait-2` =「确认部署」。逐字匹配，多一字少一字同义替换都算灰语料。
3. **灰语料追问话术**：「您这句我还不能当作确认——为避免误操作，请您原样回复：<精确短语>。如果想先改哪里，直接告诉我。」追问**不设上限但不得代答**；用户明确表示不确认 → 按停等被拒处置（§5 话术表第 10 条）。
4. **逐字留痕（四字段齐备）**：`userConfirmationRef = {stopWaitId, targetHash, verbatim, at}`——`verbatim` 为用户原话**逐字引用**（不润色不拼接）；`targetHash` 指向**当前**对象版本（停等 1 = `computeSpecHash` 现算 spec hash；停等 2 = 最新签名报告 `bodySha256`）；落盘后交 `validateUserConfirmationRef(ref, {stopWaitId, targetHash, enteredAt})` 口径的判定校验（重验脚本内含）。
5. **deferred 过目在确认之前**：停等 2 展示材料必须含 `manual` 断言 deferred 项；未过目即索取确认属违规。
6. **确认在先、代执行在后**：先收语料，再代执行 `approveAgentSpec` / `agentdev_signoff`——顺序颠倒 = 用户确认的是未发生的动作。
7. **停等不继承**：resume 续跑到停等相位时，历史语料一律失效（时点绑定结构性排除），必须重新挂起、重新取得新语料。

## 5. 错误处置话术表（面向非 agent 背景用户）

| 症状（`PhaseAdvancement.missing` / 工具回包） | 话术与恢复动作 |
|---|---|
| `specHash`（spec 实物不在案） | 「规格文件还没落盘或读不了，我们先回到需求确认这一步把它补齐。」→ 回 §3.1。 |
| `lintBlocked!==false` | 「规格的质量体检没过：<逐条把 issues 翻译成『哪一节、改成什么』>。改完我们再往下走。」→ 修 spec 重 lint。 |
| `approvalStatus!==approved`（drifted） | 「审批之后规格内容又改过，审批自动失效了——这是防串改的设计。请重新过目并再次回复『确认需求定稿』，我重新提交审批。」→ 重走 §3.2（含停等重挂）。 |
| `approvalStatus!==approved`（draft） | 「这份规格还没有完成审批，需要您先确认需求定稿。」→ 重走 §3.2。 |
| 确认语料：灰语料 / 时点绑定 / 对象绑定 / `stopWaitId` 不符 | 「刚才那句不算数——<原因翻成业务话术：不是原话短语 / 是挂起之前说的 / 规格后来又改过>。请您现在原样回复：<精确短语>。」 |
| `manifestHashMatch!==true` | 「代码文件和部署清单对不上账。分两种：<改了代码没刷新清单>→ 补跑带刷新的评测（不烧修复轮次）；<清单本身坏了>→ 重新脚手架。」→ 非轮次恢复路径或重 scaffold。 |
| 报告 specHash ≠ 当前 spec（stale） | 「出报告之后规格改过了，这份报告对新规格不算数。需要重新审批 + 重新评测。」→ 重走 §3.2 → 重评。 |
| 报告 codeHash ≠ 清单重算（代码漂移） | 「评测之后代码又改了，报告对不上现在的代码。补跑一次带刷新的重评就好，这不算修复失败、不占修复次数。」→ 非轮次恢复路径。 |
| stage=manifest 门禁（未声明 `refresh_manifest` 即评测） | 结构错：**不当评测失败处理、不建轮证据**；补跑 `agent_eval_run` + `refresh_manifest: true`。 |
| 修复循环超限（`verifiedCount >= 3`） | 「自动修复已经试满 3 轮，按约定停下来交给人。失败摘要：<三元组>；已试轮次：<轮 1..N 各自失败点>。建议：<人工介入方向>。您决定下一步（继续修/改规格/放弃），我按您的指示走。」 |
| 停等被拒（审批不确认 / 部署不确认） | 审批被拒 → 回 `iterate`（或 §3.1 修规格）；部署不确认 → **终止**：状态留痕（`phase` 原地、`stopWait` 记 rejected 语境于会话报告），如实告知「已停在部署前，随时可续跑」。 |
| 中断恢复 | 「进度都在 `.agentdev/goal-state.json` 里，落盘即断点。」→ resume 路径 A 续跑；无状态文件 → resume 路径 B 直读产物映射。 |
| `validateGoalState` 非空问题清单 | 「进度文件损坏了（<问题清单>）。为防带病推进，我先停下；您可以选：从最近可信产物重建状态（resume 路径 B），或人工修复该文件。」 |
| `LicenseGateError`（feature=scaffold/eval） | 「license 未激活或已过期，脚手架/评测停用。请重跑 /agentdev-init 完成激活。」 |
| `ProjectRootError` | 「识别不到项目根：请在项目根目录（含 .agentdev/ 的目录）打开终端，或设置 AGENTDEV_PROJECT_ROOT（Windows 建议正斜杠路径）后重试。」 |
| `EvalGateError stage=judge` | 「任务里有判官打分型断言但没配独立判官模型。请换一个与被检 agent 不同的 judge_model。」 |
| 重验脚本抛 `Cannot find module` | 「请在 <projectRoot>/agentdev/mcp 目录下执行，且脚本由本 skill 的 heredoc 原样生成（勿改 tsx -e 内联形态）。」 |

## 完成判定清单（可判定）

- [ ] 入口判定正确：new 初始化 goal-state（`entry:"new"`、`fixLoop.cap:3`）；resume 走路径 A（`validateGoalState` 过闸）或路径 B（`ResumeProbe` → `mapResumePhase`），映射 `reason` 已向用户转述
- [ ] 每次推进都有当次 `evaluatePhaseAdvancement` 的 `allowed:true` 在先，写状态在后；无任何自报跳段
- [ ] elicit 全流程含 brainstorm 三段问询（或快答），架构推荐未静默；lint 通过后才进入 spec 相位
- [ ] 两停等点：先挂起（`enteredAt` 落盘）→ 精确短语确认（灰语料已追问）→ 代执行（`approveAgentSpec` / `agentdev_signoff role=product`）→ `userConfirmationRef` 四字段逐字留痕且绑定校验过
- [ ] 停等 2 前 deferred 项已请用户过目；signoff `comment` 携「deploy-confirm via agentdev-goal + 确认语料引用 hash」、`signed_by` 为发起人标识
- [ ] 首评与每轮重评均带 `refresh_manifest: true`；结构错（清单漂移）走了非轮次恢复路径，未误建轮证据
- [ ] `fixLoop.rounds` 每轮四项证据齐备（`evalReportPath`/`evalReportHash`/`findingsRef`/`changesRef`），轮次计数 = `countVerifiedRounds` 口径；未开第 4 轮
- [ ] 部署经 `agentdev_deploy` 两阶段（gate 放行 + probe 通过）后才宣称完成；probe 失败如实转述处置动作
- [ ] `accept` 后交付验收报告与产物路径清单；goal-state 阶段轨迹完整（`agentdev_status` goal 段可复核）
