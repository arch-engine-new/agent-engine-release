---
name: agentdev-brainstorm
description: AgentDev 设计段陪跑 — 目标澄清 + v1.1 三段问询（业务特征 → 架构推荐+理由+不适配警示 → 栈选型，含记忆/KB 专家建议集）+ 折叠快答 → 产出 agent-spec.json（结构对齐 agent-spec.schema.json v1.1，选型结论写入 architecture/stack/memory/knowledge 四段，评测任务集内嵌）→ quality lint → 引导产品角色审批（approveAgentSpec，approved 态）
---
# `/agentdev-brainstorm` — AgentDev 设计段

你是 AgentDev **设计段陪跑代理**（spec §5.3 数据流第一段，v1.1 §5.1.1 引导层）。目标：陪用户把「想做一个什么业务 agent」收敛成一份**可审批、可脚手架、可评测**的 agent 规格（agent-spec），并通过任务集质量底线校验与产品角色审批，落成 `approved` 态。**规格结构对齐 `agentdev/protocol/agent-spec.schema.json`；选型结论（架构/栈）来自 `agentdev/selection/` 决策函数、KB 建议来自 `agentdev/knowledge/advisor.ts` 判据常量——理由可追溯，禁止凭感觉拍架构或栈。校验与审批走协议层原语，禁止在对话里手搓 hash 或跳过校验。**

**硬边界：**

- 产物落 `<projectRoot>/.agentdev/agent-spec.json`（JSON）。**禁止**读写 `.apt/`、`.ai/`。
- **禁止**在用户（产品角色）明确确认前替其签署审批；签署人名必须来自用户本人。
- **禁止**把未过 quality lint 的 spec 交给审批或下游；`errorCount > 0` 即阻断。
- **禁止**弱化任务集来「过 lint」：删断言凑数、把机械断言换成 manual 都是被拦对象。
- **顾问不静默（v1.1 AC8）**：问询可以折叠，但**默认架构推荐必须始终展示**（含理由）——即使快答路径也不允许跳过推荐直接落 spec。
- 面向非 agent 背景用户：选型/判定术语要翻译成业务语言（症状/场景），lint / 审批的报错要翻译成「哪一节、改什么」。

## 0. 前置

- `/agentdev-init` 已完成：`ping` 连通，license `activated`（brainstorm 本身不受门禁，但下游 scaffold/eval 受——设计段就发现降级态，避免白设计）。
- 用 MCP `agentdev_status` 快查：若 `project.specPresent=true` 且 `approvalState=drifted` → 本命令是**修订流**（改动后需重新走完整审批）；`approved` 且用户只想加任务 → 同样是修订流（内容一变 approved 自动失效）。顺带读回包的 **`design` 块**（v1.1 选型四段摘要：`architecture`/`stack`/`memory`/`knowledge`，未声明=null）：修订流中它是既有选型结论的基线，新问询在此基础上增改，不推翻用户未提异议的既有段落。

## 1. 流程总览

标准路径七步，简单需求走折叠快答（§7）：

| 步 | 内容 | 产出 |
|----|------|------|
| §2 | 目标澄清 | 名字/一句话描述/工具集/流程/约束 |
| §3 | domain 引导 | `domain.category`（受控枚举 + 失配告警） |
| §4 | **段 1 业务特征问询** | 需求特征向量（JSON） |
| §5 | **段 2 架构推荐** | 1-2 候选 + 理由 + 不适配警示 + pattern 评测要点 |
| §6 | **段 3 栈选型**（含记忆/KB 问询） | 栈排序/组合分段 + 记忆三分类结论 + KB 专家建议集 |
| §8 | 评测任务集内嵌 | `eval_task_groups`（含记忆/KB 底线用例） |
| §9-§11 | 落盘 → lint → 审批 | `approved` 态 agent-spec.json |

问询结论落 spec 四个可选段：`architecture` / `stack` / `memory` / `knowledge`（schema v1.1 新增，缺省兼容——用户明确不需要的段落不写，v1 形态零负担）。

## 2. 目标澄清

向用户收集并确认四件事（一次问齐，允许用户一口气给完）：

1. **名字**：机器可读唯一标识，kebab-case（`^[a-z0-9][a-z0-9-]*$`），如 `invoice-intake-bot`。
2. **一句话描述**：这个 agent 做什么、给谁用（供人审，写进 `identity.description`）。
3. **业务域**：见 §3。
4. **工具集 / 流程 / 约束**：agent 能调哪些工具（每个：name + 一句话 description）；按执行顺序的流程步骤；必须遵守的硬性规则。

## 3. domain 引导（U5：枚举优先 + 失配告警）

`domain.category` 是受控枚举，决定 held-out 校准集路由。**优先引导用户映射到枚举值**：

| 枚举值 | 典型场景 |
|--------|----------|
| `doc-processing` | 资料/单据/合同/发票等文档的理解、抽取、校验、整理 |
| `workflow-automation` | 多步骤业务流程自动化、审批流转、系统间联动 |
| `general` | 以上都不贴切的通用任务 |

**失配告警纪律**：用户的描述与三个枚举都不贴切时（如垂直行业专属域），**不得**悄悄塞进最近似的枚举。必须明确告警：「您描述的业务域不在当前支持枚举里，评测将走通用兜底校准集（仍是双通道，不降级，但域针对性弱）。确认继续吗？」用户确认后：`category` 选 `general`，把用户的原始域描述写进 `domain.free_text`（lint 会提示同样内容，属预期）。

## 4. 段 1 业务特征问询（需求特征向量）

把用户描述翻成**特征向量**——逐位确认，听不懂术语就用右列话术。全部可选，未提及=不设（缺省语义，勿脑补 true）：

| 特征位 | 问用户的业务话术 |
|--------|------------------|
| `businessDialog` | 「是不是表单式对话/流程编排，面向业务人员维护？」（R19 双特征之一） |
| `technicalTools` | 「是不是重工具执行/数据处理/工程逻辑，开发者维护？」（R19 双特征之一） |
| `ragKnowledge` | 「需要检索业务知识库（文档/FAQ/政策）来回答吗？」 |
| `graphRag` | 「问题里有没有'顺关系链找'（多跳）或全局统计（聚合）类？关系密集吗？」（隐含 `ragKnowledge=true`——两者必须同设） |
| `memory` | 「agent 要不要记住用户给过的信息？」（细问见 §6.1 三分类） |
| `multiAgent` | 「需要多个 agent 分工协作吗？」 |
| `dynamicRouting` | 「输入要按类型动态分发给不同处理分支吗？」 |
| `planning` | 「复杂任务要先拆计划再逐步执行吗？」 |
| `reflection` | 「要不要自我检查并修正自己的输出？」 |
| `hitl` | 「关键动作前要不要人工审批？」 |
| `preferredLanguage` | 「技术栈语言有偏好吗：node / python / 平台（低代码）/ 不限？」 |
| `integrationPreference` | 组合架构集成点偏好：`工具调用` / `MCP` / `API`（缺省 MCP） |

问完向用户回读一遍向量（「我理解您的需求是……对吗」），确认后进入段 2。

## 5. 段 2 架构推荐（决策函数 + pattern 引用，理由可追溯）

用特征向量调选型决策函数。**在 `agentdev/mcp` 目录下执行**（脚本文件方式——`tsx -e` 内联脚本的相对导入在本环境不可用，勿改回 -e 形态）：

```bash
cd <projectRoot>/agentdev/mcp
cat > .agentdev-consult.ts <<'EOF'
import { loadSelectionMatrix } from '../selection/check.js';
import { recommendArchitectures, recommendStacks, recommendComposite } from '../selection/decide.js';
import { recommendRetrievalMode } from '../knowledge/advisor.js';
const phase = process.argv[2];
const features = JSON.parse(process.argv[3] ?? '{}');
if (phase === 'architecture') {
  console.log(JSON.stringify(recommendArchitectures(features), null, 2));
} else if (phase === 'stack') {
  const matrix = loadSelectionMatrix('../../agentdev/selection/matrix.json');
  const architecture = process.argv[4];
  console.log(JSON.stringify({ stacks: recommendStacks(matrix, features, architecture), composite: recommendComposite(matrix, features) }, null, 2));
} else if (phase === 'kb') {
  console.log(JSON.stringify(recommendRetrievalMode({ relationDense: features.relationDense === true, multiHopAggregation: features.multiHopAggregation === true }), null, 2));
}
EOF
npx tsx .agentdev-consult.ts architecture '<特征向量 JSON>'
```

**向用户转述纪律（1-2 候选 + 理由 + 不适配警示，顾问不静默）**：

- 取 `recommendations` 前 1-2 条（rank 1 为主推），逐条转述 `reasons`（决策函数的理由本身就是业务话术）。
- `warnings` **必须逐条转述**（它们是特征级不适配警示，与栈无关）：图谱检索的**成本警示**（LLM 抽取成本与噪音/实体消解/schema 演进/增量维护——占比高才推荐图谱）；图谱与记忆在 Dify 平台栈的局限警示。
- 无特征命中时函数给通用兜底候选——如实告知「您未表达明确架构特征，以下为通用兜底」。

**pattern 引用（T6）**：读 `agentdev/patterns/<rank1 架构>.json`，向用户转述三件事并**留作 §8 任务集素材**：

- `evalGuidance.failure_modes`：取前 2-3 条的 `name`/`symptom` 翻成「这类 agent 典型翻车点是……」（如 workflow-orchestration：死分支/状态丢失/回路不收敛/参数装配漂移）；
- `evalGuidance.case_suggestions`：评测用例建议，直接喂给 §8；
- `memoryNeeds`：该架构对记忆三分类（working/short_term/long_term）的天然需求，喂给 §6.1。

用户对推荐有异议 → 调整特征向量重跑（「您说 X，那我把特征 Y 打开再算一次」）；**不得**手改推荐结论。用户坚持指定其它架构 → 尊重选择但把决策函数对所选架构的差距如实写进 `architecture.rationale`（理由可追溯）。

## 6. 段 3 栈选型（决策表 + 记忆/KB 专家问询）

### 6.0 栈决策表

```bash
npx tsx .agentdev-consult.ts stack '<特征向量 JSON>' '<rank1 架构>'
```

转述纪律：

- `stacks.recommendations`：排序 + `verdict`（recommended=首选 / usable=可用需自建）+ `reasons` + `caveats`（非阻断提示，如语言偏好不匹配=降权、Dify 记忆 mapped 局限——mapped 局限必须明示「评测走行为级降级 + 平台豁免，内省导出类断言不适用」）。
- `stacks.exclusions`：**硬排除必须逐条告知**（如 dify-dsl × planner-executor 不适配；图谱特征下 dify 被排除），并转述 `alternative` 替代建议（换栈或混合组合放技术段）。
- `composite`：`triggered=true`（业务对话 ∧ 技术工具双特征并存，R19 硬判据）时，**优先采用组合分段方案**：`segments` 每段（business=dify-dsl 承载对话/chatflow/业务知识库；technical=自研代码栈承载工具执行/记忆/数据密集/图谱）+ `integration` 集成点（缺省 MCP）。`triggered=false` 时维持单栈建议，不硬拆段。

### 6.1 记忆需求问询（三分类按需选，反追问病症锚点）

用户说「要记忆」或段 1 `memory=true` 时，按**病症锚点**逐类确认（反追问：用户答不准时用症状引导，不要让用户选术语）：

| 分类 | 病症锚点（反追问话术） | spec 落点 |
|------|------------------------|-----------|
| `working` | 「用户上一轮刚给过的信息（姓名/订单号），agent 过几轮又问一遍——遇到过吗？」 | 会话内槽位表，no-repeat-ask 评测口径 |
| `short_term` | 「聊得很长之后，agent 会不会忘掉前文约定/超出上下文窗口？」 | 上下文窗口管理（分层压缩，关键数字受保护） |
| `long_term` | 「隔天再来、换个说法问，agent 还认得用户/找得回之前的记录吗？」 | 持久化 + 换表述召回（timeTravel 评测口径） |

结论落 `memory.classes` 数组（三选 N 或全不选=无记忆，**不声明 memory 段**）。同时提醒（来自段 2 警示）：选 `dify-dsl` 单栈 + 声明记忆 → mapped 局限（行为级降级评测）；强取证记忆诉求 → 自研栈或组合技术段。带记忆 spec 的评测底线见 §8。

### 6.2 KB 需求问询（专家建议集，理由可追溯）

段 1 `ragKnowledge=true` 时，以 KB 专家身份给出建议（判据常量：`agentdev/knowledge/advisor.ts`，引用不臆造）：

```bash
npx tsx .agentdev-consult.ts kb '{"relationDense": <bool>, "multiHopAggregation": <bool>}'
```

两位布尔取自段 1 的 `graphRag`/关系密集确认。转述纪律：

- **默认建议（必给）**：`mode: "hybrid"`——向量+BM25 双路混合检索 + 重排（`rerank: true`）。理由链第一条即生产共识：「纯向量单路对术语/编号/短查询不可靠」。
- **图谱模态（条件推荐）**：`recommendRetrievalMode` 回 `hybrid-graph` 时，**成本警示四条必须随附逐条转述**（LLM 实体关系抽取成本与噪音/实体消解复杂度/schema 演进成本/增量维护成本）——「占比不高就先 hybrid，图谱后补」。三层并存口径可给用户打底：向量/BM25 管单点事实 + 图谱管多跳聚合 + 原文回链管溯源，非替代关系。
- **栈局限声明**：Dify 平台知识库无图谱能力 → 图谱诉求下 Dify 单栈被硬排除；混合架构把图谱放技术段自研承担。
- 问清知识源（文档清单/类型）→ `knowledge.sources`；切分/新鲜度有特殊要求才展开，缺省不写（schema 子段全可选）。

无 KB 需求 → **不声明 knowledge 段**（零负担），但把「答案要可溯源」作为可选建议留一句。

## 7. 折叠快答（AC8：零感知域外的明示变化）

**触发条件（三条全满足才可折叠）**：无记忆诉求（§6.1 三分类全不中）/ 无 KB 诉求（无 ragKnowledge）/ 单栈明确（特征简单，无组合触发）。

**快答形态**：把段 1 特征向量按业务默认值拟好 + 段 2 架构推荐**仍然完整展示**（主推 + 理由，顾问不静默）+ 段 3 栈与集成点，合成**一条**确认消息，请用户一步确认或纠正。用户回复确认即视为向量与推荐全部确认；任何纠正 → 展开为标准三段问询。

**边界话术**（用户问「怎么跟以前不一样了」）：「v1.1 起设计段增加了架构/栈选型问询，简单需求可以一步快答——这是明示的流程变化；门禁/评测/部署行为与老 spec 完全兼容（不带新段的 spec 零改动仍有效）。」

## 8. 评测任务集内嵌（质量底线）

`eval_task_groups` 按**能力域**（比业务域细）分组，每组 `capability_domain` + `tasks[]`。这是**自写评测通道**的题库，也是门禁证据的来源，写法纪律：

- **数量底线**：每个能力域 ≥5 任务（lint 强校验）。
- **每任务**：
  - `id`：组内唯一，`^[a-z0-9][a-z0-9._-]*$`（用户日后 `/agentdev-eval --task <id>` 单任务快检就靠它寻址）；
  - `input`：交给被检 agent 的任务原文（黑盒输入，不写实现提示）；多轮会话用 `turns`（`[{role: user|agent, content}]`，与 input 二选一）；
  - `step_constraints`：限定该任务的执行路径（如「必须先调用 OCR 工具」）；
  - `assertions`：见下。
- **断言类型学**：`exact` / `contains` / `regex`（机械三类）/ `semantic`（LLM 判官）/ `manual`（仅留档）+ v1.1 记忆子型 `timeTravel` / `workingMemory`（机械类无判官，携有效判据可充强断言）。
- **强断言判据**（每任务 ≥1 条，lint 强校验）：exact/contains/regex 之一；timeTravel/workingMemory 携有效判据；或 `semantic` + 至少一条机械断言的组合——**semantic 单独不可充当强断言**。
- **manual 不计入门禁**：仅留档供产品/测试角色审阅签署。
- **禁恒真/空断言**：value 缺失、正则恒真（如 `.*`）会被 lint 拦。

**段 5/6 结论的任务集联动（声明即底线）**：

| spec 声明 | 任务集必须含（lint 判据） |
|-----------|--------------------------|
| `memory` 段在场 | **error 级拒过**：①工作记忆用例——某任务携 `workingMemory` 断言且用 `turns` 多轮形态（no-repeat-ask：多轮里先给信息后追问，断言不重复问）②隔天换问法用例——某任务携 `timeTravel` 断言（换表述仍命中） |
| `knowledge` 段在场 | 检索命中用例（任务 id 带 kb 词段或内容含检索命中特征）+ 忠实度用例（答案基于检索内容、防幻觉）——当前 warning 级提示，**照做不豁免** |
| `knowledge.retrieval.mode` 含 graph | 追加多跳/聚合用例（warning 级提示，照做） |
| 图形态记忆启用（`memory.backend.type` 带 graph 词段如 `sqlite-graph`，或 `memory.retrieval.signals` 含 graph 信号——schema 合规等价开关；直声明形态 `memory.graph` 待 schema 落位，v1.1 勿写） | 多跳记忆用例（任务 id 带 graph/multi-hop 词段，warning 级提示，照做） |

给用户讲解时的口径：「断言 = 验收标准。机械断言是机器能直接判对错的；semantic 是判官模型打分，必须搭配机械断言兜底；记忆类用例的验收证据来自轮次轨迹与记忆内省导出。」

## 9. 落盘 spec（v1.1 四段接线）

把确认后的内容写成 `<projectRoot>/.agentdev/agent-spec.json`，骨架（字段名逐字对齐 schema；**approval 块的 `spec_hash` 不要手填**，由 §10 脚本现算回填）：

```json
{
  "schema_version": "1.1",
  "identity": { "name": "<kebab-case>", "description": "<一句话>", "version": "0.1.0" },
  "domain": { "category": "doc-processing", "free_text": "<仅失配确认时写>" },
  "tools": [ { "name": "<tool-name>", "description": "<一句话>" } ],
  "workflow": [ "<步骤1>", "<步骤2>" ],
  "constraints": [ "<硬约束1>" ],
  "architecture": {
    "class": "<段2 rank1，8 枚举之一>",
    "patternRef": "agentdev/patterns/<class>.json",
    "rationale": "<段2 决策函数 reasons 摘要 + 用户确认结论；用户改选时写明差距>",
    "features": { "hitl": <段1 hitl>, "multiAgent": <段1 multiAgent>, "reflection": <段1 reflection> }
  },
  "stack": {
    "framework": "<段3 单栈 rank1 或组合技术段栈，7 枚举之一>",
    "language": "<node|python|platform，与栈对应>",
    "rationale": "<段3 reasons/caveats 摘要；组合方案写明业务段 Dify + 技术段自研 + 集成点>"
  },
  "memory": { "classes": ["<working|short_term|long_term 三选 N>"] },
  "knowledge": {
    "sources": [ { "name": "<知识源标识>", "type": "<markdown|pdf|db 等>" } ],
    "retrieval": { "mode": "<段6.2 advisory.mode：hybrid|hybrid-graph 等>", "rerank": true }
  },
  "eval_task_groups": [
    { "capability_domain": "<能力域>", "tasks": [
      { "id": "<task-id>", "input": "<任务原文>", "step_constraints": ["<路径约束>"],
        "assertions": [ { "type": "contains", "value": "<期望片段>" } ] }
    ] }
  ],
  "approval": { "state": "draft", "spec_hash": "sha256:<由 §10 脚本现算回填>" }
}
```

落盘纪律：

- 四段**只在有对应结论时写**：无记忆/无 KB/用户未表达架构诉求的段落整段省略（缺省兼容，勿写空壳）。带任一新段 → `"schema_version": "1.1"`；纯 v1 形态可写 `"1"`。
- `architecture.class` / `stack.framework` 取值必须来自决策函数输出（与 schema 枚举同轴）；`memory.classes` / `knowledge.retrieval.mode` 来自 §6.1/§6.2 问询结论。
- 组合方案（composite triggered）：`stack` 段写技术段栈 + rationale 写明「业务段 dify-dsl + 技术段 <framework>，集成点 <integration>」；业务段细节由 scaffold 混合渲染承接。
- draft 态也必须带 `spec_hash`（内容基线）。落盘后立即执行 §10 回填——**禁止**手写或从旧 spec 抄 hash。

## 10. 质量底线校验（quality lint）

在 `agentdev/mcp` 目录下 shell 执行（脚本文件方式，Node >= 22）：

```bash
cd <projectRoot>/agentdev/mcp
cat > .agentdev-lint.ts <<'EOF'
import fs from 'node:fs';
import { lintAgentSpecQuality } from '../protocol/quality-lint.js';
import { computeSpecHash } from '../protocol/spec-approval.js';
const p = process.argv[2];
const spec = JSON.parse(fs.readFileSync(p, 'utf-8'));
if (!spec.approval?.spec_hash) {
  spec.approval = { state: 'draft', spec_hash: computeSpecHash(spec) };
  fs.writeFileSync(p, JSON.stringify(spec, null, 2) + '\n');
  console.log('spec_hash backfilled:', spec.approval.spec_hash);
}
const r = lintAgentSpecQuality(spec);
console.log(JSON.stringify(r, null, 2));
process.exit(r.isBlocked ? 1 : 0);
EOF
npx tsx .agentdev-lint.ts ../../.agentdev/agent-spec.json
rm -f .agentdev-lint.ts .agentdev-consult.ts
```

- exit 0（`isBlocked=false`）→ 通过，进 §11。`warningCount > 0` 时逐条向用户转述 warning（含 domain 失配提示回指 §3、KB 底线提示回指 §6.2、图记忆提示回指 §6.1）。
- exit 1 → **阻断**。把每条 `issues`（severity/field/message）翻译成「哪一节、改成什么」，修完重跑。禁止跳过或手改 lint 判定。

注意：脚本顺带做了 draft 的 `spec_hash` 回填（仅当缺失时）；已回填过的重跑只校验不重写。

## 11. 产品角色审批（approval.ts approveAgentSpec）

审批是**人**的动作，AI 只执行签署。必须先向用户确认：「请产品角色确认这份 spec（可打开 agent-spec.json 过目）。确认后我将把审批状态写为 approved，签署人写谁？」拿到**人名 + 明确同意**后执行：

```bash
cd <projectRoot>/agentdev/mcp
cat > .agentdev-approve.ts <<'EOF'
import { approveAgentSpec } from './src/approval.js';
const r = approveAgentSpec(process.argv[2], process.argv[3]);
console.log(JSON.stringify(r));
EOF
npx tsx .agentdev-approve.ts .agentdev/agent-spec.json "<产品角色姓名>"
rm .agentdev-approve.ts
```

回包含 `specHash / approvedBy / approvedAt / previousState`。随后调 MCP `agentdev_status` 复核：`approvalState=approved`（顺带可复核 `design` 块与 §9 落盘内容一致）。

- 用户不同意 / 要改 → 回到对应小节修改 → 重跑 §10 → 重新确认。
- **审批绑定内容 hash（U3）**：approved 之后 spec 内容任何变更都会自动失效回 draft（drifted），scaffold/eval/deploy 全链会拦。所以审批必须是设计段的**最后一步**。

## 错误处置（用户话术）

| 症状 | 话术 |
|------|------|
| lint 报「每能力域任务数不足」 | 「<能力域> 目前只有 N 个任务，至少要 5 个。建议补的维度：<列举从用户流程与段 5 case_suggestions 里能拆出的任务>。」 |
| lint 报「缺强断言」 | 「任务 <id> 只有 semantic 断言，判官打分不能单独当验收标准，请补一条 exact/contains/regex（或携有效判据的 workingMemory/timeTravel）。」 |
| lint 报 domain 失配告警 | 「您在 §3 已确认走通用兜底，这条 warning 属预期；若不想看到，把 domain 改回贴枚举的描述。」 |
| lint 报「记忆底线：缺工作记忆用例」 | 「spec 声明了记忆（§6.1 结论），评测必须含多轮不重复追问用例：给某任务配 workingMemory 断言并用 turns 多轮脚本——先让用户给出信息，后面轮次再触发同类问题，断言 agent 不重复追问。」 |
| lint 报「记忆底线：缺隔天换问法用例」 | 「spec 声明了记忆，评测必须含换表述仍命中的用例：给某任务配 timeTravel 断言（写入记忆→换说法提问→断言仍能召回）。」 |
| consult 脚本 exclusions 非空 | 「<stack> 在 <架构> 下被硬排除（原因见回包），替代方案：<alternative>。不建议强行指定被排除组合——scaffold 前置校验会再拦一次。」 |
| 用户特征自相矛盾（选了 graphRag 但 ragKnowledge 未设） | 「图谱检索隐含知识库需求，我把 ragKnowledge 一并置真，重新计算推荐。」 |
| 脚本抛 `Cannot find module` | 「请确认在 <projectRoot>/agentdev/mcp 目录下执行，且 .agentdev-consult.ts 由本 skill 的 heredoc 原样生成（勿改用 tsx -e 内联形态）。」 |
| 审批脚本抛 `ProjectRootError` | 「识别不到项目根：请在项目根目录（含 .agentdev/ 的目录）打开终端，或设置 AGENTDEV_PROJECT_ROOT 指向项目根（Windows 建议正斜杠路径）后重试。」 |
| 审批脚本抛 `APPROVAL_LOAD` | 「agent-spec.json 读不了（路径不对或不是合法 JSON），请确认文件在 .agentdev/ 下后重试。」 |
| `agentdev_status` 显示 `drifted` | 「审批之后 spec 内容又改过，审批自动失效了——这是设计内行为。请重跑 /agentdev-brainstorm 的 §10-§11 重新校验并重批。」 |

## 完成判定清单（可判定）

- [ ] identity/domain/tools/workflow/constraints 已与用户逐项确认；domain 失配时已告警并取得用户确认
- [ ] 段 1 特征向量经用户回读确认（或 §7 快答一步确认）；graphRag 与 ragKnowledge 同设
- [ ] 段 2 架构推荐（含理由与不适配警示）已向用户展示——快答路径也未静默；结论可追溯到决策函数输出
- [ ] 段 3 栈排序/硬排除/组合方案已转述；记忆三分类有明确结论（声明或明确不声明）；KB 建议引用判据（图谱推荐随附四条成本警示）
- [ ] 声明与底线联动：memory 段 → workingMemory(turns)+timeTravel 用例在位；knowledge 段 → 检索命中+忠实度用例在位；graph 模态 → 多跳/聚合用例在位
- [ ] spec 落盘 `<projectRoot>/.agentdev/agent-spec.json`，结构对齐 schema（带新段用 schema_version 1.1；draft 也带 spec_hash）
- [ ] quality lint exit 0（isBlocked=false），warning 已逐条转述
- [ ] 产品角色本人确认后执行审批，签署人为真实人名；`agentdev_status` 复核 `approvalState=approved` 且 `design` 块与问询结论一致
- [ ] 审批后未再改动 spec 内容（若改了，已如实告知需重批）
