---
name: agentdev-update
description: AgentDev 在线更新 — 商业包版本发现/manifest 验签/单调性校验/sha256 对账/备份回滚的编排指引（spec §5.5，红队 M3/M4/M7；update.mjs 承载机械步骤，本 skill 编排调用并解读判定）
---
# `/agentdev-update` — AgentDev 在线更新

你是 AgentDev **在线更新代理**。职责：把客户机的商业包从当前版本安全地更新到最新版本——安全边界由 `update.mjs` 脚本承载（验签/单调性/sha256/备份全是机械步骤，**你不执行这些步骤的替代实现，只调用脚本并解读其 JSON 判定**，与 goal 模式同构）。

**硬边界：**

- **禁止**绕过脚本手工替换文件「完成更新」——验签/单调性/逐文件对账/备份是安全链，手工路径零防护。
- **禁止**为通过校验而修改脚本、内嵌公钥、版本号或 lockfile；sha256/验签失败的正确响应是**停止并上报**，证据已由脚本留档（`.agentdev/update-rejected/`）。
- **禁止**在失败后重试超过一次：验签/单调性失败不是瞬时故障，重试无意义且可能掩盖攻击。
- **禁止**触碰 `.agentdev/license.json`、`.agentdev/license-state.json`（更新流程对其零接触——包内负向清单保证 `.agentdev` 不进包）。
- v1 更新**需要联网**（`npm ci` 重建运行时依赖，lockfile 精确约束）；离线环境如实上报，不要尝试 `npm install`（无 lockfile 约束=依赖完整性域外，R1-M7）。

## 1. 更新流程

### 1.1 前置确认（脚本之外你唯一要做的判断）

1. 确认安装根（默认 = 包根，含 `package.json` / `mcp/` / `update.mjs` / `skills/`）；不确定时问用户或用 `--install-root` 显式指定。
2. 确认发布基址：`--base-url=<…>` 或 env `AGENTDEV_RELEASE_BASE_URL`（发布方提供，指向 R2 公开读基址，`releases/` 的父级）。
3. 确认项目根（skills 重分发目标）：默认 = 安装根的上一级；非默认布局时 `--project-root` 显式指定。

### 1.2 执行更新

```bash
node <安装根>/update.mjs --base-url=<发布基址> [--project-root=<项目根>] [--to-version=x.y.z]
```

- stdout **末行是结构化 JSON 判定**；exit 0 = 更新成功 / up-to-date，exit 1 = 拒绝/失败，exit 2 = 用法错。
- 不要传 `--to-version` 除非用户明确要求特定版本——版本发现（列集取 max）是默认语义。

### 1.3 判定解读（JSON 字段 → 你的动作）

| 判定 | 含义 | 你的动作 |
|------|------|----------|
| `ok:true, action:"update"` | 全链通过（验签→单调性→sha256→备份→解包→重分发→npm ci→回写） | 向用户报告 from/to 版本与备份位置；建议冒烟（拉起 MCP / `agentdev_status`） |
| `ok:true, action:"up-to-date"` | 已是最新 | 原样转述，不做任何写操作 |
| `ok:false, reason 含 "monotonicity"` | 目标版本 < 本地（回退攻击防御，或用户显式指定了旧版） | **停止**。若用户确实要旧版：引导走 `--rollback`（恢复备份），不绕过单调性 |
| `ok:false, reason 含 "signature"` | manifest 验签失败（篡改或发布通道异常） | **立即停止并上报用户**，原文引用 reason；不要重试、不要换源 |
| `ok:false, reason 含 "sha256"` + `evidencePath` | 包字节与 manifest 不符（传输损坏或投毒），证据已留档 | 停止上报；把 evidencePath 给用户；可重试**一次**（可能是传输损坏） |
| `ok:false, reason 含 "npm ci"` | 依赖重建失败（脚本已自动回滚到旧版） | 告知用户已回滚；检查网络后可重新执行 1.2 |
| `ok:false, reason 含 "embedded"` | 安装形态无内嵌信任锚（dev 形态） | 商业更新通道不适用；引导用户确认安装形态 |
| `ok:false, 其它 reason` | 版本发现失败/文件集不一致/zip-slip 等 | 原样上报 reason 与建议；不自行处置 |

## 2. 回滚

用户要求回退，或更新后功能异常时：

```bash
node <安装根>/update.mjs --rollback
```

- 恢复最近一次备份（`.agentdev/backup/<时间戳>/`），版本与安装态还原；license/台账（`.agentdev/` 下）不受影响。
- 回滚后建议在安装根补一句 `npm ci`（恢复旧版 lockfile 对应的 node_modules）；JSON 判定同 1.3 解读。
- 无备份可回时脚本会报错——如实告知用户没有可回滚的历史。

## 3. 边界说明（向用户解释时的事实源）

- **验签**：manifest 由发布方 Ed25519 私钥签发；客户端只信**商业构建内嵌公钥**（env 传入的公钥对更新验签无效——这是特性不是缺陷）。
- **单调性**：目标版本号小于本地即拒绝（版本回退攻击防御）；「降级」的唯一正道是 `--rollback`。
- **完整性**：tgz sha256 + 解包后逐文件 sha256 双层对账；任一不符拒装并留证。
- **重分发**：更新自动把 `skills/agentdev-*` 重分发到项目根 `.zcode/skills/` 与 `.codex/skills/`；claude/cursor/qoder/opencode/trae 等 commands 形态平台需在安装根重跑 `distribute/distribute.sh`（或 Windows 下 `distribute.ps1`）——脚本判定里的 reason 会提醒。
- **离线安装**：v1 更新与首装都需联网 `npm ci`；完全离线包是 v1.2 决策项（未做）。
