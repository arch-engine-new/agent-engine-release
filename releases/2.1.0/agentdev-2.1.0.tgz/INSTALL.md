# AgentDev Commercial 2.1.0 — 安装文档

## 环境要求

- Node.js >= 22
- 首次安装与每次更新都需要联网执行 `npm ci`（按包内 `package-lock.json` 精确重建运行时依赖；
  v1 不携带 node_modules——完全离线包为 v1.2 决策项）

## 安装路径 A：本机级一键安装（v2.1.0 推荐）

解压后（任意安装根，如 `<项目根>/agentdev/`）在**包根**执行：

- macOS / Linux：`bash install.sh`
- Windows PowerShell：`.\install.ps1`

脚本自动完成四步：node >= 22 检查 → 包根 `npm ci` → **用户级注册**（agentdev-mcp 合并进
claude / cursor / zcode / codex / opencode / qoder / trae 七平台用户级 MCP 配置，不覆盖既有
条目、写前备份；八个 agentdev-* 命令分发到各平台用户级命令目录）→ stdio boot 冒烟握手。

- 用户级语义：不设 AGENTDEV_PROJECT_ROOT——项目根由运行时 cwd 上溯 `.agentdev/` 标记发现。
- 预览/卸载/限域：`--dry-run`（或 PowerShell `-DryRun`）预览不落盘；`--uninstall`（`-Uninstall`）
  只摘 agentdev-* 条目；`--ide=<name>` 限单平台（claude|cursor|zcode|codex|opencode|qoder|trae）。
- 本机安装完成后仍需下面的「指纹采集 + 激活」两步（license 与机器绑定）。

## 安装路径 B：手动逐步安装

1. 解压 `agentdev-2.1.0.tgz` 到客户项目根下一级目录（推荐 `<项目根>/agentdev/`——
   下述 skills 重分发与 distribute 脚本的默认解析都依赖这个布局）。
2. 安装运行时依赖（包根执行）：`npm ci`
3. 采集机器指纹：`node agentdev-fingerprint.mjs`（stdout 为 32-hex 指纹，发给发布方签发 license）。
4. 激活：`node agentdev-activate.mjs <license.json>`——双条件判据（激活成功 ∧ 复查 activated）
   才算成功；license 与机器绑定，换机需重新签发。
5. skills 重分发到客户项目（本包 update 工具会在更新时自动重分发；首装手动执行一次）：
   `node update.mjs --redistribute-only --project-root=<项目根>`
6. 注册 MCP 服务：入口 `node <安装根>/mcp/src/index.js`，env `AGENTDEV_PROJECT_ROOT=<项目根>`；
   模板见 `distribute/mcp-configs/commercial-node.mcp.json`（同目录 dev 模板为开发形态参考，
   商业包不含 tsx/src 源，按本文件的 node 入口注册）。

> 走路径 A 的用户级注册已含步骤 6 的等价物（无需再手动注册项目级 MCP）；步骤 5 的
> 项目级 skills 重分发在「每项目需要斜杠命令」时执行。

## 在线更新

`node update.mjs --base-url=<发布基址>`（或 env `AGENTDEV_RELEASE_BASE_URL`）。
流程：版本发现（列集取 max）→ manifest 验签（内嵌公钥）→ 单调性校验（拒版本回退）→
下载 sha256 校验 → 上一版备份 `.agentdev/backup/` → 解包 → skills 重分发 → `npm ci` →
版本回写。回退到旧版：`node update.mjs --rollback`（恢复最近一次备份）。

## 安全说明

- 包完整性由 Ed25519 签名 manifest（内嵌公钥验签）+ 逐文件 sha256 对账保证；sha256 不符
  会拒装并留证（`.agentdev/update-rejected/`）。
- **held-out 校准集位置**：`<安装根>/calibration/`（`routing.json` 域路由 + `domains/`
  两域 JSON 任务集 + `check.js` 结构校验器）——它是 eval 双通道中校准通道的运行必需数据，
  删除或改动会使 `agent_eval_run` 报错（fail-closed）。可随时自检：
  `node calibration/check.js`（exit 0 = 包内副本结构完好）。
- 商业产物经混淆（standard 档）：防君子不防决心破解者；强 enforcement 依赖服务端吊销
  与心跳复核（v1.2 路线）。
- 本包内不存在 ts 源/测试/私钥（负向清单强制）；发现任何此类文件请勿安装并联系发布方。
