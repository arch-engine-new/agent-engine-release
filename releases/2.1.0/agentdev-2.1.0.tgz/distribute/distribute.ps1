# distribute.ps1 - distribute agentdev/skills/agentdev-*/SKILL.md into this
# repo's seven platform directories so /agentdev-init etc. are reachable in
# every supported IDE (ported from arch-engine
# scripts/distribute-global-commands.ps1, adapted to PROJECT-LEVEL distribution).
#
# Platform mapping (arch-engine reference rules + this repo's armed layout):
#   skills form (dir/SKILL.md copied wholesale):
#     .zcode/skills/agentdev-*/   (zcode uses skills form here; brief-mandated)
#     .codex/skills/agentdev-*/   (reference script: codex -> skills)
#   commands form (frontmatter `name:` line dropped; file <name>.md):
#     .claude/commands  .cursor/commands  .qoder/commands
#     .opencode/commands  .trae/commands
#     (trae is not in the reference script; mapped to commands/ to mirror the
#      in-repo command-platform convention - documented adaptation decision)
#
# Contract:
#   - agentdev-* prefix ONLY - other commands/skills in platform dirs are
#     never touched
#   - overwrite-style idempotent: safe to re-run (upgrade re-distributes);
#     a pre-existing agentdev-* skill dir that is a junction/symlink has ONLY
#     the link itself removed (never -Recurse through a reparse point - that
#     follows the link and wipes the real directory behind it; junction rule,
#     prior incident record)
#   - missing target dirs are created; one report line per platform
#   - -DryRun prints planned target paths without writing anything
#   - standalone runnable: agentdev\distribute\distribute.ps1 [-DryRun]
param(
  [switch]$DryRun
)
$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Split-Path -Parent (Split-Path -Parent $scriptDir)
$srcSkillsDir = Join-Path $repoRoot "agentdev\skills"

if (-not (Test-Path $srcSkillsDir)) {
  Write-Error "distribute: source not found: $srcSkillsDir"
  exit 1
}

$skillDirs = Get-ChildItem -Path $srcSkillsDir -Directory -Filter "agentdev-*" -ErrorAction SilentlyContinue
if (-not $skillDirs -or @($skillDirs).Count -eq 0) {
  Write-Error "distribute: no agentdev-* skill dirs in $srcSkillsDir - source incomplete?"
  exit 1
}

# Frontmatter transform: drop the `name:` line inside the frontmatter block only
# (commands form carries the command name via file name, mirroring apt commands).
function Get-CommandBody([string]$skillMdPath) {
  $lines = [IO.File]::ReadAllLines($skillMdPath)
  $out = New-Object System.Collections.Generic.List[string]
  $inFrontmatter = $false
  for ($i = 0; $i -lt $lines.Count; $i++) {
    $line = $lines[$i]
    if ($i -eq 0 -and $line -eq "---") { $inFrontmatter = $true; $out.Add($line); continue }
    if ($inFrontmatter -and $line -eq "---") { $inFrontmatter = $false; $out.Add($line); continue }
    if ($inFrontmatter -and $line -match "^name:\s") { continue }
    $out.Add($line)
  }
  return ($out -join "`n") + "`n"
}

# Remove an existing agentdev-* target: a reparse point loses ONLY the link
# itself (cmd rmdir, no /s); a real directory is deleted wholesale so a
# re-distribution cannot leave stale files behind.
function Remove-ExistingTarget([string]$dst) {
  if (Test-Path -LiteralPath $dst) {
    $item = Get-Item -LiteralPath $dst -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
      cmd /c rmdir "$dst" | Out-Null
      if ($LASTEXITCODE -ne 0) {
        throw "distribute: failed to remove junction/symlink at $dst (cmd rmdir exit $LASTEXITCODE)"
      }
    } else {
      Remove-Item -LiteralPath $dst -Recurse -Force
    }
  }
}

# -- skills form: zcode + codex --
foreach ($p in @("zcode", "codex")) {
  $dstRoot = Join-Path $repoRoot ".$p\skills"
  New-Item -ItemType Directory -Force -Path $dstRoot | Out-Null
  foreach ($d in $skillDirs) {
    $dst = Join-Path $dstRoot $d.Name
    if ($DryRun) {
      Write-Host ("DRY ./{0}/skills/{1}/SKILL.md" -f $p, $d.Name)
    } else {
      Remove-ExistingTarget $dst
      Copy-Item -Path $d.FullName -Destination $dst -Recurse -Force
    }
  }
  if (-not $DryRun) {
    Write-Host ("OK .{0}/skills: {1} agentdev-* skills" -f $p, @($skillDirs).Count)
  }
}

# -- commands form: claude + cursor + qoder + opencode + trae --
foreach ($p in @("claude", "cursor", "qoder", "opencode", "trae")) {
  $dstDir = Join-Path $repoRoot ".$p\commands"
  New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
  foreach ($d in $skillDirs) {
    $skillMd = Join-Path $d.FullName "SKILL.md"
    if (-not (Test-Path -LiteralPath $skillMd)) {
      Write-Error "distribute: missing SKILL.md in $($d.FullName)"
      exit 1
    }
    $dst = Join-Path $dstDir ($d.Name + ".md")
    if ($DryRun) {
      Write-Host ("DRY ./{0}/commands/{1}.md" -f $p, $d.Name)
    } else {
      $body = Get-CommandBody $skillMd
      [IO.File]::WriteAllText($dst, $body, (New-Object System.Text.UTF8Encoding($false)))
    }
  }
  if (-not $DryRun) {
    Write-Host ("OK .{0}/commands: {1} agentdev-* commands" -f $p, @($skillDirs).Count)
  }
}

if ($DryRun) {
  Write-Host "distribute: dry-run complete (nothing written)"
} else {
  Write-Host "distribute: done (agentdev-* only; non-agentdev-* untouched)"
}
exit 0
