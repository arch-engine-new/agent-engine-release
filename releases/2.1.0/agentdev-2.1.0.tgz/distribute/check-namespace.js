#!/usr/bin/env node
/**
 * check-namespace.js - R10 命名空间核验 + AC1 分发完整性（L1 部分）。
 *
 * 零依赖（仅 node:fs / node:path），fail-closed：任一检查不过即非零退出。
 *
 * 检查面（对齐 task-14 brief）：
 *   1. 命令名零交集：agentdev/skills 下 agentdev-* 目录的命令名集合 ∩ 本仓现存
 *      apt 系命令名集合（.zcode/skills、.zcode/commands、.claude/commands、
 *      .cursor/commands、.qoder/commands、.opencode/commands 全量枚举，
 *      含 apt-* 前缀与非前缀别名）== 空；
 *   2. skills 源隔离：agentdev/skills/** 内无 .apt/ 与 .ai/ 的**路径引用**
 *      （`.apt/`/`.ai/` 后跟真实路径段才算引用；禁令性提及不算），
 *      且必须存在 .agentdev/ 状态目录引用（独立命名空间在用）；
 *   3. MCP 名：agentdev/mcp/package.json 的 name 与 src/index.ts 的
 *      SERVER_NAME 均为 `agentdev-mcp`；
 *   4. 分发完整性（七端 × 8 文件）：skills 形态 .zcode/.codex 的
 *      agentdev-<name>/SKILL.md 与源逐字节一致；commands 形态
 *      .claude/.cursor/.qoder/.opencode/.trae 的 agentdev-*.md 与源
 *      「仅去 frontmatter name: 行」后的内容一致。
 *
 * 用法：node agentdev/distribute/check-namespace.js
 * 全过 → exit 0 并打印各检查 OK 行；任何失败 → exit 1。
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(scriptDir, "..", "..");
const srcSkillsDir = path.join(repoRoot, "agentdev", "skills");

/** 预期八命令（目录名；与 frontmatter name 一致性强校验；goal T5 起含 agentdev-goal，commercial T4 起含 agentdev-update） */
const EXPECTED_COMMANDS = [
  "agentdev-init",
  "agentdev-brainstorm",
  "agentdev-scaffold",
  "agentdev-eval",
  "agentdev-deploy",
  "agentdev-status",
  "agentdev-goal",
  "agentdev-update",
].sort();

/** skills 形态平台（SKILL.md 原样）与 commands 形态平台（去 name 行） */
const SKILLS_FORM_PLATFORMS = ["zcode", "codex"];
const COMMANDS_FORM_PLATFORMS = ["claude", "cursor", "qoder", "opencode", "trae"];

/** 累积失败清单；任何一条非空 → exit 1 */
const failures = [];
function fail(message) {
  failures.push(message);
}

/** 读文件；读不到按 fail-closed 记失败并返回 null */
function readTextIfExists(filePath, label) {
  try {
    return fs.readFileSync(filePath, "utf-8");
  } catch (err) {
    fail(`${label}: 不可读（${err && err.code ? err.code : String(err)}）: ${filePath}`);
    return null;
  }
}

/**
 * 解析 frontmatter 的 name: 字段；无 frontmatter / 无 name 返回 null。
 * （commands 文件没有 name 行属预期，此函数只用于 skills 源。）
 */
function parseFrontmatterName(markdown) {
  const lines = markdown.split(/\r?\n/);
  // 首行不是 --- 即无 frontmatter：commands 形态文件本就无 name 行，返回 null 由调用方按源一致性单独裁决，不在解析层误报。
  if (lines[0] !== "---") return null;
  for (let i = 1; i < lines.length; i++) {
    // 只在首个 frontmatter 块内匹配：遇闭合 --- 仍未命中即判无 name，不扫正文——正文示例/代码块里的 name: 行不得误当元数据。
    if (lines[i] === "---") return null;
    const match = lines[i].match(/^name:\s*(.+?)\s*$/);
    if (match) return match[1];
  }
  return null;
}

/** commands 形态变换（与 distribute 脚本同构）：删 frontmatter 内 name: 行 */
function toCommandBody(markdown) {
  const lines = markdown.split(/\r?\n/);
  const out = [];
  let inFrontmatter = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (i === 0 && line === "---") { inFrontmatter = true; out.push(line); continue; }
    if (inFrontmatter && line === "---") { inFrontmatter = false; out.push(line); continue; }
    if (inFrontmatter && /^name:\s/.test(line)) continue;
    out.push(line);
  }
  // split 对「以 \n 结尾」的文本会产生末尾空串元素——剥掉一个，保持与
  // awk/PowerShell 变换逐字节一致（末尾恰一个换行）
  if (out.length > 1 && out[out.length - 1] === "" && markdown.endsWith("\n")) out.pop();
  return out.join("\n") + (markdown.endsWith("\n") ? "\n" : "");
}

// ---------------------------------------------------------------------------
// 1. 源清单：agentdev skills + frontmatter name 一致性
// ---------------------------------------------------------------------------
let skillDirs = [];
try {
  skillDirs = fs
    .readdirSync(srcSkillsDir, { withFileTypes: true })
    .filter((e) => e.isDirectory() && e.name.startsWith("agentdev-"))
    .map((e) => e.name)
    .sort();
} catch (err) {
  fail(`源目录不可读: ${srcSkillsDir}（${String(err)}）`);
}

if (JSON.stringify(skillDirs) !== JSON.stringify(EXPECTED_COMMANDS)) {
  fail(
    `agentdev/skills 目录清单与预期八命令不符：实际 [${skillDirs.join(", ")}]，预期 [${EXPECTED_COMMANDS.join(", ")}]`,
  );
}

/** agentdev 命令名 → SKILL.md 正文（供分发一致性检查复用） */
const skillBodies = new Map();
for (const name of skillDirs) {
  const skillPath = path.join(srcSkillsDir, name, "SKILL.md");
  const body = readTextIfExists(skillPath, `skills 源 ${name}`);
  if (body === null) continue;
  const frontName = parseFrontmatterName(body);
  if (frontName !== name) {
    fail(`skills 源 ${name}: frontmatter name（${frontName ?? "缺失"}）与目录名不一致`);
  }
  if (!/^agentdev-[a-z]+$/.test(name)) {
    fail(`skills 源 ${name}: 命令名不符合 agentdev- 前缀纪律`);
  }
  skillBodies.set(name, body);
}

// ---------------------------------------------------------------------------
// 2. R10：与 apt 系命令名零交集
// ---------------------------------------------------------------------------
const aptCommandNames = new Set();

/** apt-* skill 目录名（.zcode/skills 等任何存在位置） */
for (const rel of [".zcode/skills", ".codex/skills"]) {
  const dir = path.join(repoRoot, rel);
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    continue; // 平台目录不存在不是失败（分发完整性由第 5 检查单独把关）
  }
  for (const entry of entries) {
    if (entry.isDirectory() && entry.name.startsWith("apt-")) aptCommandNames.add(entry.name);
  }
}

/** 命令目录全量枚举：apt-* 前缀与非前缀别名（如 feature.md/verify.md）；
 *  agentdev-*.md 是本工具自己的分发产物，不属于外部命令名集合 */
for (const rel of [
  ".zcode/commands",
  ".claude/commands",
  ".cursor/commands",
  ".qoder/commands",
  ".opencode/commands",
]) {
  const dir = path.join(repoRoot, rel);
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    continue;
  }
  for (const entry of entries) {
    if (entry.isFile() && entry.name.endsWith(".md") && !entry.name.startsWith("agentdev-")) {
      aptCommandNames.add(entry.name.replace(/\.md$/, ""));
    }
  }
}

const collision = EXPECTED_COMMANDS.filter((name) => aptCommandNames.has(name));
if (collision.length > 0) {
  fail(`R10 命令名撞车：${collision.join(", ")} 与本仓 apt 系命令同名`);
}

// ---------------------------------------------------------------------------
// 3. skills 源隔离：无 .apt/ 与 .ai/ 路径引用；有 .agentdev/ 引用
// ---------------------------------------------------------------------------
// 违规判据：`.apt/` 或 `.ai/` 后跟真实路径段（字母/数字开头的段）才算**引用**；
// 「禁止读写 `.apt/`、`.ai/`」这类禁令性提及后面跟的是反引号/标点，不匹配。
// T14-M1 加固：前缀不再要求空白/引号限定——行首或标点紧跟（如 `**.apt/foo`、
// `-.apt/foo`）的同形引用同样漏检过；改为 `(^|[^A-Za-z])` 分支，只要前一个字符
// 不是英文字母（排除 `foo.apt/` 这类域名/标识符内部片段）即视为路径引用。
const FORBIDDEN_PATH_REF = /(^|[^A-Za-z])\.(apt|ai)\/[A-Za-z0-9]/;
const AGENTDEV_REF = /\.agentdev\//;

/**
 * --self-test：守卫正则自身的行为负向用例（T14-M1）。
 * 漏检形态必须命中（`**.apt/foo` 等），禁令性提及必须不命中（否则源文件全量误报）。
 * 独立 flag 而非每次运行内联断言：主检查零开销，用例随 CI/手工显式复跑。
 */
function selfTestForbiddenPathRef() {
  const mustMatch = [
    "**.apt/foo",
    "-.apt/orchestration/x.md",
    "(.ai/rules",
    "行首.apt/hidden",
    ".apt/orchestration/v1.md",
    "\t.ai/config",
  ];
  const mustNotMatch = [
    "禁止读写 `.apt/`、`.ai/`",
    "不要动 .apt/ 或 .ai/（禁令性提及，后随标点）",
    "独立命名空间 .agentdev/ 在用",
    "标识符内部片段 foo.apt/bar 应由业务侧裁决", // 前缀是英文字母：域名/包名形态不判违规
  ];
  const problems = [];
  for (const line of mustMatch) {
    if (!FORBIDDEN_PATH_REF.test(line)) problems.push(`应命中未命中: ${JSON.stringify(line)}`);
  }
  for (const line of mustNotMatch) {
    if (FORBIDDEN_PATH_REF.test(line)) problems.push(`不应命中却命中: ${JSON.stringify(line)}`);
  }
  if (problems.length > 0) {
    console.error("check-namespace --self-test: FAIL");
    for (const problem of problems) console.error(`  - ${problem}`);
    return 1;
  }
  console.log("check-namespace --self-test: OK（FORBIDDEN_PATH_REF 漏检/误报用例全过）");
  return 0;
}

if (process.argv.includes("--self-test")) {
  process.exit(selfTestForbiddenPathRef());
}

let hasAgentdevRef = false;
for (const [name, body] of skillBodies) {
  const lines = body.split(/\r?\n/);
  lines.forEach((line, idx) => {
    if (FORBIDDEN_PATH_REF.test(line)) {
      fail(`skills 源 ${name}:${idx + 1} 出现 .apt/.ai 路径引用（命名空间隔离违规）: ${line.trim()}`);
    }
  });
  if (AGENTDEV_REF.test(body)) hasAgentdevRef = true;
}
if (!hasAgentdevRef) {
  fail("skills 源内没有任何 .agentdev/ 状态目录引用——独立命名空间未在用？");
}

// ---------------------------------------------------------------------------
// 4. MCP 名：package.json name + index.ts SERVER_NAME
// ---------------------------------------------------------------------------
const pkgPath = path.join(repoRoot, "agentdev", "mcp", "package.json");
const pkgRaw = readTextIfExists(pkgPath, "mcp package.json");
if (pkgRaw !== null) {
  try {
    const pkg = JSON.parse(pkgRaw);
    if (pkg.name !== "agentdev-mcp") {
      fail(`MCP 名核验失败：package.json name = ${JSON.stringify(pkg.name)}，预期 "agentdev-mcp"`);
    }
  } catch (err) {
    fail(`mcp package.json 不是合法 JSON: ${String(err)}`);
  }
}

const indexPath = path.join(repoRoot, "agentdev", "mcp", "src", "index.ts");
const indexRaw = readTextIfExists(indexPath, "mcp src/index.ts");
if (indexRaw !== null) {
  const serverName = indexRaw.match(/export const SERVER_NAME\s*=\s*"([^"]+)"/);
  if (!serverName || serverName[1] !== "agentdev-mcp") {
    fail(
      `MCP 名核验失败：index.ts SERVER_NAME = ${serverName ? serverName[1] : "未找到"}，预期 "agentdev-mcp"`,
    );
  }
}

// ---------------------------------------------------------------------------
// 5. 分发完整性（AC1 L1 部分）：七端 × 8 文件在位且与源一致
// ---------------------------------------------------------------------------
let distFailuresBefore = failures.length;

for (const p of SKILLS_FORM_PLATFORMS) {
  for (const name of EXPECTED_COMMANDS) {
    const dst = path.join(repoRoot, `.${p}`, "skills", name, "SKILL.md");
    const dstBody = readTextIfExists(dst, `分发产物 .${p}/skills/${name}`);
    if (dstBody === null) continue;
    const srcBody = skillBodies.get(name);
    if (srcBody !== undefined && dstBody !== srcBody) {
      fail(`分发产物 .${p}/skills/${name}/SKILL.md 与源内容不一致（请重跑分发脚本）`);
    }
  }
  if (failures.length === distFailuresBefore) {
    console.log(`OK .${p}/skills: ${EXPECTED_COMMANDS.length} agentdev-* skills 与源一致`);
  }
  distFailuresBefore = failures.length;
}

for (const p of COMMANDS_FORM_PLATFORMS) {
  for (const name of EXPECTED_COMMANDS) {
    const dst = path.join(repoRoot, `.${p}`, "commands", `${name}.md`);
    const dstBody = readTextIfExists(dst, `分发产物 .${p}/commands/${name}.md`);
    if (dstBody === null) continue;
    const srcBody = skillBodies.get(name);
    if (srcBody !== undefined && dstBody !== toCommandBody(srcBody)) {
      fail(`分发产物 .${p}/commands/${name}.md 与源变换不一致（请重跑分发脚本）`);
    }
  }
  if (failures.length === distFailuresBefore) {
    console.log(`OK .${p}/commands: ${EXPECTED_COMMANDS.length} agentdev-* commands 与源一致`);
  }
  distFailuresBefore = failures.length;
}

// ---------------------------------------------------------------------------
// 汇总：fail-closed
// ---------------------------------------------------------------------------
if (failures.length > 0) {
  console.error(`check-namespace: FAIL（${failures.length} 项）`);
  for (const message of failures) console.error(`  - ${message}`);
  process.exit(1);
}
console.log(
  `check-namespace: OK（${EXPECTED_COMMANDS.length} 命令与 apt 系 ${aptCommandNames.size} 名零交集；` +
    `.agentdev/ 独立命名空间在用；MCP 名 agentdev-mcp；七端分发完整一致）`,
);
