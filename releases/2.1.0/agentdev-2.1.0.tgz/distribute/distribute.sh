#!/usr/bin/env bash
# distribute.sh - 把 agentdev/skills/agentdev-*/SKILL.md 分发到本仓七端目录，
# 让 /agentdev-init 等八命令（含 agentdev-goal、agentdev-update）在各 IDE 平台可达（自 arch-engine
# scripts/distribute-global-commands.sh 移植，适配为**项目级**分发）。
#
# 平台映射（对照 arch-engine 参考脚本的目标路径规则 + 本仓 armed 形态）：
#   skills 形态（目录/SKILL.md 原样拷贝）：
#     .zcode/skills/agentdev-*/   （本仓 zcode 走 skills 形态，brief 指定）
#     .codex/skills/agentdev-*/   （参考脚本 codex -> skills）
#   commands 形态（frontmatter 去掉 name: 行，落 <platform>/commands/<name>.md）：
#     .claude/commands  .cursor/commands  .qoder/commands
#     .opencode/commands  .trae/commands
#     （trae 不在参考脚本内，按本仓命令类平台同构映射到 commands/；
#      参考脚本无 trae 条目是既有事实，此处为记录在案的适配决策）
#
# Contract：
#   - agentdev-* 前缀 ONLY —— 平台目录里用户的 / 其它工具集的命令永不触碰
#   - overwrite 幂等：可重跑（升级即重分发）；既有 agentdev-* skill 目录若是
#     symlink/junction，只摘链接本身（绝不 rm -rf 穿过链接——会顺着删掉链接
#     背后的真实目录；junction 规则，既有事故记录）
#   - 缺失目标目录自动创建；每平台一行报告
#   - --dry-run：只打印将生成的目标路径，不落盘（验收用）
#   - 独立可运行：bash agentdev/distribute/distribute.sh [--dry-run]
set -euo pipefail

DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    *) echo "ERROR: distribute: unknown argument: $arg (supported: --dry-run)" >&2; exit 1 ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SRC_SKILLS_DIR="$REPO_ROOT/agentdev/skills"

if [ ! -d "$SRC_SKILLS_DIR" ]; then
  echo "ERROR: distribute: source not found: $SRC_SKILLS_DIR" >&2
  exit 1
fi

# frontmatter 变换：仅删 frontmatter 块内的 name: 行（commands 形态无 name 字段，
# 命令名由文件名承载——与 apt 命令文件同构）
strip_frontmatter_name() {
  awk '
    NR == 1 && $0 == "---" { fm = 1; print; next }
    fm == 1 && $0 == "---" { fm = 0; print; next }
    fm == 1 && $0 ~ /^name:[[:space:]]/ { next }
    { print }
  ' "$1"
}

shopt -s nullglob
SKILL_DIRS=("$SRC_SKILLS_DIR"/agentdev-*/)
shopt -u nullglob
if [ "${#SKILL_DIRS[@]}" -eq 0 ]; then
  echo "ERROR: distribute: no agentdev-* skill dirs in $SRC_SKILLS_DIR - source incomplete?" >&2
  exit 1
fi

# 既有 agentdev-* 目标的清理：symlink 只摘链接；真实目录整体删除（防升级残留）
remove_existing() {
  local dst="$1"
  if [ -L "$dst" ]; then
    rm "$dst"
  elif [ -e "$dst" ]; then
    rm -rf "$dst"
  fi
}

# ── skills 形态：zcode + codex ──
for p in zcode codex; do
  dst_root="$REPO_ROOT/.$p/skills"
  mkdir -p "$dst_root"
  count=0
  for src in "${SKILL_DIRS[@]}"; do
    name="$(basename "$src")"
    dst="$dst_root/$name"
    if [ "$DRY_RUN" -eq 1 ]; then
      echo "DRY ./$p/skills/$name/SKILL.md"
    else
      remove_existing "$dst"
      cp -R "$src" "$dst"
    fi
    count=$((count + 1))
  done
  if [ "$DRY_RUN" -eq 0 ]; then
    echo "OK .$p/skills: $count agentdev-* skills"
  fi
done

# ── commands 形态：claude + cursor + qoder + opencode + trae ──
for p in claude cursor qoder opencode trae; do
  dst_dir="$REPO_ROOT/.$p/commands"
  mkdir -p "$dst_dir"
  count=0
  for src in "${SKILL_DIRS[@]}"; do
    name="$(basename "$src")"
    skill_md="$src/SKILL.md"
    if [ ! -f "$skill_md" ]; then
      echo "ERROR: distribute: missing SKILL.md in $src" >&2
      exit 1
    fi
    dst="$dst_dir/$name.md"
    if [ "$DRY_RUN" -eq 1 ]; then
      echo "DRY ./$p/commands/$name.md"
    else
      rm -f "$dst"
      strip_frontmatter_name "$skill_md" > "$dst"
    fi
    count=$((count + 1))
  done
  if [ "$DRY_RUN" -eq 0 ]; then
    echo "OK .$p/commands: $count agentdev-* commands"
  fi
done

if [ "$DRY_RUN" -eq 1 ]; then
  echo "distribute: dry-run complete (nothing written)"
else
  echo "distribute: done (agentdev-* only; non-agentdev-* untouched)"
fi
