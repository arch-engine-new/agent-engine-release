# mcp-configs：七端 MCP 注册片段模板（Task 15，AC1「配置校验通过」的实体）

T14 分发的是六条 `agentdev-*` skills/commands（对话层入口）；本目录补齐另一半——
`agentdev-mcp` MCP server 在七端 IDE 的注册片段模板（工具层入口）。两份产物合起来
才是「skills+MCP 混合形态」（spec R5）在每端的完整安装面。

## 平台 × 安装位置 × 配置形态

| 平台 | 安装位置 | 配置形态 | server 字段名 |
|------|----------|----------|---------------|
| claude code | `<repo>/.mcp.json` | JSON | `mcpServers["agentdev-mcp"]`（command + args + env） |
| cursor | `<repo>/.cursor/mcp.json` | JSON | `mcpServers["agentdev-mcp"]`（同 claude 形态） |
| zcode | `<repo>/.zcode/mcp.json` | JSON | `mcpServers["agentdev-mcp"]`（同 claude 形态） |
| trae | `<repo>/.trae/mcp.json` | JSON | `mcpServers["agentdev-mcp"]`（同 claude 形态） |
| qoder | `<repo>/.qoder/mcp.json` | JSON | `mcpServers["agentdev-mcp"]`（同 claude 形态） |
| opencode | `<repo>/opencode.json` | JSON | `mcp["agentdev-mcp"]`（`type:"local"` + command **数组** + environment） |
| codex | `~/.codex/config.toml` | TOML | `[mcp_servers.agentdev-mcp]`（command 字符串 + args 数组 + env 内联表） |

## 占位符约定

所有模板统一用 `__AGENTDEV_REPO_ROOT__` 占位仓库根绝对路径。安装（或校验器）替换时
Windows 路径建议正斜杠（`D:/software/agent-engine`），与 `AGENTDEV_PROJECT_ROOT` 的
解析容错一致（paths.ts）。

## 入口形态

- 开发态（当前默认）：`node <repo>/agentdev/mcp/node_modules/tsx/dist/cli.mjs
  <repo>/agentdev/mcp/src/index.ts` —— 免构建，模板即装即用。
- 构建态：`agentdev-mcp` package.json `bin` 已声明 `dist/index.js`；执行
  `tsc` 构建后可把 args 换成 `<repo>/agentdev/mcp/dist/index.js`（`node` 直跑）。
- `env.AGENTDEV_PROJECT_ROOT`：IDE 常从任意 cwd 拉起 MCP 服务，env 显式声明项目根
  是最可靠的寻址通道（paths.ts 的最高优先级解析项）。

## 校验与验收

`agentdev/e2e/ac1-seven-platforms.spec.ts` 对每份模板做两件事（L3-a）：
1. **配置校验**：按各端形态解析（JSON 解析 / codex 受控 TOML 子集解析），抽取
   server 条目，替换占位符后断言 command 可解析、args 指向的真实文件存在；
2. **真实 stdio 握手**：以模板解析出的 command/args/env 原样拉起子进程，走真实
   `initialize` → `tools/list`，断言回包含 7 个注册工具（ping / license_status /
   agent_scaffold / agent_eval_run / agentdev_status / agentdev_signoff /
   agentdev_deploy）。
